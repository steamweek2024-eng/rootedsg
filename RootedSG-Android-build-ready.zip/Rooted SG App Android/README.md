# ROOTED SG — Android

A native Kotlin + Jetpack Compose port of the iOS app in `../RootedSG`, built to feature parity: onboarding, the Verified Plant-Day check-in system, the AI-assisted Plant Doctor, the Grower Exchange marketplace, real chat, Google Sign-In, BioDex, Quests, Community, and the five-theme design system.

It talks to **the exact same backend** as the iOS app (`../RootedSG/backend`) — nothing here duplicates or forks that server. A listing posted from an iPhone is visible and buyable from this app, and vice versa.

## Stack

- Kotlin, Jetpack Compose (Material 3), Navigation-Compose
- Room — the local-first store (SwiftData's counterpart here)
- Retrofit + OkHttp — REST client for the shared backend
- Credential Manager (`androidx.credentials`) + Google Identity Services — Sign-In
- Coil — local photo loading
- No Hilt/Dagger: a small manual `AppContainer` wires everything, matching the iOS app's own minimal-dependency style

## Building

Requires the Android SDK (`compileSdk 34`, `build-tools 34.0.0`) and JDK 17+. Point `local.properties` at your SDK:

```sh
echo "sdk.dir=$HOME/Library/Android/sdk" > local.properties
./gradlew :app:assembleDebug
```

To run it: open the project in Android Studio (simplest — it also gives you an emulator), or with a device/emulator already connected:

```sh
./gradlew :app:installDebug
```

The debug build points at `http://10.0.2.2:8787` — the Android emulator's alias for the host machine's `127.0.0.1` — so `cd ../RootedSG/backend && npm start` on the same machine is all a fresh checkout needs to talk to a real backend. A physical device on the same Wi-Fi instead needs the host machine's LAN IP in `AI_BASE_URL_DEBUG` (`app/build.gradle.kts`).

## Sign in with Google

Same account system as iOS, same backend, different native flow (Android's Credential Manager instead of `ASWebAuthenticationSession`) — and Android's token carries a *different* `aud` (audience) than iOS's, so the backend accepts a list of client IDs, not just one. Full multi-platform setup steps are in `../RootedSG/backend/README.md` under "Sign in with Google" — in short, this app needs:

1. An **Android** OAuth client in Google Cloud Console (package `sg.rooted.android` + your signing key's SHA-1) — required for Google to recognize the app, but its ID is never typed into this codebase.
2. A **Web application** OAuth client — its ID goes in `app/build.gradle.kts` as `GOOGLE_WEB_CLIENT_ID` (both the `buildConfigField` and `manifestPlaceholders` entries), and is what Android's Credential Manager flow uses as `serverClientId`.
3. The server's `GOOGLE_CLIENT_ID` env var gets *both* the iOS client ID and this Web client ID, comma-separated.

Until that's filled in, tapping "Sign in with Google" fails closed with a clear, non-crashing message — same behavior as the iOS app's placeholder state.

## What's deliberately not here (matching iOS's own documented limits)

- A synced listing (posted by the *other* platform, or another account) carries no real photo — a deterministic local placeholder image renders instead. Same as iOS.
- "Make an offer" (vs. a straight Buy) stays local-only, not synced across accounts.
- No on-device Vision-framework species classifier — Apple's `VNClassifyImageRequest` has no Android equivalent without adding ML Kit, which this build didn't. Species suggestion here is cloud-assisted only (via the same backend's `/v1/plant-analysis`), with the same manual catalog fallback iOS uses at low confidence.
- No physical-device verification in this environment — this build was compiled and packaged (`./gradlew assembleDebug`) but not run on an emulator or device here; do that in Android Studio to see it live.
