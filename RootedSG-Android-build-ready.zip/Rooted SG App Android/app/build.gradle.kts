import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

val rootedLocal = Properties().apply {
    val file = rootProject.file("local.properties")
    if (file.exists()) file.inputStream().use(::load)
}

fun rootedConfig(name: String, fallback: String = ""): String =
    (rootedLocal.getProperty(name)
        ?: providers.gradleProperty(name).orNull
        ?: System.getenv(name)
        ?: fallback).trim()

fun buildString(value: String): String = "\"${value.replace("\\", "\\\\").replace("\"", "\\\"")}\""

val backendDebug = rootedConfig("ROOTED_BACKEND_URL_DEBUG", "http://10.0.2.2:8787")
val backendRelease = rootedConfig("ROOTED_BACKEND_URL_RELEASE")
val googleWebClientId = rootedConfig("GOOGLE_WEB_CLIENT_ID")

val releaseKeystorePath = rootedConfig("ROOTED_RELEASE_KEYSTORE")
val releaseKeystorePassword = rootedConfig("ROOTED_RELEASE_KEYSTORE_PASSWORD")
val releaseKeyAlias = rootedConfig("ROOTED_RELEASE_KEY_ALIAS")
val releaseKeyPassword = rootedConfig("ROOTED_RELEASE_KEY_PASSWORD")
val hasReleaseSigning = listOf(
    releaseKeystorePath, releaseKeystorePassword, releaseKeyAlias, releaseKeyPassword,
).all { it.isNotBlank() } && rootProject.file(releaseKeystorePath).exists()

android {
    namespace = "sg.rooted.android"
    compileSdk = 34

    defaultConfig {
        applicationId = "sg.rooted.android"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.1.0"

        // No production secrets are committed to source. Debug defaults to the Android
        // emulator's host alias. Release simply runs local-first until a real HTTPS backend
        // is supplied through local.properties, -P, or environment variables.
        buildConfigField("String", "AI_BASE_URL_DEBUG", buildString(backendDebug))
        buildConfigField("String", "AI_BASE_URL_RELEASE", buildString(backendRelease))
        buildConfigField("String", "GOOGLE_WEB_CLIENT_ID", buildString(googleWebClientId))
        manifestPlaceholders["googleWebClientId"] = googleWebClientId
    }

    signingConfigs {
        if (hasReleaseSigning) {
            create("rootedRelease") {
                storeFile = rootProject.file(releaseKeystorePath)
                storePassword = releaseKeystorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // A local build remains sideloadable without a production key. Play/managed
            // distribution should provide ROOTED_RELEASE_* and will automatically use it.
            signingConfig = if (hasReleaseSigning) signingConfigs.getByName("rootedRelease") else signingConfigs.getByName("debug")
        }
        debug { isDebuggable = true }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures {
        compose = true
        buildConfig = true
    }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }

    packaging {
        resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" }
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.06.00")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.1")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    debugImplementation("androidx.compose.ui:ui-tooling")

    implementation("androidx.navigation:navigation-compose:2.7.7")

    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-gson:2.11.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    implementation("androidx.credentials:credentials:1.3.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")

    implementation("io.coil-kt:coil-compose:2.6.0")
    implementation("io.coil-kt:coil-gif:2.6.0")
    implementation("androidx.core:core-splashscreen:1.0.1")

    testImplementation("junit:junit:4.13.2")
    testImplementation("androidx.room:room-common:2.6.1")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
}
