# Add project specific ProGuard rules here.
-keep class sg.rooted.android.network.** { *; }
