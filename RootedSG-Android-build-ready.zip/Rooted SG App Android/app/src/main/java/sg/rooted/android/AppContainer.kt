package sg.rooted.android

import android.content.Context
import sg.rooted.android.account.AccountService
import sg.rooted.android.data.GardenRepository
import sg.rooted.android.data.MarketRepository
import sg.rooted.android.data.PreferencesStore
import sg.rooted.android.data.RootedDatabase

/** A small manual dependency container — no DI framework, matching this project's minimal-dependency style. */
class AppContainer(context: Context) {
    val prefs = PreferencesStore(context)
    val db: RootedDatabase = RootedDatabase.get(context)
    val accountService = AccountService(context.applicationContext, prefs)
    val gardenRepository = GardenRepository(db, context.applicationContext)
    val marketRepository = MarketRepository(db, accountService)
}
