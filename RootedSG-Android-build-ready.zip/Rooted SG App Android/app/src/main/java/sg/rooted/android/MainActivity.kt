package sg.rooted.android

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.launch
import sg.rooted.android.engine.CheckInReminders
import sg.rooted.android.engine.MojoNudges
import sg.rooted.android.ui.Routes
import sg.rooted.android.ui.RootedNavHost
import sg.rooted.android.ui.theme.RootedThemeProvider

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as RootedApplication
        val reminderPlantId = intent.getStringExtra(CheckInReminders.EXTRA_PLANT_ID)
        val openPetFromNudge = intent.getBooleanExtra(MojoNudges.EXTRA_OPEN_PET, false)

        // Holds the splash on screen until the local database has answered
        // whether a profile already exists — a beat longer than the OS
        // minimum, but it means the very first frame Compose draws is
        // already the right one (onboarding or the shell), never a flash
        // of the wrong destination.
        var contentReady = false
        splashScreen.setKeepOnScreenCondition { !contentReady }

        setContent {
            val viewModel: RootedViewModel = viewModel(factory = RootedViewModel.factory(app.container))
            val isDark = isSystemInDarkTheme()
            LaunchedEffect(isDark) { app.themeStore.systemPrefersDark = isDark }
            LaunchedEffect(Unit) {
                viewModel.user // trigger collection start
                viewModel.hasResolvedStartDestination.collect { resolved ->
                    if (resolved) contentReady = true
                }
            }

            RootedThemeProvider(app.themeStore) {
                val navController = rememberNavController()

                // A tapped check-in reminder opens straight to that plant's
                // check-in screen, once the shell itself has actually loaded.
                LaunchedEffect(reminderPlantId) {
                    if (reminderPlantId == null) return@LaunchedEffect
                    snapshotFlowUntilShellReady(navController)
                    navController.navigate(Routes.checkIn(reminderPlantId))
                }

                // A tapped Mojo nudge opens Mojo's screen.
                LaunchedEffect(openPetFromNudge) {
                    if (!openPetFromNudge) return@LaunchedEffect
                    snapshotFlowUntilShellReady(navController)
                    navController.navigate(Routes.PET)
                }

                RootedNavHost(navController = navController, viewModel = viewModel, themeStore = app.themeStore)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Feeds MojoNudges' "hasn't seen you in N days" line — written here, read
        // by the background worker.
        val prefs = (application as RootedApplication).container.prefs
        lifecycleScope.launch { prefs.setAppLastOpenMs(System.currentTimeMillis()) }
    }

    private suspend fun snapshotFlowUntilShellReady(navController: androidx.navigation.NavHostController) {
        // The shell is the natural place to land under a pushed check-in screen;
        // give the nav graph a moment to reach its start destination first.
        var attempts = 0
        while (navController.currentDestination == null && attempts < 200) {
            kotlinx.coroutines.delay(10)
            attempts++
        }
    }
}
