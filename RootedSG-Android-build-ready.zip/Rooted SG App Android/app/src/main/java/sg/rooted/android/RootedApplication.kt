package sg.rooted.android

import android.app.Application
import android.os.Build
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.GifDecoder
import coil.decode.ImageDecoderDecoder
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import sg.rooted.android.engine.CheckInReminders
import sg.rooted.android.engine.ImageStore
import sg.rooted.android.engine.MojoNudges
import sg.rooted.android.ui.theme.ThemeStore

class RootedApplication : Application(), ImageLoaderFactory {
    lateinit var container: AppContainer
        private set
    lateinit var themeStore: ThemeStore
        private set

    private val appScope = MainScope()

    override fun onCreate() {
        super.onCreate()
        ImageStore.init(this)
        CheckInReminders.ensureChannel(this)
        MojoNudges.ensureChannel(this)
        MojoNudges.arm(this)
        container = AppContainer(this)
        themeStore = ThemeStore(container.prefs, appScope)
        appScope.launch { container.accountService.restoreSession() }
    }

    /**
     * One process-wide Coil [ImageLoader] with an animated-image decoder registered —
     * Coil picks this up automatically for every `AsyncImage` / `rememberAsyncImagePainter`
     * call, so the Mojo companion's `res/raw/mojo_*.gif` sprites actually animate.
     * `ImageDecoderDecoder` is the platform path (API 28+); `GifDecoder` is the pure-Kotlin
     * fallback for API 26–27.
     */
    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .components {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) add(ImageDecoderDecoder.Factory())
                else add(GifDecoder.Factory())
            }
            .build()
}
