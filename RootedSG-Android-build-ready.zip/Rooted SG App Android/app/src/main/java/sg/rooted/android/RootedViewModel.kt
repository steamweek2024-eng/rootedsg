package sg.rooted.android

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import sg.rooted.android.account.AccountService
import sg.rooted.android.data.GardenRepository
import sg.rooted.android.data.MarketRepository
import sg.rooted.android.engine.MojoEngine
import sg.rooted.android.engine.MojoMood
import sg.rooted.android.engine.PetVitals
import sg.rooted.android.model.*

/**
 * One shared ViewModel for the whole app shell — the Compose counterpart to
 * SwiftUI passing `@Bindable var user: UserProfile` (plus `@Query`) down
 * through every screen. Repositories are exposed directly so screens can call
 * a mutation and act on its return value inside their own coroutine scope,
 * the same way the iOS screens `await` GameEngine/ExchangeEngine calls
 * directly and react to the outcome (e.g. the celebration overlay).
 */
@OptIn(ExperimentalCoroutinesApi::class)
class RootedViewModel(private val container: AppContainer) : ViewModel() {

    val garden: GardenRepository get() = container.gardenRepository
    val market: MarketRepository get() = container.marketRepository
    val account: AccountService get() = container.accountService

    val accountState: StateFlow<sg.rooted.android.account.AccountState> = account.state

    val user: StateFlow<UserProfile?> = garden.observeUser()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    /** True once the local database has answered at least once — lets the splash
     * screen hold until we genuinely know whether to open onboarding or the
     * shell, rather than a fixed timer or a flash of the wrong destination. */
    val hasResolvedStartDestination: StateFlow<Boolean> = garden.observeUser()
        .map { true }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    val plants: StateFlow<List<Plant>> = user
        .flatMapLatest { u -> u?.let { garden.observePlants(it.id) } ?: flowOf(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val quests: StateFlow<List<Quest>> = user
        .flatMapLatest { u -> u?.let { garden.observeQuests(it.id) } ?: flowOf(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** Persistent diagnosis history across all plants — powers achievements and recovery analytics. */
    val diagnosisSessions: StateFlow<List<DiagnosisSession>> = user
        .flatMapLatest { u -> u?.let { garden.observeAllDiagnosisSessions(it.id) } ?: flowOf(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sightings: StateFlow<List<Sighting>> = user
        .flatMapLatest { u -> u?.let { garden.observeSightings(it.id) } ?: flowOf(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** The XP ledger, newest first, capped — what the Progress screen's activity feed reads. */
    val recentXPEvents: StateFlow<List<XPEvent>> = user
        .flatMapLatest { u -> u?.let { garden.observeRecentXPEvents(it.id) } ?: flowOf(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** The full, uncapped XP ledger — used for all-time breakdowns (source chart, best day). */
    val allXPEvents: StateFlow<List<XPEvent>> = user
        .flatMapLatest { u -> u?.let { garden.observeAllXPEvents(it.id) } ?: flowOf(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** Sum of XP earned in the last 7 days — a small "this week" stat, nothing more. */
    val xpThisWeek: StateFlow<Int> = user
        .flatMapLatest { u -> u?.let { garden.observeXPThisWeek(it.id) } ?: flowOf(0) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // MARK: - Mojo the carrot (companion pet)

    /** The walkthrough gate — reuses the long-dormant `hasSeenTutorial` flag. */
    val hasSeenTutorial: StateFlow<Boolean> = container.prefs.hasSeenTutorial
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)

    val petName: StateFlow<String> = container.prefs.petName
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "Mojo")

    val petNudgesEnabled: StateFlow<Boolean> = container.prefs.petNudgesEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    /** Mojo's live vitals — recomputed from the same real signals the rest of the
     * app already tracks (see [MojoEngine.vitals]). */
    val petVitals: StateFlow<PetVitals> = combine(plants, quests, user, xpThisWeek) { p, q, u, xp ->
        MojoEngine.vitals(p, q, u, xp)
    }.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000),
        PetVitals(health = 60, gardenScore = 0.6, badgeScore = 0.0, momentumScore = 0.0, mood = MojoMood.OKAY),
    )

    suspend fun setWalkthroughSeen(seen: Boolean) = container.prefs.setHasSeenTutorial(seen)
    suspend fun setPetName(name: String) = container.prefs.setPetName(name)
    suspend fun setPetNudges(enabled: Boolean) = container.prefs.setPetNudgesEnabled(enabled)

    val listings: StateFlow<List<ProduceListing>> = market.observeListings()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val requests: StateFlow<List<ProduceRequest>> = market.observeRequests()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val exchanges: StateFlow<List<Exchange>> = user
        .flatMapLatest { u -> u?.let { market.observeExchanges(it.id) } ?: flowOf(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val chatThreads: StateFlow<List<ChatThread>> = user
        .flatMapLatest { u -> u?.let { market.observeChatThreads(it.id) } ?: flowOf(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** Bootstraps a brand-new profile with the same clearly-labelled sample dataset the demo offers. */
    suspend fun seedDemoIfEmpty(user: UserProfile) {
        if (plants.value.isEmpty() && listings.value.none { it.ownerId == user.id }) {
            garden.seedDemoGarden(user)
            market.seedMarketIfNeeded()
        }
    }

    companion object {
        fun factory(container: AppContainer): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = RootedViewModel(container) as T
        }
    }
}
