package sg.rooted.android.account

import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import sg.rooted.android.BuildConfig
import sg.rooted.android.data.PreferencesStore
import sg.rooted.android.network.BackendClient

data class AccountState(
    val isSignedIn: Boolean = false,
    val accountId: String? = null,
    val email: String? = null,
    val displayName: String? = null,
    val sessionToken: String? = null,
)

sealed class AccountError(message: String) : Exception(message) {
    object MissingClientId : AccountError(
        "Google Sign-In isn't configured, add your own Web OAuth client ID as GOOGLE_WEB_CLIENT_ID " +
            "(see backend/README.md \"Sign in with Google\")."
    )
    object Cancelled : AccountError("Sign-in was cancelled.")
    object NoGoogleAccount : AccountError(
        "No Google account is available on this device to sign in with."
    )
    class Other(message: String) : AccountError(message)
}

/**
 * Owns the signed-in Google account, if any, and the ROOTED session it
 * exchanges for — the Android counterpart to iOS's AccountService.swift,
 * using Credential Manager (Google's current recommended API) instead of
 * ASWebAuthenticationSession. ROOTED works fully offline and account-free by
 * default; signing in is what unlocks syncing the Grower Exchange (and, through
 * it, real chat) across devices.
 */
class AccountService(private val appContext: Context, private val prefs: PreferencesStore) {

    private val _state = MutableStateFlow(AccountState())
    val state: StateFlow<AccountState> = _state.asStateFlow()

    suspend fun restoreSession() {
        val stored = prefs.storedSession() ?: return
        _state.value = AccountState(
            isSignedIn = true,
            accountId = stored.accountId,
            email = stored.email,
            displayName = stored.name,
            sessionToken = stored.sessionToken,
        )
    }

    /** [activityContext] must be an Activity — Credential Manager requires it to show the account picker. */
    suspend fun signIn(activityContext: Context): AccountState {
        val clientId = BuildConfig.GOOGLE_WEB_CLIENT_ID
        if (clientId.isBlank() || clientId.startsWith("REPLACE_WITH_YOUR_")) {
            throw AccountError.MissingClientId
        }

        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(clientId)
            .setAutoSelectEnabled(false)
            .build()
        val request = GetCredentialRequest.Builder().addCredentialOption(googleIdOption).build()

        val credentialManager = CredentialManager.create(appContext)
        val idToken: String = try {
            val result = credentialManager.getCredential(request = request, context = activityContext)
            val credential = result.credential
            if (credential is CustomCredential &&
                credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
            ) {
                GoogleIdTokenCredential.createFrom(credential.data).idToken
            } else {
                throw AccountError.Other("Google did not return an identity token.")
            }
        } catch (e: GetCredentialCancellationException) {
            throw AccountError.Cancelled
        } catch (e: NoCredentialException) {
            throw AccountError.NoGoogleAccount
        } catch (e: GetCredentialException) {
            throw AccountError.Other(e.message ?: "Sign-in failed.")
        }

        val account = BackendClient.signInWithGoogle(idToken)
        prefs.saveSession(
            PreferencesStore.StoredSession(
                sessionToken = account.sessionToken,
                accountId = account.id,
                email = account.email,
                name = account.name,
            )
        )
        val newState = AccountState(
            isSignedIn = true,
            accountId = account.id,
            email = account.email,
            displayName = account.name,
            sessionToken = account.sessionToken,
        )
        _state.value = newState
        return newState
    }

    suspend fun signOut() {
        try {
            CredentialManager.create(appContext)
                .clearCredentialState(ClearCredentialStateRequest())
        } catch (e: Exception) {
            // Best-effort — signing out of ROOTED itself still proceeds.
        }
        prefs.clearSession()
        _state.value = AccountState()
    }
}
