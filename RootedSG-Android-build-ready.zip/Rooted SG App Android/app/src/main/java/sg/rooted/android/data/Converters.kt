package sg.rooted.android.data

import androidx.room.TypeConverter
import sg.rooted.android.model.*

/** Room has no built-in enum support in this version — one converter pair per enum. */
class Converters {
    @TypeConverter fun fromPlantStage(v: PlantStage): String = v.name
    @TypeConverter fun toPlantStage(v: String): PlantStage = PlantStage.valueOf(v)

    @TypeConverter fun fromHealthStatus(v: HealthStatus): String = v.name
    @TypeConverter fun toHealthStatus(v: String): HealthStatus = HealthStatus.valueOf(v)

    @TypeConverter fun fromConfidenceLevel(v: ConfidenceLevel): String = v.name
    @TypeConverter fun toConfidenceLevel(v: String): ConfidenceLevel = ConfidenceLevel.valueOf(v)

    @TypeConverter fun fromObservationCategory(v: ObservationCategory): String = v.name
    @TypeConverter fun toObservationCategory(v: String): ObservationCategory = ObservationCategory.valueOf(v)

    @TypeConverter fun fromVerificationStatus(v: VerificationStatus): String = v.name
    @TypeConverter fun toVerificationStatus(v: String): VerificationStatus = VerificationStatus.valueOf(v)

    @TypeConverter fun fromQuestType(v: QuestType): String = v.name
    @TypeConverter fun toQuestType(v: String): QuestType = QuestType.valueOf(v)

    @TypeConverter fun fromQuestStatus(v: QuestStatus): String = v.name
    @TypeConverter fun toQuestStatus(v: String): QuestStatus = QuestStatus.valueOf(v)


    @TypeConverter fun fromDiagnosisStatus(v: DiagnosisStatus): String = v.name
    @TypeConverter fun toDiagnosisStatus(v: String): DiagnosisStatus = DiagnosisStatus.valueOf(v)

    @TypeConverter fun fromDiagnosisSource(v: DiagnosisSource): String = v.name
    @TypeConverter fun toDiagnosisSource(v: String): DiagnosisSource = DiagnosisSource.valueOf(v)

    @TypeConverter fun fromProduceKind(v: ProduceKind): String = v.name
    @TypeConverter fun toProduceKind(v: String): ProduceKind = ProduceKind.valueOf(v)

    @TypeConverter fun fromExchangeTerms(v: ExchangeTerms): String = v.name
    @TypeConverter fun toExchangeTerms(v: String): ExchangeTerms = ExchangeTerms.valueOf(v)

    @TypeConverter fun fromListingStatus(v: ListingStatus): String = v.name
    @TypeConverter fun toListingStatus(v: String): ListingStatus = ListingStatus.valueOf(v)

    @TypeConverter fun fromRequestStatus(v: RequestStatus): String = v.name
    @TypeConverter fun toRequestStatus(v: String): RequestStatus = RequestStatus.valueOf(v)

    @TypeConverter fun fromExchangeStatus(v: ExchangeStatus): String = v.name
    @TypeConverter fun toExchangeStatus(v: String): ExchangeStatus = ExchangeStatus.valueOf(v)

    @TypeConverter fun fromExchangeKind(v: ExchangeKind): String = v.name
    @TypeConverter fun toExchangeKind(v: String): ExchangeKind = ExchangeKind.valueOf(v)
}
