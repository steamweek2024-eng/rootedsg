package sg.rooted.android.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow
import sg.rooted.android.model.*

@Dao
interface UserProfileDao {
    @Query("SELECT * FROM user_profile LIMIT 1")
    fun observe(): Flow<UserProfile?>

    @Query("SELECT * FROM user_profile LIMIT 1")
    suspend fun get(): UserProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(user: UserProfile)

    @Query("DELETE FROM user_profile")
    suspend fun clear()
}

@Dao
interface PlantDao {
    @Query("SELECT * FROM plants WHERE ownerId = :ownerId ORDER BY verifiedPlantDays DESC")
    fun observeAll(ownerId: String): Flow<List<Plant>>

    @Query("SELECT * FROM plants WHERE id = :id")
    fun observeOne(id: String): Flow<Plant?>

    @Query("SELECT * FROM plants WHERE id = :id")
    suspend fun get(id: String): Plant?

    @Query("SELECT * FROM plants WHERE ownerId = :ownerId")
    suspend fun getAll(ownerId: String): List<Plant>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(plant: Plant)

    @Delete
    suspend fun delete(plant: Plant)

    @Query("SELECT COUNT(*) FROM plants WHERE ownerId = :ownerId")
    suspend fun count(ownerId: String): Int
}

@Dao
interface CheckInDao {
    @Query("SELECT * FROM check_ins WHERE plantId = :plantId ORDER BY date DESC")
    fun observeForPlant(plantId: String): Flow<List<CheckIn>>

    @Query("SELECT * FROM check_ins WHERE plantId = :plantId ORDER BY date DESC")
    suspend fun getForPlant(plantId: String): List<CheckIn>

    @Insert
    suspend fun insert(checkIn: CheckIn)
}

@Dao
interface QuestDao {
    @Query("SELECT * FROM quests WHERE ownerId = :ownerId ORDER BY createdDate DESC")
    fun observeAll(ownerId: String): Flow<List<Quest>>

    @Query("SELECT * FROM quests WHERE id = :id LIMIT 1")
    suspend fun get(id: String): Quest?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(quest: Quest)

    @Query("SELECT * FROM quests WHERE ownerId = :ownerId")
    suspend fun getAll(ownerId: String): List<Quest>
}

@Dao
interface DiagnosisSessionDao {
    @Query("SELECT * FROM diagnosis_sessions WHERE plantId = :plantId ORDER BY createdDate DESC")
    fun observeForPlant(plantId: String): Flow<List<DiagnosisSession>>

    @Query("SELECT * FROM diagnosis_sessions WHERE plantId = :plantId ORDER BY createdDate DESC LIMIT 1")
    suspend fun latestForPlant(plantId: String): DiagnosisSession?

    @Query("SELECT * FROM diagnosis_sessions WHERE ownerId = :ownerId ORDER BY createdDate DESC")
    fun observeAll(ownerId: String): Flow<List<DiagnosisSession>>

    @Query("SELECT * FROM diagnosis_sessions WHERE ownerId = :ownerId ORDER BY createdDate DESC")
    suspend fun getAll(ownerId: String): List<DiagnosisSession>

    @Query("SELECT * FROM diagnosis_sessions WHERE id = :id LIMIT 1")
    suspend fun get(id: String): DiagnosisSession?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(session: DiagnosisSession)
}

@Dao
interface SightingDao {
    @Query("SELECT * FROM sightings WHERE ownerId = :ownerId ORDER BY date DESC")
    fun observeAll(ownerId: String): Flow<List<Sighting>>

    @Query("SELECT * FROM sightings WHERE ownerId = :ownerId")
    suspend fun getAll(ownerId: String): List<Sighting>

    @Insert
    suspend fun insert(sighting: Sighting)
}

@Dao
interface XPEventDao {
    @Query("SELECT * FROM xp_events WHERE ownerId = :ownerId ORDER BY date DESC LIMIT :limit")
    fun observeRecent(ownerId: String, limit: Int = 40): Flow<List<XPEvent>>

    /** Unbounded — used for all-time breakdowns (source chart, best day), where
     * capping at "recent" would understate a long-lived profile's real totals. */
    @Query("SELECT * FROM xp_events WHERE ownerId = :ownerId ORDER BY date DESC")
    fun observeAll(ownerId: String): Flow<List<XPEvent>>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM xp_events WHERE ownerId = :ownerId AND date >= :sinceMs")
    fun observeSumSince(ownerId: String, sinceMs: Long): Flow<Int>

    @Insert
    suspend fun insert(event: XPEvent)
}

@Dao
interface ProduceListingDao {
    @Query("SELECT * FROM produce_listings ORDER BY createdDate DESC")
    fun observeAll(): Flow<List<ProduceListing>>

    @Query("SELECT * FROM produce_listings")
    suspend fun getAll(): List<ProduceListing>

    @Query("SELECT * FROM produce_listings WHERE id = :id")
    suspend fun get(id: String): ProduceListing?

    @Query("SELECT * FROM produce_listings WHERE id = :id")
    fun observeOne(id: String): Flow<ProduceListing?>

    @Query("SELECT * FROM produce_listings WHERE ownerId = :ownerId ORDER BY createdDate DESC")
    fun observeOwnedBy(ownerId: String): Flow<List<ProduceListing>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(listing: ProduceListing)

    @Query("SELECT COUNT(*) FROM produce_listings WHERE isSeeded = 1")
    suspend fun seededCount(): Int
}

@Dao
interface ProduceRequestDao {
    @Query("SELECT * FROM produce_requests ORDER BY createdDate DESC")
    fun observeAll(): Flow<List<ProduceRequest>>

    @Query("SELECT * FROM produce_requests")
    suspend fun getAll(): List<ProduceRequest>

    @Query("SELECT id FROM produce_requests")
    suspend fun getAllIds(): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(request: ProduceRequest)
}

@Dao
interface ExchangeDao {
    @Query("SELECT * FROM exchanges WHERE ownerId = :ownerId ORDER BY createdDate DESC")
    fun observeAll(ownerId: String): Flow<List<Exchange>>

    @Query("SELECT * FROM exchanges WHERE ownerId = :ownerId")
    suspend fun getAll(ownerId: String): List<Exchange>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(exchange: Exchange)

    @Delete
    suspend fun delete(exchange: Exchange)
}

@Dao
interface ChatThreadDao {
    @Query("SELECT * FROM chat_threads WHERE ownerId = :ownerId ORDER BY lastMessageDate DESC")
    fun observeAll(ownerId: String): Flow<List<ChatThread>>

    @Query("SELECT * FROM chat_threads WHERE id = :id")
    fun observeOne(id: String): Flow<ChatThread?>

    @Query("SELECT * FROM chat_threads WHERE ownerId = :ownerId AND listingId = :listingId LIMIT 1")
    suspend fun findByListing(ownerId: String, listingId: String): ChatThread?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(thread: ChatThread)
}

@Dao
interface ChatMessageDao {
    @Query("SELECT * FROM chat_messages WHERE threadId = :threadId ORDER BY createdDate ASC")
    fun observeForThread(threadId: String): Flow<List<ChatMessage>>

    @Query("SELECT * FROM chat_messages WHERE threadId = :threadId ORDER BY createdDate ASC")
    suspend fun getForThread(threadId: String): List<ChatMessage>

    @Insert
    suspend fun insert(message: ChatMessage)
}
