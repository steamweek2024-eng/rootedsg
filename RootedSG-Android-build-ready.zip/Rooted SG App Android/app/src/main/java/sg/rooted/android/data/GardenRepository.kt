package sg.rooted.android.data

import android.content.Context
import android.graphics.Bitmap
import kotlinx.coroutines.flow.Flow
import sg.rooted.android.engine.CheckInReminders
import sg.rooted.android.engine.DiagnosisEngine
import sg.rooted.android.engine.GameEngine
import sg.rooted.android.engine.ImageStore
import sg.rooted.android.engine.PlantDayLedger
import sg.rooted.android.engine.SamplePhoto
import sg.rooted.android.engine.VisionService
import sg.rooted.android.engine.WeatherService
import sg.rooted.android.network.BackendClient
import sg.rooted.android.model.*
import java.util.Calendar
import java.io.ByteArrayOutputStream
import kotlin.math.roundToInt
import java.util.concurrent.TimeUnit

/**
 * The stateful mutation engine for the garden side of the app — a Room-backed
 * port of GameEngine.swift's registration/check-in/quest/demo-seeding logic.
 * Where SwiftData mutates objects in place and calls `context.save()`, this
 * fetches the current row, computes the next value, and re-persists it; every
 * DAO query used elsewhere is Flow-backed so the UI updates automatically.
 */
class GardenRepository(private val db: RootedDatabase, private val appContext: Context) {

    // MARK: - User

    fun observeUser(): Flow<UserProfile?> = db.userProfileDao().observe()

    suspend fun currentUserOrNull(): UserProfile? = db.userProfileDao().get()

    suspend fun ensureUser(name: String, school: String, avatarEmoji: String, neighbourhood: String): UserProfile {
        currentUserOrNull()?.let { return it }
        val user = UserProfile(name = name, school = school, avatarEmoji = avatarEmoji, neighbourhood = neighbourhood)
        db.userProfileDao().upsert(user)
        seedStarterQuests(user.id)
        return user
    }

    suspend fun saveUser(user: UserProfile) = db.userProfileDao().upsert(user)

    fun observeRecentXPEvents(ownerId: String) = db.xpEventDao().observeRecent(ownerId)
    fun observeAllXPEvents(ownerId: String) = db.xpEventDao().observeAll(ownerId)
    fun observeXPThisWeek(ownerId: String) =
        db.xpEventDao().observeSumSince(ownerId, System.currentTimeMillis() - TimeUnit.DAYS.toMillis(7))

    /** Logs one XP ledger entry — called alongside every GameEngine.award(...), so
     * the Progress screen's activity feed shows what was actually earned, not
     * just a running total. */
    private suspend fun logXP(ownerId: String, amount: Int, reason: String, icon: String) {
        if (amount == 0) return
        db.xpEventDao().insert(XPEvent(ownerId = ownerId, amount = amount, reason = reason, icon = icon))
    }

    // MARK: - Shop

    /** Buys `item` if affordable and not already owned, then equips it — a
     * purchase is always also a wear. Returns the updated profile, or null if
     * the purchase couldn't go through (already owned / can't afford it). */
    suspend fun purchase(user: UserProfile, item: sg.rooted.android.engine.ShopItem): UserProfile? {
        if (user.owns(item) || user.seeds < item.price) return null
        val withPurchase = user.copy(
            seeds = user.seeds - item.price,
            ownedItemIdsRaw = (user.ownedItemIds + item.id).joinToString(","),
        )
        val equipped = applyEquip(withPurchase, item)
        db.userProfileDao().upsert(equipped)
        return equipped
    }

    suspend fun equip(user: UserProfile, item: sg.rooted.android.engine.ShopItem): UserProfile {
        if (!user.owns(item)) return user
        val updated = applyEquip(user, item)
        db.userProfileDao().upsert(updated)
        return updated
    }

    private fun applyEquip(user: UserProfile, item: sg.rooted.android.engine.ShopItem): UserProfile =
        when (item.category) {
            sg.rooted.android.engine.ShopCategory.TITLE -> user.copy(equippedTitleId = item.id)
            sg.rooted.android.engine.ShopCategory.FRAME -> user.copy(equippedFrameId = item.id)
            sg.rooted.android.engine.ShopCategory.POT_SKIN -> user.copy(equippedPotSkinId = item.id)
        }

    suspend fun updatePlantNotes(plant: Plant, notes: String) = db.plantDao().upsert(plant.copy(notes = notes))

    suspend fun deletePlant(plant: Plant) {
        db.checkInDao().getForPlant(plant.id).forEach { ImageStore.delete(it.imageFilename) }
        ImageStore.delete(plant.imageFilename)
        CheckInReminders.cancel(appContext, plant.id)
        db.plantDao().delete(plant)
    }

    suspend fun totalVerifiedPlantDays(ownerId: String): Int =
        db.plantDao().getAll(ownerId).sumOf { it.verifiedPlantDays }

    suspend fun activePlantCount(ownerId: String): Int =
        db.plantDao().getAll(ownerId).count { it.health != HealthStatus.DECEASED }

    // MARK: - Plants

    fun observePlants(ownerId: String): Flow<List<Plant>> = db.plantDao().observeAll(ownerId)
    fun observePlant(id: String): Flow<Plant?> = db.plantDao().observeOne(id)
    fun observeCheckIns(plantId: String): Flow<List<CheckIn>> = db.checkInDao().observeForPlant(plantId)
    fun observeDiagnosisSessions(plantId: String): Flow<List<DiagnosisSession>> = db.diagnosisSessionDao().observeForPlant(plantId)
    fun observeAllDiagnosisSessions(ownerId: String): Flow<List<DiagnosisSession>> = db.diagnosisSessionDao().observeAll(ownerId)

    /** Builds and persists the clue set. Cloud AI enriches the same session when configured;
     * otherwise the deterministic on-device engine is the complete fallback. */
    suspend fun createDiagnosisSession(
        plant: Plant, user: UserProfile, bitmap: Bitmap,
        verification: VisionService.VerificationResult, profile: VisionService.ColorProfile,
    ): DiagnosisSession {
        val weather = runCatching { WeatherService.todaysAdvisory(user.neighbourhood) }.getOrNull()
        val local = DiagnosisEngine.analyse(profile, verification, plant.healthScore, weather)

        var source = DiagnosisSource.LOCAL
        var headline = local.headline
        var clues = local.clues
        var likelyCause = local.likelyCause
        var nextAction = local.nextAction
        var observeNext = local.observeNext
        var choices = local.choices

        if (BackendClient.isConfigured && verification.vegetationDetected && verification.confidence != ConfidenceLevel.LOW) {
            runCatching {
                val out = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, 76, out)
                BackendClient.plantDoctorReport(out.toByteArray(), plant.species, user.id)
            }.getOrNull()?.let { cloud ->
                source = DiagnosisSource.HYBRID
                headline = cloud.headline.ifBlank { headline }
                val cloudClues = cloud.causes.take(3).map { cause ->
                    DiagnosisClue(
                        icon = "🧠",
                        title = cause.possibleCause,
                        detail = cause.whyPlausible,
                        confidence = 0.72,
                    )
                }
                clues = (local.clues.take(2) + cloudClues).take(4)
                cloud.causes.firstOrNull()?.possibleCause?.takeIf { it.isNotBlank() }?.let { likelyCause = it }
                if (cloud.nextAction.isNotBlank()) nextAction = cloud.nextAction
                if (cloud.observeNext.isNotBlank()) observeNext = cloud.observeNext
                val cloudChoice = DiagnosisChoice(likelyCause, "🧠", cloud.causes.firstOrNull()?.whyPlausible.orEmpty())
                choices = (listOf(cloudChoice) + local.choices)
                    .distinctBy { it.label.lowercase() }
                    .take(4)
            }
        }

        val session = DiagnosisSession(
            ownerId = user.id, plantId = plant.id, status = DiagnosisStatus.CLUES, source = source,
            headline = headline, cluesRaw = DiagnosisCodec.cluesTo(clues), choicesRaw = DiagnosisCodec.choicesTo(choices),
            likelyCause = likelyCause, nextAction = nextAction, observeNext = observeNext,
            weatherContext = weather?.careContext.orEmpty(), baselineHealthScore = local.healthScore,
        )
        db.diagnosisSessionDao().upsert(session)
        return session
    }

    data class DiagnosisChoiceOutcome(val session: DiagnosisSession, val quest: Quest?, val xpAwarded: Int, val matched: Boolean)

    suspend fun submitDiagnosisChoice(sessionId: String, choice: String): DiagnosisChoiceOutcome {
        val session = db.diagnosisSessionDao().get(sessionId) ?: throw IllegalArgumentException("Diagnosis session not found")
        val existingQuest = session.treatmentQuestId?.let { db.questDao().get(it) }
        if (session.diagnosisXP > 0) {
            return DiagnosisChoiceOutcome(session, existingQuest, 0, choicesMatch(choice, session.likelyCause))
        }

        val matched = choicesMatch(choice, session.likelyCause)
        val xp = if (matched) 150 else 50
        val liveUser = currentUserOrNull() ?: throw IllegalStateException("Profile missing")
        db.userProfileDao().upsert(GameEngine.award(liveUser, xp))
        logXP(liveUser.id, xp, if (matched) "Solved ${session.plantId.take(6)}'s plant mystery" else "Collected diagnosis clues", "sparkles")

        val plant = db.plantDao().get(session.plantId)
        var quest: Quest? = null
        var updated = session.copy(
            userChoice = choice, diagnosisXP = xp, updatedDate = System.currentTimeMillis(), status = DiagnosisStatus.VERDICT,
        )

        if (plant != null && session.baselineHealthScore < 80) {
            val objectives = DiagnosisEngine.treatmentObjectives(session.likelyCause, session.observeNext)
            val old = db.questDao().getAll(session.ownerId).firstOrNull {
                it.type == QuestType.RECOVERY && it.relatedPlantID == plant.id && it.status == QuestStatus.ACTIVE
            }
            quest = (old ?: Quest(
                ownerId = session.ownerId, type = QuestType.RECOVERY, title = "QUEST: Get ${plant.name} Healthy",
                detail = "Complete the care objectives, then recheck ${plant.name} to prove improvement.",
                target = objectives.size, rewardXP = 250, relatedPlantID = plant.id,
                baselineHealthScore = session.baselineHealthScore, requiresRecheck = true,
                bossName = DiagnosisEngine.bossName(session.likelyCause),
            )).withObjectives(objectives).copy(
                baselineHealthScore = session.baselineHealthScore, requiresRecheck = true,
                bossName = DiagnosisEngine.bossName(session.likelyCause),
            )
            db.questDao().upsert(quest)
            db.plantDao().upsert(plant.copy(rescueBaselineHealthScore = session.baselineHealthScore))
            updated = updated.copy(status = DiagnosisStatus.TREATMENT, treatmentQuestId = quest.id)
        } else {
            updated = updated.copy(status = DiagnosisStatus.COMPLETE, completedDate = System.currentTimeMillis())
        }
        db.diagnosisSessionDao().upsert(updated)
        return DiagnosisChoiceOutcome(updated, quest, xp, matched)
    }

    /** +25 XP for each real treatment objective, once. Recheck remains locked until all are complete. */
    suspend fun completeQuestObjective(questId: String, objectiveId: String): Quest? {
        val quest = db.questDao().get(questId) ?: return null
        if (quest.status != QuestStatus.ACTIVE) return quest
        val objectives = quest.objectives
        val target = objectives.firstOrNull { it.id == objectiveId } ?: return quest
        if (target.isComplete) return quest
        val now = System.currentTimeMillis()
        val updatedObjectives = objectives.map { if (it.id == objectiveId) it.copy(isComplete = true, completedDate = now) else it }
        val updated = quest.withObjectives(updatedObjectives)
        db.questDao().upsert(updated)
        val user = currentUserOrNull()
        if (user != null) {
            db.userProfileDao().upsert(GameEngine.award(user, 25))
            logXP(user.id, 25, "Treatment step: ${target.title}", "cross.case.fill")
        }
        if (updated.objectivesComplete) {
            db.diagnosisSessionDao().latestForPlant(quest.relatedPlantID.orEmpty())?.let { session ->
                if (session.treatmentQuestId == quest.id && !session.isResolved) {
                    db.diagnosisSessionDao().upsert(session.copy(status = DiagnosisStatus.RECHECK, updatedDate = now))
                }
            }
        }
        return updated
    }

    private fun choicesMatch(choice: String, likely: String): Boolean {
        fun tokens(s: String) = s.lowercase().replace(Regex("[^a-z ]"), " ").split(Regex("\\s+")).filter { it.length >= 4 }.toSet()
        val a = tokens(choice); val b = tokens(likely)
        return a.isNotEmpty() && b.isNotEmpty() && a.intersect(b).isNotEmpty()
    }

    suspend fun registerPlant(user: UserProfile, name: String, species: String, speciesEmoji: String, bitmap: Bitmap): Plant {
        val filename = ImageStore.save(bitmap)
        val plant = Plant(
            ownerId = user.id, name = name, species = species, speciesEmoji = speciesEmoji,
            registeredDate = System.currentTimeMillis(), imageFilename = filename,
        )
        db.plantDao().upsert(plant)
        db.userProfileDao().upsert(GameEngine.award(user, GameEngine.REGISTRATION_XP))
        logXP(user.id, GameEngine.REGISTRATION_XP, "Registered $name", "leaf.fill")
        ensureCareQuest(plant, user.id)
        CheckInReminders.schedule(appContext, plant)
        return plant
    }

    /** A local guardrail — compares the new photo against this user's existing plant photos. */
    suspend fun duplicatePlant(user: UserProfile, bitmap: Bitmap): Plant? =
        db.plantDao().getAll(user.id).firstOrNull { plant ->
            val previous = ImageStore.load(plant.imageFilename) ?: return@firstOrNull false
            VisionService.looksLikeDuplicate(bitmap, previous)
        }

    data class CheckInOutcome(
        val checkIn: CheckIn,
        val verified: Boolean,
        val xpGained: Int,
        val leveledUp: Boolean,
        val stageAdvanced: Boolean,
        val newStage: PlantStage,
        val milestonesHit: List<Int>,
        val doctorSummary: String,
    )

    suspend fun processCheckIn(
        plant: Plant, user: UserProfile, bitmap: Bitmap,
        verification: VisionService.VerificationResult, profile: VisionService.ColorProfile, duplicate: Boolean,
    ): CheckInOutcome {
        val liveUser = db.userProfileDao().get() ?: user
        val previousLevel = GameEngine.level(forXP = liveUser.xp)
        val now = System.currentTimeMillis()
        val filename = ImageStore.save(bitmap)
        val verified = verification.vegetationDetected && verification.confidence != ConfidenceLevel.LOW && !duplicate

        val existingCheckIns = db.checkInDao().getForPlant(plant.id)
        var updatedPlant = plant
        var daysAwarded = 0
        if (verified) {
            val hasCreditToday = existingCheckIns.any { isSameDay(it.date, now) && it.daysAwarded > 0 }
            if (!hasCreditToday) {
                daysAwarded = PlantDayLedger.award(alreadyCreditedToday = false)
                updatedPlant = updatedPlant.copy(careStreak = updatedPlant.careStreak + 1)
            }
            updatedPlant = updatedPlant.copy(lastCheckInDate = now)
        }
        // A rejected/low-confidence photo is not evidence that the plant got worse.
        // Keep its health and streak intact and simply ask for a better photo.

        val existingLedgerTotal = if (existingCheckIns.isEmpty()) updatedPlant.verifiedPlantDays
        else PlantDayLedger.total(existingCheckIns.map { it.daysAwarded })
        updatedPlant = updatedPlant.copy(verifiedPlantDays = existingLedgerTotal + daysAwarded)

        val wasStruggling = plant.health == HealthStatus.STRUGGLING || plant.health == HealthStatus.AT_RISK
        val observedScore = DiagnosisEngine.observationHealthScore(profile)
        val newHealthScore = if (verified)
            (plant.healthScore * 0.45 + observedScore * 0.55).roundToInt().coerceIn(20, 98)
        else plant.healthScore
        val newHealth = if (verified) DiagnosisEngine.healthFromScore(newHealthScore) else plant.health
        var hadRecovery = updatedPlant.hadRecoveryEvent
        if (wasStruggling && (newHealth == HealthStatus.HEALTHY || newHealth == HealthStatus.RECOVERING)) hadRecovery = true
        updatedPlant = updatedPlant.copy(health = newHealth, healthScore = newHealthScore, hadRecoveryEvent = hadRecovery)

        val candidateStage = evaluateStage(updatedPlant)
        var stageAdvanced = false
        if (candidateStage.order > updatedPlant.stage.order) {
            updatedPlant = updatedPlant.copy(stage = candidateStage)
            stageAdvanced = true
        }

        var xpGained = 0
        var updatedUser = liveUser
        if (daysAwarded > 0) {
            val careXP = GameEngine.dailyCareXP(newHealth)
            updatedUser = GameEngine.award(updatedUser, careXP)
            logXP(user.id, careXP, "${plant.name} verified check-in", "checkmark.seal.fill")
            xpGained += careXP
        }

        val milestonesHit = mutableListOf<Int>()
        if (verified) {
            var awarded = updatedPlant.awardedMilestoneDays
            for ((days, milestoneXP) in GameEngine.SURVIVAL_MILESTONES) {
                if (updatedPlant.verifiedPlantDays >= days && !awarded.contains(days)) {
                    awarded = awarded + days
                    updatedUser = GameEngine.award(updatedUser, milestoneXP)
                    logXP(user.id, milestoneXP, "${plant.name}, $days-day milestone", "star.fill")
                    xpGained += milestoneXP
                    milestonesHit.add(days)
                }
            }
            updatedPlant = updatedPlant.withAwardedMilestoneDays(awarded)
        }

        val checkIn = CheckIn(
            plantId = plant.id, date = now, imageFilename = filename, confidence = verification.confidence,
            verified = verified, vegetationDetected = verification.vegetationDetected, greenRatio = verification.greenRatio,
            duplicateFlag = duplicate, healthAtCheckIn = newHealth, healthScoreAtCheckIn = newHealthScore, daysAwarded = daysAwarded,
            note = if (duplicate) "This looks like a repeat of your last photo." else verification.summary,
        )
        db.checkInDao().insert(checkIn)
        db.plantDao().upsert(updatedPlant)

        val questXP = updateQuestsAfterCheckIn(
            plant = updatedPlant, ownerId = user.id, verified = daysAwarded > 0,
            recovered = wasStruggling && hadRecovery && daysAwarded > 0,
        )
        xpGained += questXP
        updatedUser = GameEngine.award(updatedUser, questXP)
        db.userProfileDao().upsert(updatedUser)

        // Re-arms the 7-day reminder from whatever just became the plant's newest
        // activity — a verified check-in pushes it out a week; a rejected one
        // leaves the existing countdown alone.
        if (verified) CheckInReminders.schedule(appContext, updatedPlant)

        val leveledUp = GameEngine.level(forXP = updatedUser.xp) > previousLevel

        // Small Mojo pop-ins for the real moments (a stage-up gets the full
        // celebration overlay instead, so skip the little one there).
        if (leveledUp) {
            sg.rooted.android.engine.MojoReactionBus.post(
                sg.rooted.android.engine.MojoEvent.LeveledUp(GameEngine.level(forXP = updatedUser.xp))
            )
        } else if (daysAwarded > 0 && !stageAdvanced) {
            sg.rooted.android.engine.MojoReactionBus.post(
                sg.rooted.android.engine.MojoEvent.CheckInVerified(updatedPlant.name, daysAwarded)
            )
        }
        if (!wasStruggling && (newHealth == HealthStatus.STRUGGLING || newHealth == HealthStatus.AT_RISK)) {
            sg.rooted.android.engine.MojoReactionBus.post(
                sg.rooted.android.engine.MojoEvent.PlantStruggling(updatedPlant.name)
            )
        }
        milestonesHit.maxOrNull()?.let {
            sg.rooted.android.engine.MojoReactionBus.post(sg.rooted.android.engine.MojoEvent.StreakMilestone(it))
        }

        return CheckInOutcome(
            checkIn = checkIn, verified = verified, xpGained = xpGained, leveledUp = leveledUp,
            stageAdvanced = stageAdvanced, newStage = updatedPlant.stage, milestonesHit = milestonesHit,
            doctorSummary = verification.summary,
        )
    }

    private fun evaluateStage(plant: Plant): PlantStage {
        val days = plant.verifiedPlantDays
        return when {
            plant.hadRecoveryEvent && days >= PlantStage.LEGACY.thresholdDays -> PlantStage.LEGACY
            days >= PlantStage.VETERAN.thresholdDays -> PlantStage.VETERAN
            days >= PlantStage.BLOOMING.thresholdDays -> PlantStage.BLOOMING
            days >= PlantStage.GROWING.thresholdDays || plant.careStreak >= 4 -> PlantStage.GROWING
            plant.verifiedPlantDays >= 1 || plant.careStreak >= 1 -> PlantStage.SPROUT
            else -> plant.stage
        }
    }

    // MARK: - Quests

    fun observeQuests(ownerId: String): Flow<List<Quest>> = db.questDao().observeAll(ownerId)

    suspend fun ensureCareQuest(plant: Plant, ownerId: String): Quest {
        val existing = db.questDao().getAll(ownerId)
            .firstOrNull { it.type == QuestType.CARE && it.relatedPlantID == plant.id && it.status == QuestStatus.ACTIVE }
        if (existing != null) return existing
        val quest = Quest(
            ownerId = ownerId, type = QuestType.CARE, title = "Growth Check, ${plant.name}",
            detail = "Upload ${plant.name}'s next check-in photo for XP.", target = 4, rewardXP = 40,
            relatedPlantID = plant.id,
        )
        db.questDao().upsert(quest)
        return quest
    }

    private suspend fun ensureRecoveryQuest(plant: Plant, ownerId: String) {
        val existing = db.questDao().getAll(ownerId)
            .any { it.type == QuestType.RECOVERY && it.relatedPlantID == plant.id && it.status == QuestStatus.ACTIVE }
        if (existing) return
        val objectives = DiagnosisEngine.treatmentObjectives(
            "General environmental stress",
            "Take another photo after completing the care steps and compare the same visible symptoms.",
        )
        val quest = Quest(
            ownerId = ownerId, type = QuestType.RECOVERY, title = "QUEST: Get ${plant.name} Healthy",
            detail = "Complete the care objectives, then recheck ${plant.name} to prove improvement.",
            target = objectives.size, rewardXP = 250, relatedPlantID = plant.id,
            baselineHealthScore = plant.healthScore, requiresRecheck = true, bossName = "Plant Rescue",
        ).withObjectives(objectives)
        db.questDao().upsert(quest)
        db.plantDao().upsert(plant.copy(rescueBaselineHealthScore = plant.healthScore))
    }

    private suspend fun updateQuestsAfterCheckIn(plant: Plant, ownerId: String, verified: Boolean, recovered: Boolean): Int {
        var xp = 0
        if (verified) {
            val care = db.questDao().getAll(ownerId)
                .firstOrNull { it.type == QuestType.CARE && it.relatedPlantID == plant.id && it.status == QuestStatus.ACTIVE }
            if (care != null) {
                var updated = care.copy(progress = care.progress + 1)
                if (updated.progress >= updated.target) {
                    updated = updated.copy(status = QuestStatus.COMPLETED, completedDate = System.currentTimeMillis())
                    xp += updated.rewardXP
                    logXP(ownerId, updated.rewardXP, "Completed: ${updated.title}", "drop.fill")
                    db.questDao().upsert(updated)
                    ensureCareQuest(plant, ownerId)
                } else {
                    db.questDao().upsert(updated)
                }
            }
        }

        if (plant.health == HealthStatus.STRUGGLING || plant.health == HealthStatus.AT_RISK) ensureRecoveryQuest(plant, ownerId)

        if (verified) {
            val rescue = db.questDao().getAll(ownerId)
                .firstOrNull { it.type == QuestType.RECOVERY && it.relatedPlantID == plant.id && it.status == QuestStatus.ACTIVE }
            if (rescue != null && rescue.requiresRecheck && rescue.objectivesComplete) {
                val baseline = rescue.baselineHealthScore ?: plant.rescueBaselineHealthScore ?: plant.healthScore
                val improvedEnough = plant.healthScore >= baseline + 8 || (plant.healthScore >= 80 && baseline < 80)
                if (improvedEnough) {
                    val now = System.currentTimeMillis()
                    val updated = rescue.copy(status = QuestStatus.COMPLETED, completedDate = now)
                    db.questDao().upsert(updated)
                    xp += updated.rewardXP
                    logXP(ownerId, updated.rewardXP, "Plant Rescue Complete: ${plant.name} ${baseline} → ${plant.healthScore}", "cross.case.fill")
                    db.plantDao().upsert(plant.copy(rescueBaselineHealthScore = null, hadRecoveryEvent = true))
                    db.diagnosisSessionDao().latestForPlant(plant.id)?.let { session ->
                        if (session.treatmentQuestId == rescue.id && !session.isResolved) {
                            db.diagnosisSessionDao().upsert(session.copy(
                                status = DiagnosisStatus.COMPLETE, updatedDate = now, completedDate = now,
                                recheckHealthScore = plant.healthScore,
                            ))
                        }
                    }
                } else {
                    db.diagnosisSessionDao().latestForPlant(plant.id)?.let { session ->
                        if (session.treatmentQuestId == rescue.id && !session.isResolved) {
                            db.diagnosisSessionDao().upsert(session.copy(
                                status = DiagnosisStatus.RECHECK, updatedDate = System.currentTimeMillis(),
                                recheckHealthScore = plant.healthScore,
                            ))
                        }
                    }
                }
            }
        }

        if (verified) {
            val community = db.questDao().getAll(ownerId)
                .firstOrNull { it.type == QuestType.COMMUNITY && it.status == QuestStatus.ACTIVE }
            if (community != null) {
                val target = maxOf(community.target, 90)
                val elapsed = TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis() - community.createdDate).toInt().coerceAtLeast(0)
                val progress = minOf(target, minOf(elapsed, totalVerifiedPlantDays(ownerId)))
                var updated = community.copy(target = target, progress = progress)
                if (progress >= target) {
                    updated = updated.copy(status = QuestStatus.COMPLETED, completedDate = System.currentTimeMillis())
                    xp += updated.rewardXP
                    logXP(ownerId, updated.rewardXP, "Completed: ${updated.title}", "person.3.fill")
                }
                db.questDao().upsert(updated)
            }
        }
        return xp
    }

    /** Seeds a fresh profile with the MVP's starter quest set. */
    suspend fun seedStarterQuests(ownerId: String) {
        val starters = listOf(
            Quest(ownerId = ownerId, type = QuestType.BIODIVERSITY, title = "Pollinator Visitor",
                detail = "Photograph a butterfly, bee or other pollinator near your plants.", target = 1, rewardXP = 30),
            Quest(ownerId = ownerId, type = QuestType.EXPLORATION, title = "Discover Singapore",
                detail = "Log a species you haven't recorded in your BioDex before.", target = 1, rewardXP = 30),
            Quest(ownerId = ownerId, type = QuestType.COMMUNITY, title = "90-Day Challenge",
                detail = "Keep your garden alive across a real 90-day arc. Milestones unlock at 7, 14, 30, 60 and 90 days.",
                target = 90, rewardXP = 150),
            Quest(ownerId = ownerId, type = QuestType.SCHOOL, title = "Green Class Challenge",
                detail = "Help your class climb the Green School League this term.", target = 10, rewardXP = 100),
        )
        starters.forEach { db.questDao().upsert(it) }
    }

    // MARK: - BioDex

    fun observeSightings(ownerId: String): Flow<List<Sighting>> = db.sightingDao().observeAll(ownerId)

    suspend fun logObservation(user: UserProfile, name: String, category: ObservationCategory, bitmap: Bitmap, neighbourhood: String): Sighting {
        val filename = ImageStore.save(bitmap)
        val existing = db.sightingDao().getAll(user.id)
        val isNewSpecies = existing.none { it.speciesName.equals(name, ignoreCase = true) }
        val sighting = Sighting(
            ownerId = user.id, speciesName = name, category = category, imageFilename = filename,
            verification = VerificationStatus.AI_SUGGESTED, neighbourhood = neighbourhood,
        )
        db.sightingDao().insert(sighting)
        var updatedUser = GameEngine.award(user, 15)
        logXP(user.id, 15, "Logged $name", "binoculars.fill")

        if (category == ObservationCategory.BUTTERFLY || category == ObservationCategory.BEE) {
            db.questDao().getAll(user.id).firstOrNull { it.type == QuestType.BIODIVERSITY && it.status == QuestStatus.ACTIVE }?.let {
                val updated = it.copy(progress = it.target, status = QuestStatus.COMPLETED, completedDate = System.currentTimeMillis())
                db.questDao().upsert(updated)
                updatedUser = GameEngine.award(updatedUser, updated.rewardXP)
                logXP(user.id, updated.rewardXP, "Completed: ${updated.title}", "ladybug.fill")
            }
        }
        if (isNewSpecies) {
            db.questDao().getAll(user.id).firstOrNull { it.type == QuestType.EXPLORATION && it.status == QuestStatus.ACTIVE }?.let {
                val updated = it.copy(progress = it.target, status = QuestStatus.COMPLETED, completedDate = System.currentTimeMillis())
                db.questDao().upsert(updated)
                updatedUser = GameEngine.award(updatedUser, updated.rewardXP)
                logXP(user.id, updated.rewardXP, "Completed: ${updated.title}", "map.fill")
            }
        }
        db.userProfileDao().upsert(updatedUser)
        return sighting
    }

    // MARK: - Demo garden — populates a plausible garden for the demo, clearly marked as sample data.

    private data class DemoPlantSpec(
        val name: String, val species: String, val emoji: String, val plantDays: Int, val streak: Int,
        val stage: PlantStage, val health: HealthStatus, val recovered: Boolean, val checkIns: Int,
    )

    private val demoSpecs = listOf(
        DemoPlantSpec("Bob", "Chilli Plant", "🌶️", 67, 8, PlantStage.VETERAN, HealthStatus.HEALTHY, false, 9),
        DemoPlantSpec("Pandan", "Pandan", "🌾", 194, 5, PlantStage.LEGACY, HealthStatus.HEALTHY, true, 12),
        DemoPlantSpec("Sunny", "Sunflower", "🌻", 34, 4, PlantStage.BLOOMING, HealthStatus.RECOVERING, false, 6),
        DemoPlantSpec("Mochi", "Money Plant (Pothos)", "🪴", 16, 0, PlantStage.GROWING, HealthStatus.STRUGGLING, false, 4),
        DemoPlantSpec("Kai", "Basil", "🌿", 3, 1, PlantStage.SPROUT, HealthStatus.HEALTHY, false, 1),
    )

    suspend fun seedDemoGarden(user: UserProfile) {
        val now = System.currentTimeMillis()
        val dayMs = TimeUnit.DAYS.toMillis(1)
        var totalMilestoneXP = 0

        demoSpecs.forEachIndexed { index, spec ->
            val mood = if (spec.health == HealthStatus.STRUGGLING) SamplePhoto.Mood.STRUGGLING else SamplePhoto.Mood.HEALTHY
            val heroImage = SamplePhoto.make(mood, 1000 + index * 37)
            val registered = now - (spec.plantDays + 4) * dayMs
            var plant = Plant(
                ownerId = user.id, name = spec.name, species = spec.species, speciesEmoji = spec.emoji,
                registeredDate = registered, imageFilename = ImageStore.save(heroImage),
                stage = spec.stage, health = spec.health, verifiedPlantDays = spec.plantDays, careStreak = spec.streak,
                hadRecoveryEvent = spec.recovered,
                healthScore = when (spec.health) {
                    HealthStatus.HEALTHY -> 90
                    HealthStatus.RECOVERING -> 72
                    HealthStatus.STRUGGLING -> 48
                    HealthStatus.AT_RISK -> 35
                    HealthStatus.DECEASED -> 0
                },
                lastCheckInDate = now - (if (spec.name == "Mochi") 11L else 2L) * dayMs,
            )
            plant = plant.withAwardedMilestoneDays(GameEngine.SURVIVAL_MILESTONES.filter { spec.plantDays >= it.first }.map { it.first })
            db.plantDao().upsert(plant)

            val perCheckIn = maxOf(1, spec.plantDays / maxOf(1, spec.checkIns))
            for (c in 0 until spec.checkIns) {
                val daysAgo = maxOf(1, spec.plantDays - (c * perCheckIn))
                val date = now - daysAgo * dayMs
                val image = SamplePhoto.make(mood, 5000 + index * 100 + c)
                val profile = VisionService.colorProfile(image)
                db.checkInDao().insert(CheckIn(
                    plantId = plant.id, date = date, imageFilename = ImageStore.save(image), confidence = ConfidenceLevel.HIGH,
                    verified = true, vegetationDetected = true, greenRatio = profile.greenRatio, duplicateFlag = false,
                    healthAtCheckIn = spec.health, daysAwarded = perCheckIn,
                    note = "Strong, consistent vegetation signal across the frame.",
                ))
            }

            ensureCareQuest(plant, user.id)
            if (spec.health == HealthStatus.STRUGGLING) {
                db.questDao().upsert(Quest(
                    ownerId = user.id, type = QuestType.RECOVERY, title = "Plant Rescue, ${spec.name}",
                    detail = "${spec.name} is struggling. Follow the Plant Doctor's suggestions and verify improvement at your next check-in.",
                    target = 1, rewardXP = 80, relatedPlantID = plant.id,
                ))
            }
            totalMilestoneXP += GameEngine.SURVIVAL_MILESTONES.filter { spec.plantDays >= it.first }.sumOf { it.second }
        }

        val sightingsSeed = listOf(
            Triple("Painted Jezebel Butterfly", ObservationCategory.BUTTERFLY, VerificationStatus.COMMUNITY_CONFIRMED),
            Triple("Olive-backed Sunbird", ObservationCategory.BIRD, VerificationStatus.AI_SUGGESTED),
            Triple("Giant Honey Bee", ObservationCategory.BEE, VerificationStatus.EXPERT_VERIFIED),
            Triple("Common Scarlet Dragonfly", ObservationCategory.DRAGONFLY, VerificationStatus.AI_SUGGESTED),
        )
        sightingsSeed.forEachIndexed { i, (name, category, verification) ->
            val image = SamplePhoto.make(SamplePhoto.Mood.HEALTHY, 9000 + i * 61)
            db.sightingDao().insert(Sighting(
                ownerId = user.id, speciesName = name, category = category, imageFilename = ImageStore.save(image),
                verification = verification, neighbourhood = user.neighbourhood, date = now - (i * 6L + 2L) * dayMs,
            ))
        }

        seedStarterQuests(user.id)

        val totalXP = totalMilestoneXP + demoSpecs.size * GameEngine.REGISTRATION_XP + sightingsSeed.size * 15
        db.userProfileDao().upsert(GameEngine.award(user, totalXP))
        logXP(user.id, totalXP, "Welcome to ROOTED SG", "sparkles")

        val quests = db.questDao().getAll(user.id)
        quests.firstOrNull { it.type == QuestType.COMMUNITY && it.status == QuestStatus.ACTIVE }?.let {
            db.questDao().upsert(it.copy(progress = minOf(it.target, 13)))
        }
        quests.firstOrNull { it.type == QuestType.SCHOOL && it.status == QuestStatus.ACTIVE }?.let {
            db.questDao().upsert(it.copy(progress = minOf(it.target, 6)))
        }
    }

    private fun isSameDay(a: Long, b: Long): Boolean {
        val ca = Calendar.getInstance().apply { timeInMillis = a }
        val cb = Calendar.getInstance().apply { timeInMillis = b }
        return ca.get(Calendar.YEAR) == cb.get(Calendar.YEAR) && ca.get(Calendar.DAY_OF_YEAR) == cb.get(Calendar.DAY_OF_YEAR)
    }
}
