package sg.rooted.android.data

import android.graphics.Bitmap
import kotlinx.coroutines.flow.Flow
import sg.rooted.android.account.AccountService
import sg.rooted.android.engine.ExchangeEngine
import sg.rooted.android.engine.ImageStore
import sg.rooted.android.engine.ProducePhoto
import sg.rooted.android.model.*
import sg.rooted.android.network.BackendClient
import sg.rooted.android.network.Iso8601
import sg.rooted.android.network.ServiceError
import java.util.concurrent.TimeUnit
import kotlin.math.abs

/**
 * The Grower Exchange's mutation engine, plus the sync bridge to the real
 * backend and real chat — a Room-backed port of ExchangeEngine.swift,
 * MarketSyncEngine.swift and ChatService.swift combined. Local SwiftData-style
 * mutation becomes fetch-current / compute-next / re-persist, same as
 * GardenRepository.
 */
class MarketRepository(private val db: RootedDatabase, private val accountService: AccountService) {

    // MARK: - Listings & requests

    fun observeListings(): Flow<List<ProduceListing>> = db.produceListingDao().observeAll()
    fun observeListing(id: String): Flow<ProduceListing?> = db.produceListingDao().observeOne(id)
    fun observeRequests(): Flow<List<ProduceRequest>> = db.produceRequestDao().observeAll()
    fun observeExchanges(ownerId: String): Flow<List<Exchange>> = db.exchangeDao().observeAll(ownerId)

    suspend fun eligibility(user: UserProfile): ExchangeEngine.ListingEligibility {
        val plants = db.plantDao().getAll(user.id)
        val activeCount = plants.count { it.health != HealthStatus.DECEASED }
        val days = plants.sumOf { it.verifiedPlantDays }
        return ExchangeEngine.eligibility(activeCount, days)
    }

    suspend fun suggestionsFor(user: UserProfile): List<ProduceListing> {
        val requests = db.produceRequestDao().getAll().filter { it.ownerId == user.id && it.status == RequestStatus.OPEN }
        return ExchangeEngine.suggestions(requests, db.produceListingDao().getAll())
    }

    suspend fun householdsServed(user: UserProfile): Int =
        db.produceListingDao().getAll().filter { it.ownerId == user.id }.sumOf { it.claimedCount }

    suspend fun offerProduce(
        user: UserProfile, produce: ProduceKind, headline: String, detail: String, terms: ExchangeTerms,
        households: Int, bitmap: Bitmap?, quantityLabel: String = "", stockTotal: Int = 0,
        priceSGDCents: Int = 0, isSeedListing: Boolean = false,
    ): Boolean {
        val totalDays = db.plantDao().getAll(user.id).sumOf { it.verifiedPlantDays }
        val listing = ProduceListing(
            ownerId = user.id, produce = produce,
            headline = headline.ifBlank { "${produce.label} from my garden" },
            detail = detail, terms = terms,
            capacityHouseholds = minOf(ExchangeEngine.MAX_HOUSEHOLDS, maxOf(1, households)),
            neighbourhood = user.neighbourhood,
            growerId = if (user.isSignedIn) user.googleAccountId else user.id,
            growerName = user.name, growerAvatar = user.avatarEmoji, growerPlantDays = totalDays,
            imageFilename = bitmap?.let { ImageStore.save(it) },
            quantityLabel = quantityLabel, stockTotal = stockTotal, stockRemaining = stockTotal,
            priceSGDCents = if (terms == ExchangeTerms.SMALL_PAYMENT) priceSGDCents else 0,
            isSeedListing = isSeedListing,
        )
        db.produceListingDao().upsert(listing)
        if (user.isSignedIn) pushListing(listing, user)
        return true
    }

    suspend fun requestProduce(user: UserProfile, produce: ProduceKind, note: String): Boolean {
        val request = ProduceRequest(
            ownerId = user.id, produce = produce, note = note, neighbourhood = user.neighbourhood,
            requesterName = user.name, requesterAvatar = user.avatarEmoji,
            requesterId = if (user.isSignedIn) user.googleAccountId else user.id,
        )
        db.produceRequestDao().upsert(request)
        if (user.isSignedIn) pushRequest(request, user)
        return true
    }

    /** The existing thread about this listing, or a fresh local one. */
    suspend fun chatThreadFor(listing: ProduceListing, user: UserProfile): ChatThread {
        db.chatThreadDao().findByListing(user.id, listing.id)?.let { return it }
        val thread = ChatThread(
            ownerId = user.id, listingId = listing.id, listingHeadline = listing.headline, produce = listing.produce,
            otherPartyId = listing.growerId, otherPartyName = listing.growerName, otherPartyAvatar = listing.growerAvatar,
            isSeededOtherParty = listing.isSeeded,
        )
        db.chatThreadDao().upsert(thread)
        return thread
    }

    // MARK: - Claiming

    sealed class ClaimResult {
        data class Claimed(val exchange: Exchange) : ClaimResult()
        object Full : ClaimResult()
        object OwnListing : ClaimResult()
        object AlreadyClaimed : ClaimResult()
    }

    private fun applyReservation(listing: ProduceListing, units: Int): ProduceListing {
        var updated = listing.copy(claimedCount = listing.claimedCount + 1)
        if (updated.isStockTracked) updated = updated.copy(stockRemaining = maxOf(0, updated.stockRemaining - units))
        if (updated.spacesLeft == 0 || (updated.isStockTracked && updated.stockRemainingClamped == 0)) {
            updated = updated.copy(status = ListingStatus.FULL)
        }
        return updated
    }

    private fun revertReservation(listing: ProduceListing, units: Int): ProduceListing {
        var updated = listing.copy(claimedCount = maxOf(0, listing.claimedCount - 1))
        if (updated.isStockTracked) updated = updated.copy(stockRemaining = minOf(updated.stockTotal, updated.stockRemaining + units))
        val stockOK = !updated.isStockTracked || updated.stockRemainingClamped > 0
        if (updated.status == ListingStatus.FULL && updated.spacesLeft > 0 && stockOK) updated = updated.copy(status = ListingStatus.OPEN)
        return updated
    }

    private suspend fun reserve(
        listing: ProduceListing, user: UserProfile, note: String, kind: ExchangeKind, units: Int, reserveNow: Boolean,
    ): ClaimResult {
        if (listing.ownerId == user.id) return ClaimResult.OwnListing
        val existingExchanges = db.exchangeDao().getAll(user.id)
        if (existingExchanges.any { it.listingId == listing.id && it.status != ExchangeStatus.DECLINED }) return ClaimResult.AlreadyClaimed
        if (!listing.isAvailable) return ClaimResult.Full
        val boundedUnits = maxOf(1, units)
        if (reserveNow && listing.isStockTracked && listing.stockRemainingClamped < boundedUnits) return ClaimResult.Full

        val exchange = Exchange(
            ownerId = user.id, listingId = listing.id, produce = listing.produce, growerName = listing.growerName,
            takerName = user.name, neighbourhood = listing.neighbourhood, terms = listing.terms, kind = kind,
            units = boundedUnits, note = note, reservedSlot = reserveNow, userIsGrower = false,
        )
        db.exchangeDao().upsert(exchange)

        if (reserveNow) {
            db.produceListingDao().upsert(applyReservation(listing, boundedUnits))
            db.produceRequestDao().getAll()
                .filter { it.ownerId == user.id && it.produce == listing.produce && it.status == RequestStatus.OPEN }
                .forEach { db.produceRequestDao().upsert(it.copy(status = RequestStatus.MATCHED)) }
        }
        return ClaimResult.Claimed(exchange)
    }

    /** Accepts the listing exactly as posted — reserves a household space (and stock, if tracked) immediately. */
    suspend fun buy(listing: ProduceListing, user: UserProfile, note: String = "", units: Int = 1): ClaimResult =
        reserve(listing, user, note, ExchangeKind.BUY, units, reserveNow = true)

    /** Proposes different terms for the grower to review. Nothing is reserved until [acceptOffer]. */
    suspend fun proposeOffer(listing: ProduceListing, user: UserProfile, message: String, units: Int = 1): ClaimResult =
        reserve(listing, user, message, ExchangeKind.OFFER, units, reserveNow = false)

    suspend fun acceptOffer(exchange: Exchange): Boolean {
        if (exchange.kind != ExchangeKind.OFFER || exchange.reservedSlot) return false
        val listing = db.produceListingDao().get(exchange.listingId) ?: return false
        if (!listing.isAvailable || (listing.isStockTracked && listing.stockRemainingClamped < exchange.units)) return false
        db.produceListingDao().upsert(applyReservation(listing, exchange.units))
        db.exchangeDao().upsert(exchange.copy(reservedSlot = true))
        return true
    }

    suspend fun complete(exchange: Exchange): Boolean {
        db.exchangeDao().upsert(exchange.copy(status = ExchangeStatus.COMPLETED))
        return true
    }

    suspend fun cancel(exchange: Exchange): Boolean {
        if (exchange.status == ExchangeStatus.DECLINED) return true
        val wasReserved = exchange.reservedSlot
        db.exchangeDao().upsert(exchange.copy(status = ExchangeStatus.DECLINED, reservedSlot = false))
        if (wasReserved) {
            db.produceListingDao().get(exchange.listingId)?.let { db.produceListingDao().upsert(revertReservation(it, exchange.units)) }
        }
        return true
    }

    // MARK: - Seeding a live market

    suspend fun seedMarketIfNeeded() {
        if (db.produceListingDao().seededCount() > 0) return
        val now = System.currentTimeMillis()
        val dayMs = TimeUnit.DAYS.toMillis(1)
        ExchangeEngine.seedListings.forEachIndexed { index, seed ->
            val photo = ProducePhoto.make(seed.produce, 4200 + index * 71)
            var listing = ProduceListing(
                ownerId = "", produce = seed.produce, headline = seed.headline, detail = seed.detail, terms = seed.terms,
                capacityHouseholds = seed.households, neighbourhood = seed.neighbourhood,
                growerId = ExchangeEngine.seededGrowerId(seed.grower), growerName = seed.grower, growerAvatar = seed.avatar,
                growerPlantDays = seed.plantDays, imageFilename = ImageStore.save(photo), quantityLabel = seed.quantity,
                stockTotal = seed.stockTotal, priceSGDCents = seed.priceSGDCents, isSeedListing = seed.isSeeds,
                isSeeded = true, createdDate = now - seed.daysAgo * dayMs, claimedCount = seed.claimed,
            )
            if (seed.stockTotal > 0) listing = listing.copy(stockRemaining = seed.stockRemaining)
            if (listing.spacesLeft == 0 || (listing.isStockTracked && listing.stockRemainingClamped == 0)) {
                listing = listing.copy(status = ListingStatus.FULL)
            }
            db.produceListingDao().upsert(listing)
        }
        ExchangeEngine.seedRequests.forEach { seed ->
            db.produceRequestDao().upsert(ProduceRequest(
                ownerId = "", produce = seed.produce, note = seed.note, neighbourhood = seed.neighbourhood,
                requesterName = seed.name, requesterAvatar = "🧺", isSeeded = true, createdDate = now - seed.daysAgo * dayMs,
            ))
        }
    }

    // MARK: - Push — this device's own listings/requests, after a local change

    suspend fun pushListing(listing: ProduceListing, user: UserProfile) {
        if (!user.isSignedIn) return
        val token = accountService.state.value.sessionToken ?: return
        try {
            BackendClient.pushListing(
                id = listing.id, sessionToken = token, produce = listing.produce.wireValue, headline = listing.headline,
                detail = listing.detail, terms = listing.terms.wireValue, priceSGDCents = listing.priceSGDCents,
                capacityHouseholds = listing.capacityHouseholds, stockTotal = listing.stockTotal,
                quantityLabel = listing.quantityLabel, isSeedListing = listing.isSeedListing,
                neighbourhood = listing.neighbourhood, status = listing.status.name.lowercase(),
                ownerName = user.name, ownerAvatar = user.avatarEmoji,
                ownerPlantDays = db.plantDao().getAll(user.id).sumOf { it.verifiedPlantDays },
            )
            db.produceListingDao().upsert(listing.copy(isSynced = true))
        } catch (e: Exception) {
            // Stays local-only; the next explicit sync (or edit) tries again.
        }
    }

    suspend fun pushRequest(request: ProduceRequest, user: UserProfile) {
        if (!user.isSignedIn) return
        val token = accountService.state.value.sessionToken ?: return
        try {
            BackendClient.pushRequest(
                id = request.id, sessionToken = token, produce = request.produce.wireValue, note = request.note,
                neighbourhood = request.neighbourhood, status = request.status.name.lowercase(),
                requesterName = request.requesterName, requesterAvatar = request.requesterAvatar,
            )
            db.produceRequestDao().upsert(request.copy(isSynced = true))
        } catch (e: Exception) {
            // As above.
        }
    }

    // MARK: - Pull — what other real accounts have posted

    suspend fun pullListings(user: UserProfile): Int {
        if (!BackendClient.isConfigured) return 0
        return try {
            val remoteListings = BackendClient.fetchListings()
            val existing = db.produceListingDao().getAll().associateBy { it.id }
            var newCount = 0
            for (remote in remoteListings) {
                val local = existing[remote.id]
                if (local != null) {
                    // Only overwrite fields this device doesn't own the truth for.
                    if (local.growerId != accountService.state.value.accountId) {
                        db.produceListingDao().upsert(local.copy(
                            headline = remote.headline, detail = remote.detail,
                            terms = ExchangeTerms.fromWireValue(remote.terms), priceSGDCents = remote.priceSGDCents,
                            capacityHouseholds = remote.capacityHouseholds, claimedCount = remote.claimedCount,
                            stockTotal = remote.stockTotal, stockRemaining = remote.stockRemaining,
                            quantityLabel = remote.quantityLabel,
                            status = runCatching { ListingStatus.valueOf(remote.status.uppercase()) }.getOrDefault(ListingStatus.OPEN),
                            isSynced = true,
                        ))
                    }
                } else {
                    val kind = ProduceKind.fromWireValue(remote.produce)
                    val photo = ProducePhoto.make(kind, abs(remote.id.hashCode() % 1_000_000))
                    db.produceListingDao().upsert(ProduceListing(
                        id = remote.id, ownerId = "", produce = kind, headline = remote.headline, detail = remote.detail,
                        terms = ExchangeTerms.fromWireValue(remote.terms), capacityHouseholds = remote.capacityHouseholds,
                        claimedCount = remote.claimedCount, neighbourhood = remote.neighbourhood,
                        status = runCatching { ListingStatus.valueOf(remote.status.uppercase()) }.getOrDefault(ListingStatus.OPEN),
                        createdDate = Iso8601.parseToEpochMillis(remote.createdAt), isSeeded = false,
                        growerId = remote.ownerId, growerName = remote.ownerName, growerAvatar = remote.ownerAvatar,
                        growerPlantDays = remote.ownerPlantDays,
                        // A remote listing carries no photo (backend stores metadata only) — a
                        // deterministic local render stands in so the grid stays photo-forward.
                        imageFilename = ImageStore.save(photo), quantityLabel = remote.quantityLabel,
                        stockTotal = remote.stockTotal, stockRemaining = remote.stockRemaining,
                        priceSGDCents = remote.priceSGDCents, isSeedListing = remote.isSeedListing, isSynced = true,
                    ))
                    newCount++
                }
            }
            newCount
        } catch (e: Exception) { 0 }
    }

    suspend fun pullRequests(user: UserProfile): Int {
        if (!BackendClient.isConfigured) return 0
        return try {
            val remoteRequests = BackendClient.fetchRequests()
            val existingIds = db.produceRequestDao().getAllIds().toSet()
            var newCount = 0
            for (remote in remoteRequests) {
                if (remote.id in existingIds) continue
                db.produceRequestDao().upsert(ProduceRequest(
                    id = remote.id, ownerId = "", produce = ProduceKind.fromWireValue(remote.produce), note = remote.note,
                    neighbourhood = remote.neighbourhood,
                    status = runCatching { RequestStatus.valueOf(remote.status.uppercase()) }.getOrDefault(RequestStatus.OPEN),
                    createdDate = Iso8601.parseToEpochMillis(remote.createdAt), isSeeded = false,
                    requesterName = remote.requesterName, requesterAvatar = remote.requesterAvatar,
                    requesterId = remote.requesterId, isSynced = true,
                ))
                newCount++
            }
            newCount
        } catch (e: Exception) { 0 }
    }

    // MARK: - Claiming a synced listing — server-authoritative

    sealed class ClaimOutcome {
        data class Confirmed(val exchange: Exchange) : ClaimOutcome()
        data class Failed(val message: String) : ClaimOutcome()
    }

    /** Used instead of [buy] whenever the listing is synced and this device is signed in, so two
     * real accounts racing for the last space resolve on the server's one copy of the truth. */
    suspend fun confirmedBuy(listing: ProduceListing, units: Int, note: String, user: UserProfile): ClaimOutcome {
        val token = accountService.state.value.sessionToken
            ?: return ClaimOutcome.Failed("Sign in to buy from another account's listing.")
        return try {
            val remote = BackendClient.claimListing(listing.id, token, units)
            db.produceListingDao().upsert(listing.copy(
                claimedCount = remote.claimedCount, stockRemaining = remote.stockRemaining,
                status = runCatching { ListingStatus.valueOf(remote.status.uppercase()) }.getOrDefault(listing.status),
            ))
            val exchange = Exchange(
                ownerId = user.id, listingId = listing.id, produce = listing.produce, growerName = listing.growerName,
                takerName = user.name, neighbourhood = listing.neighbourhood, terms = listing.terms,
                kind = ExchangeKind.BUY, units = maxOf(1, units), note = note, reservedSlot = true, userIsGrower = false,
            )
            db.exchangeDao().upsert(exchange)
            ClaimOutcome.Confirmed(exchange)
        } catch (e: ServiceError) {
            ClaimOutcome.Failed(e.message ?: "That listing just filled up.")
        } catch (e: Exception) {
            ClaimOutcome.Failed("Couldn't reach the server. Check your connection and try again.")
        }
    }

    // MARK: - Chat — real, persisted messaging through the same backend

    fun observeChatThreads(ownerId: String): Flow<List<ChatThread>> = db.chatThreadDao().observeAll(ownerId)
    fun observeChatThread(id: String): Flow<ChatThread?> = db.chatThreadDao().observeOne(id)
    fun observeChatMessages(threadId: String): Flow<List<ChatMessage>> = db.chatMessageDao().observeForThread(threadId)

    sealed class SendResult {
        object Sent : SendResult()
        data class Failed(val message: String) : SendResult()
    }

    /** Ensures a backend conversation exists for this thread, creating one on first use. */
    suspend fun ensureConversation(thread: ChatThread, user: UserProfile): Result<ChatThread> {
        if (thread.remoteConversationId.isNotEmpty()) return Result.success(thread)
        val token = accountService.state.value.sessionToken
            ?: return Result.failure(ServiceError.NotSignedIn)
        val accountId = accountService.state.value.accountId ?: user.googleAccountId
        return try {
            val id = BackendClient.startConversation(
                listingId = thread.listingId, listingHeadline = thread.listingHeadline,
                growerId = thread.otherPartyId, growerName = thread.otherPartyName,
                takerId = accountId, takerName = user.name, sessionToken = token,
            )
            val updated = thread.copy(remoteConversationId = id)
            db.chatThreadDao().upsert(updated)
            Result.success(updated)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** Polls for messages newer than the thread's last known message; returns how many arrived. */
    suspend fun pollMessages(thread: ChatThread, initial: Boolean): Result<Int> {
        if (thread.remoteConversationId.isEmpty()) return Result.success(0)
        return try {
            val token = accountService.state.value.sessionToken ?: throw ServiceError.NotSignedIn
            val since = if (initial) null else thread.lastMessageDate
            val remote = BackendClient.fetchMessages(thread.remoteConversationId, token, since)
            if (remote.isEmpty()) return Result.success(0)
            val knownRemoteIds = db.chatMessageDao().getForThread(thread.id).map { it.remoteId }.filter { it.isNotEmpty() }.toSet()
            var count = 0
            var latestThread = thread
            for (message in remote) {
                if (message.id in knownRemoteIds) continue
                val mine = message.senderId == accountService.state.value.accountId
                val createdAt = Iso8601.parseToEpochMillis(message.createdAt)
                db.chatMessageDao().insert(ChatMessage(
                    threadId = thread.id, text = message.text, isMine = mine, senderName = message.senderName,
                    remoteId = message.id, createdDate = createdAt,
                ))
                latestThread = latestThread.copy(lastMessagePreview = message.text, lastMessageDate = createdAt)
                count++
            }
            if (count > 0) db.chatThreadDao().upsert(latestThread)
            Result.success(count)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** Sends one message, then (only for a seeded demo grower) a short, clearly-scripted local reply. */
    suspend fun sendChatMessage(thread: ChatThread, user: UserProfile, text: String): SendResult {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return SendResult.Failed("Message can't be empty.")

        var currentThread = thread
        if (currentThread.remoteConversationId.isEmpty()) {
            val ensured = ensureConversation(currentThread, user)
            if (ensured.isFailure) {
                return SendResult.Failed(friendlyMessage(ensured.exceptionOrNull()))
            }
            currentThread = ensured.getOrThrow()
        }

        return try {
            val token = accountService.state.value.sessionToken ?: throw ServiceError.NotSignedIn
            val sent = BackendClient.sendMessage(currentThread.remoteConversationId, token, user.name, trimmed)
            val createdAt = Iso8601.parseToEpochMillis(sent.createdAt)
            db.chatMessageDao().insert(ChatMessage(
                threadId = currentThread.id, text = sent.text, isMine = true, senderName = user.name,
                remoteId = sent.id, createdDate = createdAt,
            ))
            db.chatThreadDao().upsert(currentThread.copy(lastMessagePreview = sent.text, lastMessageDate = createdAt))

            if (currentThread.isSeededOtherParty) {
                val reply = SimulatedGrowerReply.line(currentThread.otherPartyName, currentThread.produce)
                db.chatMessageDao().insert(ChatMessage(
                    threadId = currentThread.id, text = reply, isMine = false,
                    senderName = currentThread.otherPartyName, isSimulated = true,
                ))
                db.chatThreadDao().upsert(currentThread.copy(lastMessagePreview = reply, lastMessageDate = System.currentTimeMillis()))
            }
            SendResult.Sent
        } catch (e: Exception) {
            SendResult.Failed(friendlyMessage(e))
        }
    }

    private fun friendlyMessage(e: Throwable?): String = when (e) {
        is ServiceError -> e.message ?: "Messaging is temporarily unavailable."
        null -> "Messaging is temporarily unavailable."
        else -> "Couldn't reach the messaging server. Check your connection and try again."
    }
}

/**
 * A short, honestly-scripted acknowledgement for the sample marketplace's
 * fictional growers — not AI, not a real person, just enough that trying the
 * chat feature solo doesn't dead-end on an empty thread.
 */
object SimulatedGrowerReply {
    private val templates = listOf(
        "Thanks for reaching out! Still around, happy to sort out pick-up.",
        "Hey! Yep, still have some %s going. When suits you?",
        "Hi there 🌱 I'll reply properly once I'm off work, pick-up's usually weekend mornings.",
        "Thanks! Message me a day ahead and I'll set some aside for you.",
    )

    fun line(growerName: String, produce: ProduceKind): String {
        val seed = growerName.sumOf { it.code }
        val template = templates[seed % templates.size]
        return if (template.contains("%s")) template.format(produce.label.lowercase()) else template
    }
}
