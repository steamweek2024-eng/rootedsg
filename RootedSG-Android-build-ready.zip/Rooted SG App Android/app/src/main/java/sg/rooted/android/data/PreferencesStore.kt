package sg.rooted.android.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "rooted_prefs")

/** DataStore-backed key-value store — this app's counterpart to iOS's UserDefaults use. */
class PreferencesStore(private val context: Context) {

    private object Keys {
        val THEME_ID = stringPreferencesKey("rooted.theme")
        val APPEARANCE_MODE = stringPreferencesKey("rooted.appearance")
        val HAS_SEEN_TUTORIAL = booleanPreferencesKey("rooted.hasSeenTutorial")
        val SESSION_TOKEN = stringPreferencesKey("rooted.account.session-token")
        val ACCOUNT_ID = stringPreferencesKey("rooted.account.id")
        val ACCOUNT_EMAIL = stringPreferencesKey("rooted.account.email")
        val ACCOUNT_NAME = stringPreferencesKey("rooted.account.display-name")
        val CLOUD_AI_OPT_IN_PREFIX = "rooted.cloud-ai-opt-in."

        // MARK: Mojo the carrot — companion pet state (kept here, not in Room, alongside
        // the theme/tutorial flags it's closest kin to).
        val PET_NAME = stringPreferencesKey("rooted.pet.name")
        val PET_NUDGES_ENABLED = booleanPreferencesKey("rooted.pet.nudges-enabled")
        val PET_LAST_NUDGE_MS = longPreferencesKey("rooted.pet.last-nudge-ms")
        val APP_LAST_OPEN_MS = longPreferencesKey("rooted.app.last-open-ms")
    }

    val themeId: Flow<String?> = context.dataStore.data.map { it[Keys.THEME_ID] }
    val appearanceMode: Flow<String?> = context.dataStore.data.map { it[Keys.APPEARANCE_MODE] }
    val hasSeenTutorial: Flow<Boolean> = context.dataStore.data.map { it[Keys.HAS_SEEN_TUTORIAL] ?: false }

    suspend fun setThemeId(id: String) = context.dataStore.edit { it[Keys.THEME_ID] = id }
    suspend fun setAppearanceMode(mode: String) = context.dataStore.edit { it[Keys.APPEARANCE_MODE] = mode }
    suspend fun setHasSeenTutorial(seen: Boolean) = context.dataStore.edit { it[Keys.HAS_SEEN_TUTORIAL] = seen }

    // MARK: Mojo the carrot

    val petName: Flow<String> = context.dataStore.data.map { it[Keys.PET_NAME] ?: "Mojo" }
    val petNudgesEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.PET_NUDGES_ENABLED] ?: true }

    suspend fun setPetName(name: String) = context.dataStore.edit {
        it[Keys.PET_NAME] = name.trim().ifBlank { "Mojo" }
    }
    suspend fun setPetNudgesEnabled(enabled: Boolean) = context.dataStore.edit { it[Keys.PET_NUDGES_ENABLED] = enabled }

    /** One-shot reads for the background nudge worker — no need to hold a Flow open there. */
    suspend fun petNudgesEnabledNow(): Boolean = context.dataStore.data.first()[Keys.PET_NUDGES_ENABLED] ?: true
    suspend fun hasSeenTutorialNow(): Boolean = context.dataStore.data.first()[Keys.HAS_SEEN_TUTORIAL] ?: false
    suspend fun petNameNow(): String = context.dataStore.data.first()[Keys.PET_NAME] ?: "Mojo"
    suspend fun petLastNudgeMs(): Long = context.dataStore.data.first()[Keys.PET_LAST_NUDGE_MS] ?: 0L
    suspend fun setPetLastNudgeMs(ms: Long) = context.dataStore.edit { it[Keys.PET_LAST_NUDGE_MS] = ms }
    suspend fun appLastOpenMs(): Long = context.dataStore.data.first()[Keys.APP_LAST_OPEN_MS] ?: 0L
    suspend fun setAppLastOpenMs(ms: Long) = context.dataStore.edit { it[Keys.APP_LAST_OPEN_MS] = ms }

    // MARK: Account session

    data class StoredSession(val sessionToken: String, val accountId: String, val email: String, val name: String)

    suspend fun storedSession(): StoredSession? {
        val prefs = context.dataStore.data.first()
        val token = prefs[Keys.SESSION_TOKEN] ?: return null
        val id = prefs[Keys.ACCOUNT_ID] ?: return null
        return StoredSession(token, id, prefs[Keys.ACCOUNT_EMAIL] ?: "", prefs[Keys.ACCOUNT_NAME] ?: "")
    }

    suspend fun saveSession(session: StoredSession) = context.dataStore.edit {
        it[Keys.SESSION_TOKEN] = session.sessionToken
        it[Keys.ACCOUNT_ID] = session.accountId
        it[Keys.ACCOUNT_EMAIL] = session.email
        it[Keys.ACCOUNT_NAME] = session.name
    }

    suspend fun clearSession() = context.dataStore.edit {
        it.remove(Keys.SESSION_TOKEN)
        it.remove(Keys.ACCOUNT_ID)
        it.remove(Keys.ACCOUNT_EMAIL)
        it.remove(Keys.ACCOUNT_NAME)
    }

    // MARK: Cloud AI opt-in, per local user id

    suspend fun isCloudAIOptedIn(userId: String): Boolean {
        val key = booleanPreferencesKey(Keys.CLOUD_AI_OPT_IN_PREFIX + userId)
        return context.dataStore.data.first()[key] ?: false
    }

    suspend fun setCloudAIOptIn(userId: String, enabled: Boolean) {
        val key = booleanPreferencesKey(Keys.CLOUD_AI_OPT_IN_PREFIX + userId)
        context.dataStore.edit { it[key] = enabled }
    }
}
