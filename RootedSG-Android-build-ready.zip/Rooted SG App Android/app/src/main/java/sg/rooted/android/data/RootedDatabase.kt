package sg.rooted.android.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import sg.rooted.android.model.*

@Database(
    entities = [
        UserProfile::class, Plant::class, CheckIn::class, Quest::class, Sighting::class,
        ProduceListing::class, ProduceRequest::class, Exchange::class,
        ChatThread::class, ChatMessage::class, XPEvent::class, DiagnosisSession::class,
    ],
    version = 4,
    exportSchema = false,
)
@TypeConverters(Converters::class)
abstract class RootedDatabase : RoomDatabase() {
    abstract fun userProfileDao(): UserProfileDao
    abstract fun plantDao(): PlantDao
    abstract fun checkInDao(): CheckInDao
    abstract fun questDao(): QuestDao
    abstract fun diagnosisSessionDao(): DiagnosisSessionDao
    abstract fun sightingDao(): SightingDao
    abstract fun xpEventDao(): XPEventDao
    abstract fun produceListingDao(): ProduceListingDao
    abstract fun produceRequestDao(): ProduceRequestDao
    abstract fun exchangeDao(): ExchangeDao
    abstract fun chatThreadDao(): ChatThreadDao
    abstract fun chatMessageDao(): ChatMessageDao

    companion object {

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE plants ADD COLUMN healthScore INTEGER NOT NULL DEFAULT 88")
                db.execSQL("ALTER TABLE plants ADD COLUMN rescueBaselineHealthScore INTEGER")
                db.execSQL("ALTER TABLE check_ins ADD COLUMN healthScoreAtCheckIn INTEGER NOT NULL DEFAULT 88")
                db.execSQL("ALTER TABLE quests ADD COLUMN objectivesRaw TEXT NOT NULL DEFAULT '[]'")
                db.execSQL("ALTER TABLE quests ADD COLUMN baselineHealthScore INTEGER")
                db.execSQL("ALTER TABLE quests ADD COLUMN requiresRecheck INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE quests ADD COLUMN bossName TEXT NOT NULL DEFAULT ''")
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS diagnosis_sessions (
                        id TEXT NOT NULL PRIMARY KEY,
                        ownerId TEXT NOT NULL,
                        plantId TEXT NOT NULL,
                        createdDate INTEGER NOT NULL,
                        updatedDate INTEGER NOT NULL,
                        status TEXT NOT NULL,
                        source TEXT NOT NULL,
                        headline TEXT NOT NULL,
                        cluesRaw TEXT NOT NULL,
                        choicesRaw TEXT NOT NULL,
                        likelyCause TEXT NOT NULL,
                        userChoice TEXT NOT NULL,
                        nextAction TEXT NOT NULL,
                        observeNext TEXT NOT NULL,
                        weatherContext TEXT NOT NULL,
                        baselineHealthScore INTEGER NOT NULL,
                        recheckHealthScore INTEGER,
                        diagnosisXP INTEGER NOT NULL,
                        treatmentQuestId TEXT,
                        completedDate INTEGER
                    )
                    """.trimIndent()
                )
            }
        }
        @Volatile private var instance: RootedDatabase? = null

        fun get(context: Context): RootedDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext, RootedDatabase::class.java, "rooted.db"
            )
                .addMigrations(MIGRATION_3_4)
                // Ancient internal test builds (v1/v2) never shipped publicly.
                // Preserve all real v3 installs; only those obsolete schemas may reset.
                .fallbackToDestructiveMigrationFrom(1, 2)
                .build().also { instance = it }
        }
    }
}
