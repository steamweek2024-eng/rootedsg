package sg.rooted.android.engine

import sg.rooted.android.model.DiagnosisSession
import sg.rooted.android.model.Plant
import sg.rooted.android.model.Quest
import sg.rooted.android.model.QuestStatus
import sg.rooted.android.model.QuestType
import sg.rooted.android.model.UserProfile

/**
 * Achievements are derived entirely from persisted care behaviour. Opening the
 * app cannot unlock one; a user has to care, diagnose, recover or sustain real
 * plants. That keeps the reward layer aligned with ROOTED's trust model.
 */
data class Achievement(
    val id: String,
    val emoji: String,
    val title: String,
    val detail: String,
    val progress: Int,
    val target: Int,
) {
    val unlocked: Boolean get() = progress >= target
    val fraction: Float get() = (progress.toFloat() / target.coerceAtLeast(1)).coerceIn(0f, 1f)
}

object AchievementEngine {
    fun evaluate(
        user: UserProfile?,
        plants: List<Plant>,
        quests: List<Quest>,
        sessions: List<DiagnosisSession>,
    ): List<Achievement> {
        val completedRescues = quests.count { it.type == QuestType.RECOVERY && it.status == QuestStatus.COMPLETED }
        val detectiveCount = sessions.count { it.diagnosisXP > 0 }
        val wateringReads = sessions.count { s ->
            s.diagnosisXP >= 150 &&
                s.userChoice.contains("water", ignoreCase = true) &&
                s.likelyCause.contains("water", ignoreCase = true)
        }
        val thriving = plants.count { it.healthScore >= 90 }
        val recoveries = plants.count { it.hadRecoveryEvent }
        val bestStreak = plants.maxOfOrNull { it.careStreak } ?: 0
        val level = user?.level ?: 1

        return listOf(
            Achievement("first_rescue", "🏅", "First Rescue", "Bring a struggling plant back after completing its treatment quest.", completedRescues, 1),
            Achievement("water_whisperer", "💧", "Water Whisperer", "Match ROOTED's watering diagnosis 10 times.", wateringReads, 10),
            Achievement("plant_detective", "🔍", "Plant Detective", "Complete 25 plant investigations.", detectiveCount, 25),
            Achievement("green_thumb", "🌱", "Green Thumb", "Keep 5 plants at 90+ health.", thriving, 5),
            Achievement("comeback_king", "🔥", "Comeback King", "Complete a verified recovery from a rescue baseline.", recoveries, 1),
            Achievement("streak_keeper", "📆", "Streak Keeper", "Reach a 7-check-in care streak on one plant.", bestStreak, 7),
            Achievement("guardian_ten", "✨", "Plant Guardian", "Reach Guardian Level 10.", level, 10),
        )
    }
}
