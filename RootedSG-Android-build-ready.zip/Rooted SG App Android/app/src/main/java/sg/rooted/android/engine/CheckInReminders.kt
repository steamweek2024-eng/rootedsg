package sg.rooted.android.engine

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import sg.rooted.android.MainActivity
import sg.rooted.android.data.RootedDatabase
import sg.rooted.android.model.HealthStatus
import sg.rooted.android.model.Plant
import java.util.concurrent.TimeUnit

/**
 * Local check-in reminders — a port of CheckInReminders.swift. No server, no
 * push infrastructure: one scheduled WorkManager job per plant, always
 * exactly 7 days after its last verified activity, replaced every time that
 * activity happens again. Never nags about a plant that's already current.
 */
object CheckInReminders {
    private const val CHANNEL_ID = "checkin_reminders"
    const val EXTRA_PLANT_ID = "sg.rooted.android.EXTRA_PLANT_ID"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Check-in reminders", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "A nudge when a plant is due for its weekly verified check-in."
            },
        )
    }

    private fun workName(plantId: String) = "checkin-reminder-$plantId"

    /** Schedules (replacing any existing one) a reminder 7 days from this plant's most recent activity. */
    fun schedule(context: Context, plant: Plant) {
        val manager = WorkManager.getInstance(context)
        if (plant.health == HealthStatus.DECEASED) {
            manager.cancelUniqueWork(workName(plant.id))
            return
        }
        val lastActivity = plant.lastCheckInDate ?: plant.registeredDate
        val fireAt = lastActivity + TimeUnit.DAYS.toMillis(7)
        // A plant already overdue when this schedules fires almost immediately
        // rather than never, mirroring the iOS behaviour.
        val delayMs = (fireAt - System.currentTimeMillis()).coerceAtLeast(TimeUnit.MINUTES.toMillis(1))

        val request = OneTimeWorkRequestBuilder<CheckInReminderWorker>()
            .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf(CheckInReminderWorker.KEY_PLANT_ID to plant.id))
            .setConstraints(Constraints.NONE)
            .build()
        manager.enqueueUniqueWork(workName(plant.id), ExistingWorkPolicy.REPLACE, request)
    }

    fun cancel(context: Context, plantId: String) {
        WorkManager.getInstance(context).cancelUniqueWork(workName(plantId))
    }
}

/** Fires at the scheduled time; re-checks the plant is genuinely still due before notifying. */
class CheckInReminderWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    companion object { const val KEY_PLANT_ID = "plantId" }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val plantId = inputData.getString(KEY_PLANT_ID) ?: return@withContext Result.failure()
        val plant = RootedDatabase.get(applicationContext).plantDao().get(plantId) ?: return@withContext Result.success()
        if (!plant.isCheckInDue() || plant.health == HealthStatus.DECEASED) return@withContext Result.success()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ActivityCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            return@withContext Result.success()
        }

        CheckInReminders.ensureChannel(applicationContext)
        val openIntent = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(CheckInReminders.EXTRA_PLANT_ID, plant.id)
        }
        val pendingIntent = PendingIntent.getActivity(
            applicationContext, plant.id.hashCode(), openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val notification = NotificationCompat.Builder(applicationContext, "checkin_reminders")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("${plant.name} is due for a check-in")
            .setContentText("It's been a week, a quick verified photo keeps ${plant.name}'s streak alive.")
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        applicationContext.getSystemService(NotificationManager::class.java)?.notify(plant.id.hashCode(), notification)
        Result.success()
    }
}
