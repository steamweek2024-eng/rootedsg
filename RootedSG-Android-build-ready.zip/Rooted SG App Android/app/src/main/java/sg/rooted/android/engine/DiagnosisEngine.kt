package sg.rooted.android.engine

import sg.rooted.android.model.DiagnosisChoice
import sg.rooted.android.model.DiagnosisClue
import sg.rooted.android.model.HealthStatus
import sg.rooted.android.model.QuestObjective
import kotlin.math.roundToInt

/**
 * Deterministic, cautious on-device reasoning used whenever cloud AI is absent.
 * It never invents object-level visual claims ("three lower leaves", "mites")
 * that the colour heuristic cannot actually see. Cloud evidence can enrich the
 * copy, but ROOTED's treatment guardrails remain the same.
 */
object DiagnosisEngine {
    data class Draft(
        val headline: String,
        val clues: List<DiagnosisClue>,
        val choices: List<DiagnosisChoice>,
        val likelyCause: String,
        val nextAction: String,
        val observeNext: String,
        val healthScore: Int,
        val health: HealthStatus,
    )

    val defaultChoices = listOf(
        DiagnosisChoice("Overwatering", "💧", "Roots staying wet for too long can cause yellowing and weak growth."),
        DiagnosisChoice("Not enough light", "☀️", "Low usable light can reduce vigorous green growth."),
        DiagnosisChoice("Nutrient / soil stress", "🧪", "Root-zone or nutrient imbalance can show as general colour stress."),
        DiagnosisChoice("Pest / disease stress", "🐛", "Leaf damage can sometimes come from pests or disease; confirm by inspecting the plant."),
    )

    fun analyse(
        profile: VisionService.ColorProfile,
        verification: VisionService.VerificationResult,
        previousHealthScore: Int,
        weather: WeatherService.CareAdvisory?,
    ): Draft {
        if (!verification.vegetationDetected || verification.confidence == sg.rooted.android.model.ConfidenceLevel.LOW) {
            return Draft(
                headline = "We need a clearer plant photo",
                clues = listOf(
                    DiagnosisClue("📸", "Plant coverage is too uncertain", verification.summary, 0.95),
                    DiagnosisClue("💡", "Retake in even daylight", "Fill most of the frame with leaves and stems without harsh backlight.", 0.9),
                ),
                choices = defaultChoices,
                likelyCause = "Photo quality is too low to make a useful care read",
                nextAction = "Retake the photo in bright, even light with the plant filling most of the frame.",
                observeNext = "Look for clear leaves, stems and any visible discolouration or damage.",
                healthScore = previousHealthScore,
                health = healthFromScore(previousHealthScore),
            )
        }

        val observationScore = observationHealthScore(profile)
        val healthScore = (previousHealthScore * 0.45 + observationScore * 0.55).roundToInt().coerceIn(20, 98)
        val health = healthFromScore(healthScore)
        val clues = mutableListOf<DiagnosisClue>()

        val yellowPct = (profile.yellowBrownRatio * 100).roundToInt()
        val greenPct = (profile.greenRatio * 100).roundToInt()
        if (profile.yellowBrownRatio >= 0.13) {
            clues += DiagnosisClue("🍂", "Colour stress detected", "About $yellowPct% of sampled pixels fall into ROOTED's yellow/brown stress range.", 0.74)
        } else {
            clues += DiagnosisClue("🍃", "Green signal is holding", "The photo has about $greenPct% strong green coverage with limited yellow/brown signal.", 0.7)
        }

        if (profile.averageBrightness < 0.18) {
            clues += DiagnosisClue("☀️", "The scene is quite dark", "Low image brightness makes light stress plausible, though the room lighting can also affect this clue.", 0.58)
        } else if (profile.averageBrightness > 0.90) {
            clues += DiagnosisClue("🌤️", "Very bright exposure", "Harsh exposure can hide leaf detail. Check whether the plant is receiving intense direct sun.", 0.46)
        } else {
            clues += DiagnosisClue("🔎", "Usable photo exposure", "Lighting is clear enough for a more reliable colour comparison.", 0.72)
        }

        weather?.let { w ->
            when {
                (w.localRainfallMm ?: 0.0) > 0.0 || (w.localHumidityPercent ?: 0.0) >= 86 ->
                    clues += DiagnosisClue("💧", "Drying conditions are slow nearby", "${w.locationLabel}: ${w.careContext}. Wet weather makes overwatering more plausible for outdoor or exposed pots.", 0.7)
                (w.uvIndex ?: 0) >= 8 || (w.temperatureHigh ?: 0) >= 34 ->
                    clues += DiagnosisClue("🔥", "Singapore heat/light pressure", "${w.careContext}. Warm, high-UV conditions can make pots dry faster and stress sensitive leaves.", 0.68)
                else ->
                    clues += DiagnosisClue("🌦️", "Weather is not the strongest clue", "${w.careContext}. Prioritise soil moisture, light and visible leaf changes.", 0.58)
            }
        }

        val likely = likelyCause(profile, weather)
        val choices = if (likely.startsWith("No strong", ignoreCase = true)) {
            listOf(DiagnosisChoice("No strong problem detected", "🌿", "The current photo does not show a strong stress pattern.")) + defaultChoices.take(3)
        } else defaultChoices
        val (nextAction, observeNext) = actionsFor(likely)
        val headline = when (health) {
            HealthStatus.HEALTHY -> "${healthScore}/100 — mostly healthy signals"
            HealthStatus.RECOVERING -> "${healthScore}/100 — mild stress worth watching"
            HealthStatus.STRUGGLING -> "${healthScore}/100 — your plant needs a care check"
            HealthStatus.AT_RISK -> "${healthScore}/100 — stronger stress signals detected"
            HealthStatus.DECEASED -> "Plant condition uncertain"
        }
        return Draft(headline, clues.take(4), choices, likely, nextAction, observeNext, healthScore, health)
    }

    fun treatmentObjectives(cause: String, observeNext: String): List<QuestObjective> {
        val c = cause.lowercase()
        return when {
            "overwater" in c || "wet" in c || "root rot" in c -> listOf(
                QuestObjective(title = "Pause watering", detail = "Wait until the top few centimetres of soil are no longer wet before watering again.", icon = "💧"),
                QuestObjective(title = "Check drainage", detail = "Make sure excess water can leave the pot and is not sitting in a saucer.", icon = "🪴"),
                QuestObjective(title = "Give bright indirect light", detail = "Use brighter indirect light and airflow to support drying without scorching stressed leaves.", icon = "☀️"),
                QuestObjective(title = "Recheck visible change", detail = observeNext, icon = "🔍"),
            )
            "light" in c -> listOf(
                QuestObjective(title = "Move to brighter indirect light", detail = "Increase usable daylight gradually; avoid an abrupt jump into harsh afternoon sun.", icon = "☀️"),
                QuestObjective(title = "Rotate the pot", detail = "Turn the plant so growth is exposed more evenly to the light source.", icon = "🪴"),
                QuestObjective(title = "Watch new growth", detail = observeNext, icon = "🌱"),
            )
            "pest" in c || "disease" in c || "fung" in c -> listOf(
                QuestObjective(title = "Inspect both sides of leaves", detail = "Look closely for insects, webbing, sticky residue, powder or expanding spots before treating.", icon = "🔍"),
                QuestObjective(title = "Separate if suspicious", detail = "Temporarily isolate the plant from nearby plants if you find signs that could spread.", icon = "↔️"),
                QuestObjective(title = "Remove badly damaged debris", detail = "Clear fallen or dead material with clean tools; avoid aggressive pruning of healthy tissue.", icon = "🍂"),
                QuestObjective(title = "Recheck the same symptoms", detail = observeNext, icon = "📸"),
            )
            "nutrient" in c || "soil" in c -> listOf(
                QuestObjective(title = "Check moisture first", detail = "Rule out very wet or very dry soil before adding fertiliser; watering problems can mimic nutrient stress.", icon = "💧"),
                QuestObjective(title = "Review recent feeding", detail = "Avoid doubling fertiliser. Follow the product label and the species' normal feeding needs.", icon = "🧪"),
                QuestObjective(title = "Observe new leaves", detail = observeNext, icon = "🌱"),
            )
            else -> listOf(
                QuestObjective(title = "Check soil moisture", detail = "Feel the root zone before deciding whether to water.", icon = "💧"),
                QuestObjective(title = "Check light and leaves", detail = "Confirm the plant has suitable light and inspect leaves for visible damage.", icon = "🔍"),
                QuestObjective(title = "Recheck in a few days", detail = observeNext, icon = "📸"),
            )
        }
    }

    fun bossName(cause: String): String = when {
        "overwater" in cause.lowercase() || "root" in cause.lowercase() -> "Drowned Roots"
        "pest" in cause.lowercase() -> "The Infestation"
        "fung" in cause.lowercase() || "disease" in cause.lowercase() -> "Spore Storm"
        "light" in cause.lowercase() -> "The Long Shadow"
        "nutrient" in cause.lowercase() || "soil" in cause.lowercase() -> "Hungry Soil"
        else -> "Plant Rescue"
    }

    fun observationHealthScore(profile: VisionService.ColorProfile): Int {
        var score = 96.0
        score -= profile.yellowBrownRatio * 155.0
        if (profile.greenRatio < 0.08) score -= (0.08 - profile.greenRatio) * 180.0
        if (profile.averageBrightness < 0.12) score -= 12.0
        if (profile.averageBrightness > 0.95) score -= 7.0
        return score.roundToInt().coerceIn(25, 98)
    }

    fun healthFromScore(score: Int): HealthStatus = when {
        score >= 80 -> HealthStatus.HEALTHY
        score >= 62 -> HealthStatus.RECOVERING
        score >= 40 -> HealthStatus.STRUGGLING
        else -> HealthStatus.AT_RISK
    }

    private fun likelyCause(profile: VisionService.ColorProfile, weather: WeatherService.CareAdvisory?): String {
        val wet = (weather?.localRainfallMm ?: 0.0) > 0.0 || (weather?.localHumidityPercent ?: 0.0) >= 86
        val hot = (weather?.uvIndex ?: 0) >= 8 || (weather?.temperatureHigh ?: 0) >= 34
        return when {
            profile.yellowBrownRatio >= 0.18 && wet -> "Overwatering / slow-drying soil"
            profile.averageBrightness < 0.18 -> "Not enough usable light"
            profile.yellowBrownRatio >= 0.18 && hot -> "Water / heat stress"
            profile.yellowBrownRatio >= 0.15 -> "Nutrient or root-zone stress"
            profile.greenRatio >= 0.16 -> "No strong problem detected"
            else -> "General environmental stress"
        }
    }

    private fun actionsFor(cause: String): Pair<String, String> {
        val c = cause.lowercase()
        return when {
            "overwater" in c || "slow-drying" in c ->
                "Let the soil dry before watering again, check drainage, and keep the plant in bright indirect light." to
                    "Look for firmer leaves, stable colour and soil that dries at a normal pace."
            "light" in c ->
                "Move the plant gradually toward brighter indirect light and avoid a sudden jump into harsh direct sun." to
                    "Watch whether new growth is less stretched and holds stronger green colour."
            "water / heat" in c ->
                "Check soil moisture and shelter stressed leaves from the harshest afternoon light; water only if the root zone is actually dry." to
                    "Look for leaf firmness and whether browning stops spreading."
            "nutrient" in c || "root-zone" in c ->
                "Check moisture and drainage first, then review the species' feeding routine instead of adding extra fertiliser immediately." to
                    "Watch new leaves for healthier colour and check that existing yellowing is not spreading quickly."
            "no strong" in c ->
                "Keep the current routine and use the next photo as a comparison point." to
                    "Watch for new growth and stable leaf colour."
            else ->
                "Inspect soil moisture, light exposure and both sides of the leaves before changing care." to
                    "Recheck the same visible symptoms in a few days."
        }
    }
}
