package sg.rooted.android.engine

import sg.rooted.android.model.ExchangeTerms
import sg.rooted.android.model.ProduceKind
import sg.rooted.android.model.ProduceListing
import sg.rooted.android.model.ProduceRequest
import java.text.Normalizer
import kotlin.random.Random

/**
 * Rules of the Grower Exchange, and the seeded demo market — a direct port of
 * the stateless parts of ExchangeEngine.swift. The stateful parts (buy/offer/
 * accept/cancel, which need database access) live in RootedRepository.
 */
object ExchangeEngine {

    /** Verified Plant-Days a grower needs before they can offer produce. */
    const val PLANT_DAYS_TO_LIST = 30

    /** The most households one listing may serve, so nobody signs up for a farm. */
    const val MAX_HOUSEHOLDS = 8

    sealed class ListingEligibility {
        object Eligible : ListingEligibility()
        object NeedsAPlant : ListingEligibility()
        data class NeedsMorePlantDays(val have: Int, val need: Int) : ListingEligibility()

        val isEligible: Boolean get() = this is Eligible

        val explanation: String
            get() = when (this) {
                is Eligible -> "You can offer produce to neighbours."
                is NeedsAPlant -> "Register and verify a plant before offering produce."
                is NeedsMorePlantDays -> "${need - have} more Verified Plant-Days before you can offer produce."
            }
    }

    fun eligibility(activePlantCount: Int, totalVerifiedPlantDays: Int): ListingEligibility {
        if (activePlantCount == 0) return ListingEligibility.NeedsAPlant
        return if (totalVerifiedPlantDays >= PLANT_DAYS_TO_LIST) ListingEligibility.Eligible
        else ListingEligibility.NeedsMorePlantDays(totalVerifiedPlantDays, PLANT_DAYS_TO_LIST)
    }

    fun score(listing: ProduceListing, request: ProduceRequest): Double {
        if (listing.produce != request.produce || !listing.isAvailable) return 0.0
        var score = 1.0
        if (listing.neighbourhood == request.neighbourhood) score += 1.5
        score += minOf(1.0, listing.growerPlantDays / 400.0)
        score += minOf(0.5, listing.spacesLeft / 8.0)
        return score
    }

    fun matches(request: ProduceRequest, listings: List<ProduceListing>): List<ProduceListing> =
        listings.map { it to score(it, request) }.filter { it.second > 0 }.sortedByDescending { it.second }.map { it.first }

    fun suggestions(openRequests: List<ProduceRequest>, listings: List<ProduceListing>): List<ProduceListing> {
        if (openRequests.isEmpty()) return emptyList()
        val seen = mutableSetOf<String>()
        val out = mutableListOf<ProduceListing>()
        for (request in openRequests) {
            for (listing in matches(request, listings)) {
                if (seen.add(listing.id)) out.add(listing)
            }
        }
        return out
    }

    /** A stable, deterministic id for a seeded grower — the same name always resolves to the same slug. */
    fun seededGrowerId(name: String): String {
        val normalized = Normalizer.normalize(name.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}"), "")
        return "seed-" + normalized.filter { it.isLetterOrDigit() }
    }

    /** Singapore imports the large majority of what it eats; national goal is 30% local by 2030. */
    const val IMPORT_DEPENDENCE_NOTE =
        "Singapore grows under 10% of what it eats. Every household plot counts toward the 30-by-30 goal."

    // MARK: - Seed data (a live-feeling market on first open)

    data class SeedListing(
        val produce: ProduceKind, val headline: String, val detail: String, val terms: ExchangeTerms,
        val households: Int, val claimed: Int, val neighbourhood: String, val grower: String, val avatar: String,
        val plantDays: Int, val daysAgo: Int, val quantity: String, val isSeeds: Boolean = false,
        val stockTotal: Int = 0, val stockRemaining: Int = 0, val priceSGDCents: Int = 0,
    )

    val seedListings: List<SeedListing> = listOf(
        SeedListing(ProduceKind.TOMATO, "Cherry tomatoes off the corridor rack",
            "Pick-up from my block on weekend mornings. Bring your own bag.", ExchangeTerms.FREE,
            4, 2, "Tampines", "Wei Ling", "🍅", 421, 2, "About 300g a week", stockTotal = 7, stockRemaining = 4),
        SeedListing(ProduceKind.CHILLI, "Chilli padi, more than we can eat",
            "Small handful each, roughly fortnightly while the plant keeps fruiting.", ExchangeTerms.SWAP,
            3, 1, "Tampines", "Arun", "🌶️", 268, 5, "A handful, fortnightly", stockTotal = 20, stockRemaining = 13),
        SeedListing(ProduceKind.PANDAN, "Pandan leaves, cut fresh",
            "Whole leaves for cooking. Message a day ahead.", ExchangeTerms.FREE,
            6, 4, "Bedok", "Mdm Chua", "🌾", 693, 8, "6–8 leaves", stockTotal = 8, stockRemaining = 2),
        SeedListing(ProduceKind.KANGKONG, "Kangkong from the balcony trough",
            "Cut-and-come-again, so there's usually a bunch spare.", ExchangeTerms.SMALL_PAYMENT,
            5, 1, "Punggol", "Siti", "🥬", 154, 1, "1 bunch", priceSGDCents = 150),
        SeedListing(ProduceKind.BASIL, "Thai basil, plenty of it",
            "Happy to keep a pot going for someone who cooks with it.", ExchangeTerms.FREE,
            3, 0, "Jurong East", "Daniel", "🌿", 97, 3, "A small bunch"),
        SeedListing(ProduceKind.MINT, "Mint, it has taken over",
            "Genuinely please take some.", ExchangeTerms.FREE,
            8, 3, "Woodlands", "Priya", "🌱", 212, 12, "As much as you want"),
        SeedListing(ProduceKind.LADIES_FINGER, "Ladies' finger, a few pods a week",
            "Best picked young, I'll message when they're ready.", ExchangeTerms.SMALL_PAYMENT,
            2, 0, "Bedok", "Hafiz", "🫛", 331, 6, "8–10 pods", priceSGDCents = 200),
        SeedListing(ProduceKind.CURRY_LEAF, "Curry leaf from a well-established tree",
            "Cuttings available too if you'd rather grow your own.", ExchangeTerms.FREE,
            5, 2, "Toa Payoh", "Mr Raj", "🍃", 884, 15, "A sprig, plus cuttings"),
        SeedListing(ProduceKind.TOMATO, "Cherry tomato seeds, saved from this season",
            "Open-pollinated, so they'll grow true. Sow indoors, then pot on.", ExchangeTerms.FREE,
            6, 1, "Jurong East", "Daniel", "🍅", 97, 4, "~15 seeds per packet", isSeeds = true),
        SeedListing(ProduceKind.CHILLI, "Chilli padi seeds, dried and cleaned",
            "From a plant that's been reliably productive for two seasons.", ExchangeTerms.SWAP,
            5, 0, "Bedok", "Hafiz", "🌶️", 331, 9, "~20 seeds per packet", isSeeds = true),
        SeedListing(ProduceKind.BASIL, "Thai basil cuttings, already rooting",
            "Rooted in water, just pot them straight into soil.", ExchangeTerms.FREE,
            4, 2, "Woodlands", "Priya", "🌿", 212, 6, "3 cuttings", isSeeds = true),
    )

    data class SeedRequest(val produce: ProduceKind, val note: String, val neighbourhood: String, val name: String, val daysAgo: Int)

    val seedRequests: List<SeedRequest> = listOf(
        SeedRequest(ProduceKind.TOMATO, "Cooking for a family of four, a small punnet would be lovely.", "Tampines", "Joanne", 1),
        SeedRequest(ProduceKind.LEMONGRASS, "For soup. Happy to trade eggs.", "Punggol", "Marcus", 4),
        SeedRequest(ProduceKind.CHILLI, "Anyone growing chilli padi near Bedok?", "Bedok", "Farah", 2),
        SeedRequest(ProduceKind.SPRING_ONION, "Just a bunch now and then.", "Woodlands", "Kelvin", 9),
    )
}
