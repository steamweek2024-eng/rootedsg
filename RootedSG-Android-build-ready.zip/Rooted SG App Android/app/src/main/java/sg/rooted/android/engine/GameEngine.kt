package sg.rooted.android.engine

import sg.rooted.android.model.HealthStatus
import sg.rooted.android.model.UserProfile
import kotlin.math.pow

/**
 * Pure XP/level math — a direct port of the iOS app's GameEngine "XP & Levels"
 * section. Kept side-effect-free so UserProfile can call straight into it
 * (see UserProfile.level) without needing a database handle.
 */
object GameEngine {

    private fun cumulativeXP(level: Int): Int {
        val l = maxOf(1, level)
        return ((l - 1).toDouble().pow(2) * 50).toInt()
    }

    fun level(forXP: Int): Int {
        var lvl = 1
        while (cumulativeXP(lvl + 1) <= forXP) lvl++
        return lvl
    }

    /** (xpIntoLevel, xpSpanOfLevel) */
    fun xpProgress(xp: Int): Pair<Int, Int> {
        val lvl = level(forXP = xp)
        val lower = cumulativeXP(lvl)
        val upper = cumulativeXP(lvl + 1)
        return (xp - lower) to maxOf(1, upper - lower)
    }

    /** +10 XP to register a plant. */
    const val REGISTRATION_XP = 10

    /** Survival milestones: +25 @ 7d, +100 @ 30d, +300 @ 90d, +750 @ 180d, +2000 @ 365d. */
    val SURVIVAL_MILESTONES: List<Pair<Int, Int>> = listOf(7 to 25, 30 to 100, 90 to 300, 180 to 750, 365 to 2000)

    /**
     * XP for the single normal day a verified check-in credits, scaled by how
     * the plant looked in that photo — a thriving plant earns more than a
     * struggling one, but showing up for a struggling plant still earns
     * something, so nursing it back to health stays worth doing.
     */
    fun dailyCareXP(health: HealthStatus): Int = when (health) {
        HealthStatus.HEALTHY -> 5
        HealthStatus.RECOVERING -> 4
        HealthStatus.STRUGGLING -> 2
        HealthStatus.AT_RISK, HealthStatus.DECEASED -> 0
    }

    /**
     * Every source of XP also pays the same amount in Seeds — the Shop's
     * spendable currency (see ShopItem.kt). XP only ever climbs (it drives
     * Level); Seeds climb the same way but spend back down at the Shop.
     * Routing every reward through this one place keeps the two permanently
     * in lockstep with no duplicated math.
     */
    fun award(user: UserProfile, xp: Int): UserProfile =
        user.copy(xp = user.xp + xp, seeds = user.seeds + xp)
}
