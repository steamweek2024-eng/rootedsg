package sg.rooted.android.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.util.UUID

/**
 * Persists check-in / registration / observation / produce photos to disk so
 * Room rows only ever carry a filename — a direct port of ImageStore.swift.
 * `init` is called once from RootedApplication, mirroring how the iOS version
 * implicitly has FileManager access everywhere.
 */
object ImageStore {
    private lateinit var directory: File

    fun init(context: Context) {
        directory = File(context.filesDir, "RootedPhotos").apply { mkdirs() }
    }

    fun save(bitmap: Bitmap): String {
        val filename = "${UUID.randomUUID()}.jpg"
        File(directory, filename).outputStream().use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 72, out)
        }
        return filename
    }

    fun load(filename: String?): Bitmap? {
        if (filename.isNullOrEmpty()) return null
        val file = File(directory, filename)
        if (!file.exists()) return null
        return BitmapFactory.decodeFile(file.path)
    }

    fun file(filename: String?): File? {
        if (filename.isNullOrEmpty()) return null
        return File(directory, filename)
    }

    fun newCaptureFile(): File {
        val filename = "${UUID.randomUUID()}.jpg"
        return File(directory, filename)
    }

    fun delete(filename: String?) {
        if (filename.isNullOrEmpty()) return
        File(directory, filename).delete()
    }
}
