package sg.rooted.android.engine

/**
 * Illustrative Singapore neighbourhood figures — a port of MockData.swift's
 * community fixtures. Clearly-labelled sample data, never presented as a real
 * pilot result; used only once a user has opted into the demo dataset.
 */
data class Neighbourhood(
    val name: String,
    val activeGrowers: Int,
    val activePlants: Int,
    val verifiedPlantDays: Int,
    val survivalRate: Double,
    val biodiversityObservations: Int,
)

data class LeaderboardEntry(val name: String, val subtitle: String, val plantDays: Int)

object MockData {
    val neighbourhoods = listOf(
        Neighbourhood("Tampines", 382, 714, 48219, 0.89, 273),
        Neighbourhood("Bishan", 211, 398, 26010, 0.91, 164),
        Neighbourhood("Jurong East", 176, 305, 19870, 0.84, 112),
        Neighbourhood("Punggol", 264, 460, 30112, 0.92, 201),
        Neighbourhood("Bukit Timah", 145, 260, 21044, 0.93, 188),
        Neighbourhood("Toa Payoh", 198, 340, 22190, 0.87, 96),
        Neighbourhood("Woodlands", 233, 401, 25877, 0.86, 141),
        Neighbourhood("Pasir Ris", 159, 289, 18345, 0.90, 133),
    )

    val classLeague = listOf(
        LeaderboardEntry("3A Green Warriors", "34 growers", 6210),
        LeaderboardEntry("4B EcoRoots", "29 growers", 5480),
        LeaderboardEntry("2C Sprout Squad", "31 growers", 4990),
        LeaderboardEntry("3C Leafline", "26 growers", 4310),
        LeaderboardEntry("1A Budding Stars", "22 growers", 3765),
    )

    val schoolLeague = listOf(
        LeaderboardEntry("School A", "Green School League", 52810),
        LeaderboardEntry("School B", "Green School League", 48291),
        LeaderboardEntry("School C", "Green School League", 44102),
        LeaderboardEntry("School D", "Green School League", 39876),
        LeaderboardEntry("School E", "Green School League", 35210),
    )

    val communityLeague = listOf(
        LeaderboardEntry("Tampines", "382 active growers", 48219),
        LeaderboardEntry("Punggol", "264 active growers", 30112),
        LeaderboardEntry("Woodlands", "233 active growers", 25877),
        LeaderboardEntry("Bishan", "211 active growers", 26010),
        LeaderboardEntry("Toa Payoh", "198 active growers", 22190),
    )

    const val DEMO_MODE_KEY = "rooted.demo-data.enabled"
}
