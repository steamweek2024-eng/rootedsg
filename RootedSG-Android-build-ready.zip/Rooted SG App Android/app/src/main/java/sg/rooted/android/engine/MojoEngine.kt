package sg.rooted.android.engine

import sg.rooted.android.model.HealthStatus
import sg.rooted.android.model.Plant
import sg.rooted.android.model.PlantStage
import sg.rooted.android.model.Quest
import sg.rooted.android.model.QuestStatus
import sg.rooted.android.model.UserProfile
import kotlin.math.roundToInt

/**
 * Mojo the carrot — the companion pet's brain. Pure, side-effect-free math and
 * copy in the same spirit as [GameEngine]: no database handle, no Android or
 * Compose imports, so a screen (or the background nudge worker, or a unit test)
 * can call straight into it.
 *
 * Mojo's health is a weighted blend of three things the player already earns:
 *  - **Garden** — the average health of the plants that are still alive.
 *  - **Badges** — real progression markers: Level, completed Quests, survival milestones.
 *  - **Momentum** — this week's XP plus the best care streak running right now.
 * When those go up, Mojo perks up; when the garden slips, Mojo wilts.
 */
object MojoEngine {

    // Blend weights — retune here; they sum to 1.0.
    const val W_GARDEN = 0.55
    const val W_BADGE = 0.30
    const val W_MOMENTUM = 0.15

    private fun healthValue(h: HealthStatus): Double = when (h) {
        HealthStatus.HEALTHY -> 1.0
        HealthStatus.RECOVERING -> 0.7
        HealthStatus.STRUGGLING -> 0.4
        HealthStatus.AT_RISK -> 0.25
        HealthStatus.DECEASED -> 0.0
    }

    /**
     * Average health across the plants that are still alive. No plants at all →
     * a neutral 0.6, so a brand-new grower's Mojo starts out "okay" rather than
     * "sad"; a garden where every plant has been lost → 0.0.
     */
    fun gardenScore(plants: List<Plant>): Double {
        if (plants.isEmpty()) return 0.6
        val alive = plants.filter { it.health != HealthStatus.DECEASED }
        if (alive.isEmpty()) return 0.0
        return alive.sumOf { healthValue(it.health) } / alive.size
    }

    /** Level (up to ~13), quests actually completed (up to 8), and survival
     * milestones plants have hit (up to 10) — each capped, then weighted. */
    fun badgeScore(user: UserProfile?, quests: List<Quest>, plants: List<Plant>): Double {
        val level = user?.level ?: 1
        val completedQuests = quests.count { it.status == QuestStatus.COMPLETED }
        val milestones = plants.sumOf { it.awardedMilestoneDays.size }
        val levelPart = ((level - 1) / 12.0).coerceIn(0.0, 1.0) * 0.5
        val questPart = (completedQuests / 8.0).coerceIn(0.0, 1.0) * 0.3
        val milePart = (milestones / 10.0).coerceIn(0.0, 1.0) * 0.2
        return (levelPart + questPart + milePart).coerceIn(0.0, 1.0)
    }

    /** This week's XP (full weight at ~120) plus the best live care streak (full at 10 days). */
    fun momentumScore(xpThisWeek: Int, plants: List<Plant>): Double {
        val bestStreak = plants.maxOfOrNull { it.careStreak } ?: 0
        val xpPart = (xpThisWeek / 120.0).coerceIn(0.0, 1.0) * 0.6
        val streakPart = (bestStreak / 10.0).coerceIn(0.0, 1.0) * 0.4
        return (xpPart + streakPart).coerceIn(0.0, 1.0)
    }

    fun vitals(plants: List<Plant>, quests: List<Quest>, user: UserProfile?, xpThisWeek: Int): PetVitals {
        val g = gardenScore(plants)
        val b = badgeScore(user, quests, plants)
        val m = momentumScore(xpThisWeek, plants)
        val health = (100.0 * (W_GARDEN * g + W_BADGE * b + W_MOMENTUM * m)).roundToInt().coerceIn(0, 100)
        return PetVitals(health = health, gardenScore = g, badgeScore = b, momentumScore = m, mood = mood(health))
    }

    fun mood(health: Int): MojoMood = when {
        health >= 85 -> MojoMood.THRIVING
        health >= 68 -> MojoMood.HAPPY
        health >= 50 -> MojoMood.OKAY
        health >= 32 -> MojoMood.WORRIED
        else -> MojoMood.SAD
    }

    /** The sprite Mojo settles into when he's just standing around, by mood. */
    fun restingAnim(mood: MojoMood): MojoAnim = when (mood) {
        MojoMood.THRIVING, MojoMood.HAPPY -> MojoAnim.IDLE
        MojoMood.OKAY -> MojoAnim.WAITING
        MojoMood.WORRIED -> MojoAnim.REVIEW
        MojoMood.SAD -> MojoAnim.FAILED
    }

    /** 1–3 short lines for the Home card and the Mojo screen — every line is tied
     * to something genuinely true about the garden right now. */
    fun encouragement(
        vitals: PetVitals,
        plants: List<Plant>,
        quests: List<Quest>,
        petName: String = "Mojo",
    ): List<String> {
        val lines = mutableListOf<String>()
        val due = plants.filter { it.health != HealthStatus.DECEASED && it.isCheckInDue() }
        val struggling = plants.filter { it.health == HealthStatus.STRUGGLING || it.health == HealthStatus.AT_RISK }
        val bestStreak = plants.maxOfOrNull { it.careStreak } ?: 0
        val nearQuest = quests.firstOrNull { it.status == QuestStatus.ACTIVE && it.progressFraction >= 0.6 }

        lines += when (vitals.mood) {
            MojoMood.THRIVING -> "$petName is thriving. Whatever you're doing, keep doing it."
            MojoMood.HAPPY -> "$petName is having a good day."
            MojoMood.OKAY -> "$petName is doing okay. A check-in would lift the mood."
            MojoMood.WORRIED -> "$petName looks worried about the garden."
            MojoMood.SAD -> "$petName is wilting a little. The garden needs you."
        }
        when {
            due.size == 1 -> lines += "${due[0].name} is waiting for a photo."
            due.size > 1 -> lines += "${due.size} plants are waiting for a photo."
        }
        if (struggling.isNotEmpty()) {
            val names = struggling.joinToString(", ") { it.name }
            lines += "$names ${if (struggling.size == 1) "is" else "are"} struggling — $petName is rooting for a comeback."
        }
        if (bestStreak >= 3 && due.isEmpty()) lines += "Your $bestStreak-day streak is alive. $petName counted every one."
        if (nearQuest != null) lines += "“${nearQuest.title}” is almost done — ${nearQuest.progress}/${nearQuest.target}."
        return lines.take(3)
    }

    // ── Reactions ────────────────────────────────────────────────────────────
    // A tiny Mojo that pops in from a corner on a real event, anywhere in the
    // app. The (sprite, line) is decided here so it stays pure and testable.

    fun reaction(event: MojoEvent, petName: String = "Mojo"): Pair<MojoAnim, String>? = when (event) {
        is MojoEvent.CheckInVerified ->
            MojoAnim.JUMPING to (if (event.daysAwarded > 0)
                "+${event.daysAwarded} day${if (event.daysAwarded == 1) "" else "s"} for ${event.plantName}. I felt that."
            else "${event.plantName} checked in. Nice.")
        is MojoEvent.PlantStruggling ->
            MojoAnim.FAILED to "${event.plantName} is struggling. Let's turn that around."
        is MojoEvent.LeveledUp ->
            MojoAnim.JUMPING to "Level ${event.level}! $petName is doing a little dance."
        is MojoEvent.QuestCompleted ->
            MojoAnim.WAVING to "“${event.title}” — done. That's the good stuff."
        is MojoEvent.StreakMilestone ->
            MojoAnim.JUMPING to "${event.days}-day streak. $petName is impressed."
    }

    // ── Daily tip ────────────────────────────────────────────────────────────
    // One useful, real-state coaching line for the Home card. Deterministic for
    // a given calendar day (pass day-of-year as [daySeed]) so it doesn't churn
    // every recomposition, but rotates when there's more than one thing to say.

    fun dailyTip(
        plants: List<Plant>,
        quests: List<Quest>,
        vitals: PetVitals,
        petName: String = "Mojo",
        daySeed: Int = 0,
    ): String {
        val alive = plants.filter { it.health != HealthStatus.DECEASED }
        val candidates = mutableListOf<String>()

        // A plant close to its next stage — the most motivating thing to hear.
        alive.filter { it.nextStage != null && it.daysToNextStage in 1..5 }
            .sortedBy { it.daysToNextStage }
            .firstOrNull()?.let {
                candidates += "${it.name} is ${it.daysToNextStage} verified day${if (it.daysToNextStage == 1) "" else "s"} from ${it.nextStage!!.displayName}."
            }

        // Something overdue.
        alive.filter { it.isCheckInDue() }.maxByOrNull { it.daysSinceLastCheckIn() }?.let {
            candidates += "${it.name} hasn't had a photo in ${it.daysSinceLastCheckIn()} days — that's the one I'd do first."
        }

        // A streak worth protecting.
        alive.filter { it.careStreak >= 4 && !it.isCheckInDue() }.maxByOrNull { it.careStreak }?.let {
            candidates += "${it.name} is on a ${it.careStreak}-day streak. Keep it going."
        }

        // A quest almost home.
        quests.filter { it.status == QuestStatus.ACTIVE && it.target - it.progress in 1..2 }
            .minByOrNull { it.target - it.progress }?.let {
                val left = it.target - it.progress
                candidates += "“${it.title}” just needs ${left} more."
            }

        if (candidates.isEmpty()) {
            candidates += when (vitals.mood) {
                MojoMood.THRIVING -> "Everything's green. Enjoy it — you earned this."
                MojoMood.HAPPY -> "Garden's in good shape. A quick look never hurts."
                MojoMood.OKAY -> "Pick one plant today. Just one photo."
                MojoMood.WORRIED, MojoMood.SAD -> "Start with whichever plant you like best. Momentum helps."
            }
        }
        return candidates[((daySeed % candidates.size) + candidates.size) % candidates.size]
    }

    /** The order Mojo cycles his poses through while idling on the tour cloud. */
    val EMOTE_CYCLE: List<MojoAnim> = listOf(
        MojoAnim.IDLE, MojoAnim.WAITING, MojoAnim.REVIEW, MojoAnim.WAVING, MojoAnim.IDLE, MojoAnim.JUMPING,
    )

    /**
     * The single line a reminder notification carries — deliberately affectionate,
     * a little pitiful, and **always** triggered by a real condition. Returns null
     * when the garden is healthy and nothing is actually due, so Mojo stays quiet
     * rather than inventing a reason to nag.
     */
    fun nudge(
        vitals: PetVitals,
        plants: List<Plant>,
        daysSinceOpen: Int,
        petName: String = "Mojo",
    ): String? {
        val alive = plants.filter { it.health != HealthStatus.DECEASED }
        val due = alive.filter { it.isCheckInDue() }.sortedByDescending { it.daysSinceLastCheckIn() }
        val streakAtRisk = alive
            .filter { it.careStreak >= 3 && it.daysSinceLastCheckIn() >= 6 }
            .maxByOrNull { it.careStreak }

        return when {
            streakAtRisk != null ->
                "Your ${streakAtRisk.careStreak}-day streak on ${streakAtRisk.name} snaps tomorrow. $petName can't watch that happen."
            due.size == 1 ->
                "${due[0].name} hasn't had a photo in ${due[0].daysSinceLastCheckIn()} days. $petName keeps checking the door."
            due.size > 1 ->
                "${due.size} plants are waiting on you. $petName has been pacing by the window."
            daysSinceOpen >= 3 ->
                "$petName hasn't seen you in $daysSinceOpen days. The plants are okay. $petName misses you."
            vitals.mood == MojoMood.WORRIED || vitals.mood == MojoMood.SAD ->
                "$petName is looking a little wilted today. One check-in would perk him right back up."
            else -> null
        }
    }
}

enum class MojoMood { THRIVING, HAPPY, OKAY, WORRIED, SAD }

/** Every Mojo sprite in `res/raw/` — see MojoSprite.kt for the file mapping. */
enum class MojoAnim { IDLE, WAITING, WAVING, RUNNING, RUNNING_LEFT, RUNNING_RIGHT, JUMPING, REVIEW, FAILED }

/** A real thing that just happened, worth a small Mojo pop-in. See [MojoEngine.reaction]. */
sealed interface MojoEvent {
    data class CheckInVerified(val plantName: String, val daysAwarded: Int) : MojoEvent
    data class PlantStruggling(val plantName: String) : MojoEvent
    data class LeveledUp(val level: Int) : MojoEvent
    data class QuestCompleted(val title: String) : MojoEvent
    data class StreakMilestone(val days: Int) : MojoEvent
}

data class PetVitals(
    /** 0..100 — what the health ring shows. */
    val health: Int,
    val gardenScore: Double,
    val badgeScore: Double,
    val momentumScore: Double,
    val mood: MojoMood,
)
