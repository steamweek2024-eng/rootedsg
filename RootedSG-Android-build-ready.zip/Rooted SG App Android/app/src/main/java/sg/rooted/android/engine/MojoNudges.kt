package sg.rooted.android.engine

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import sg.rooted.android.MainActivity
import sg.rooted.android.data.PreferencesStore
import sg.rooted.android.data.RootedDatabase
import java.time.LocalTime
import java.util.concurrent.TimeUnit

/**
 * Mojo's reminder notifications — the pet-voiced counterpart to
 * [CheckInReminders]. Same shape (WorkManager, no server, no push): one
 * repeating job that wakes a few times a day and *usually decides to stay
 * quiet*. It only ever speaks when something is genuinely true — a plant
 * overdue, a real streak about to break, several days since the app was
 * opened — and then at most once per day, never during quiet hours, and
 * never at all unless the player has met Mojo and left reminders on.
 *
 * The copy is affectionate and a little pitiful on purpose (an attachment
 * hook, the way a well-loved mascot earns a check-in), but there is no
 * invented urgency underneath it — see [MojoEngine.nudge].
 */
object MojoNudges {
    private const val CHANNEL_ID = "mojo_nudges"
    private const val WORK_NAME = "mojo-nudge"
    internal const val NOTIFICATION_ID = 77_010
    const val EXTRA_OPEN_PET = "sg.rooted.android.EXTRA_OPEN_PET"

    /** How often the job wakes. The worker's own 20h cool-down is the real cadence. */
    private val REPEAT_INTERVAL_HOURS = 6L
    private const val MIN_HOURS_BETWEEN_NUDGES = 20L
    private const val QUIET_START_HOUR = 21   // 21:00
    private const val QUIET_END_HOUR = 8      // 08:00

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Mojo", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Gentle nudges from Mojo when the garden needs you."
            },
        )
    }

    /** Idempotent — safe to call on every app start. */
    fun arm(context: Context) {
        val request = PeriodicWorkRequestBuilder<MojoNudgeWorker>(REPEAT_INTERVAL_HOURS, TimeUnit.HOURS)
            .setConstraints(Constraints.NONE)
            .setInitialDelay(REPEAT_INTERVAL_HOURS, TimeUnit.HOURS)
            .build()
        WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
    }

    internal fun withinQuietHours(now: LocalTime): Boolean {
        val h = now.hour
        return h >= QUIET_START_HOUR || h < QUIET_END_HOUR
    }

    internal fun minGapMs(): Long = TimeUnit.HOURS.toMillis(MIN_HOURS_BETWEEN_NUDGES)
}

class MojoNudgeWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val ctx = applicationContext
        val prefs = PreferencesStore(ctx)

        if (!prefs.hasSeenTutorialNow() || !prefs.petNudgesEnabledNow()) return@withContext Result.success()
        if (MojoNudges.withinQuietHours(LocalTime.now())) return@withContext Result.success()

        val now = System.currentTimeMillis()
        val lastNudge = prefs.petLastNudgeMs()
        if (lastNudge != 0L && now - lastNudge < MojoNudges.minGapMs()) return@withContext Result.success()

        val db = RootedDatabase.get(ctx)
        val user = db.userProfileDao().get() ?: return@withContext Result.success()
        val plants = db.plantDao().getAll(user.id)
        val quests = db.questDao().getAll(user.id)
        val weekAgo = now - TimeUnit.DAYS.toMillis(7)
        val xpThisWeek = db.xpEventDao().observeSumSince(user.id, weekAgo).first()

        val vitals = MojoEngine.vitals(plants, quests, user, xpThisWeek)
        val lastOpen = prefs.appLastOpenMs()
        val daysSinceOpen = if (lastOpen == 0L) 0 else TimeUnit.MILLISECONDS.toDays(now - lastOpen).toInt()
        val petName = prefs.petNameNow()

        val message = MojoEngine.nudge(vitals, plants, daysSinceOpen, petName) ?: return@withContext Result.success()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ActivityCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            return@withContext Result.success()
        }

        MojoNudges.ensureChannel(ctx)
        val openIntent = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(MojoNudges.EXTRA_OPEN_PET, true)
        }
        val pendingIntent = PendingIntent.getActivity(
            ctx, 7701, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val notification = NotificationCompat.Builder(ctx, "mojo_nudges")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("$petName misses you")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        ctx.getSystemService(NotificationManager::class.java)?.notify(MojoNudges.NOTIFICATION_ID, notification)
        prefs.setPetLastNudgeMs(now)
        Result.success()
    }
}
