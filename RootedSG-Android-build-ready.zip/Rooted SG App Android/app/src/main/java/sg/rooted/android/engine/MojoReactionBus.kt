package sg.rooted.android.engine

import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow

/**
 * A one-line bus for "something real just happened" moments. Repositories drop
 * a [MojoEvent] here (non-suspending, drops the oldest if nobody's listening);
 * the reaction host mounted in the shell turns the newest one into a small
 * Mojo pop-in. Kept in the engine layer so data code can post without reaching
 * into the UI.
 */
object MojoReactionBus {
    val events = MutableSharedFlow<MojoEvent>(extraBufferCapacity = 4, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    fun post(event: MojoEvent) { events.tryEmit(event) }
}
