package sg.rooted.android.engine

/**
 * Pure local ledger rules — a direct port of PlantDayLedger.swift. One
 * verified check-in credits exactly one Verified Plant-Day, once per calendar
 * day. There is no retrospective catch-up for a gap since the last check-in —
 * a normal day count, not a farmable one.
 */
object PlantDayLedger {
    fun award(alreadyCreditedToday: Boolean): Int = if (alreadyCreditedToday) 0 else 1

    fun total(credits: List<Int>): Int = credits.sumOf { maxOf(0, it) }
}
