package sg.rooted.android.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import sg.rooted.android.model.ProduceKind
import kotlin.random.Random

/**
 * Deterministic, seeded placeholder photography — a direct port of what
 * ProducePhoto.swift / MockData's SamplePhoto do for seeded demo data and for
 * a synced listing that carries no real photo (see MarketSyncEngine on iOS).
 * Not a real photo of anything; a warm gradient block with the produce's own
 * emoji, so the grid still reads as photo-forward rather than a blank tile.
 */
private fun renderEmojiBlock(emoji: String, seed: Int, size: Int = 480): Bitmap {
    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val random = Random(seed)

    // A small, warm, deterministic palette of gradient pairs — hue picked by seed.
    val palettes = listOf(
        0xFFE0A86A.toInt() to 0xFF9C5E30.toInt(),
        0xFF8FBF6B.toInt() to 0xFF35662B.toInt(),
        0xFFE8C77A.toInt() to 0xFFB4763A.toInt(),
        0xFF7FB89E.toInt() to 0xFF2E5C4C.toInt(),
        0xFFD98E73.toInt() to 0xFF8C4630.toInt(),
    )
    val (top, bottom) = palettes[random.nextInt(palettes.size)]

    val gradient = LinearGradient(0f, 0f, size.toFloat(), size.toFloat(), top, bottom, Shader.TileMode.CLAMP)
    val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = gradient }
    canvas.drawRect(0f, 0f, size.toFloat(), size.toFloat(), bgPaint)

    val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = size * 0.42f
        textAlign = Paint.Align.CENTER
    }
    val bounds = android.graphics.Rect()
    textPaint.getTextBounds(emoji, 0, emoji.length, bounds)
    val y = size / 2f - bounds.exactCenterY()
    canvas.drawText(emoji, size / 2f, y, textPaint)

    return bitmap
}

object ProducePhoto {
    fun make(kind: ProduceKind, seed: Int): Bitmap = renderEmojiBlock(kind.emoji, seed)
}

object SamplePhoto {
    enum class Mood { HEALTHY, STRUGGLING }

    fun make(mood: Mood, seed: Int): Bitmap =
        renderEmojiBlock(if (mood == Mood.HEALTHY) "🌿" else "🥀", seed)
}
