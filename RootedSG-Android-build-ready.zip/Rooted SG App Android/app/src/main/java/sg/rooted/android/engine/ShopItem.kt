package sg.rooted.android.engine

import androidx.compose.ui.graphics.Color

/**
 * A cosmetic slot — a Compose port of ShopItem.swift. Every item lives in
 * exactly one; nothing here ever touches a plant's real stage, health or
 * Verified Plant-Days, only how the *profile* looks while showing that real
 * progress off.
 */
enum class ShopCategory(val label: String, val icon: String) {
    TITLE("Titles", "text.quote"),
    FRAME("Frames", "circle.dashed"),
    POT_SKIN("Pot Skins", "paintbrush.fill"),
}

enum class ShopRarity(val label: String, val tint: Color) {
    // A fixed, non-themed palette — rarity is a game-collectible signal, the
    // same way a bloom's petal colour is, not app chrome that should shift
    // with the reading theme.
    COMMON("Common", Color(0.561f, 0.580f, 0.522f)),
    RARE("Rare", Color(0.271f, 0.541f, 0.741f)),
    EPIC("Epic", Color(0.514f, 0.376f, 0.729f)),
    LEGENDARY("Legendary", Color(0.851f, 0.741f, 0.404f)),
}

data class ShopItem(
    val id: String,
    val category: ShopCategory,
    val name: String,
    /** For [ShopCategory.TITLE], the flair text itself. For the others, a short description. */
    val detail: String,
    val rarity: ShopRarity,
    val price: Int,
    /** FRAME: ring gradient (1–2 stops). POT_SKIN: [top, bottom, rim]. TITLE: unused. */
    val colors: List<Color> = emptyList(),
)

object ShopCatalog {
    val all: List<ShopItem> = listOf(
        // Titles — flair shown under your name.
        ShopItem("title.green_thumb", ShopCategory.TITLE, "Green Thumb",
            "A little flair under your name.", ShopRarity.COMMON, 60),
        ShopItem("title.rain_whisperer", ShopCategory.TITLE, "Rain Whisperer",
            "A little flair under your name.", ShopRarity.COMMON, 60),
        ShopItem("title.urban_forester", ShopCategory.TITLE, "Urban Forester",
            "For a garden that outgrew the windowsill.", ShopRarity.RARE, 180),
        ShopItem("title.verified_grower", ShopCategory.TITLE, "Verified Grower",
            "Every day of it, checked and counted.", ShopRarity.RARE, 180),
        ShopItem("title.plant_whisperer", ShopCategory.TITLE, "Plant Whisperer",
            "Earned the hard way, plant by plant.", ShopRarity.EPIC, 420),
        ShopItem("title.legacy_keeper", ShopCategory.TITLE, "Legacy Keeper",
            "For growers who kept something alive for good.", ShopRarity.LEGENDARY, 900),

        // Frames — a ring around your avatar.
        ShopItem("frame.sage", ShopCategory.FRAME, "Sage Ring", "A quiet green ring.",
            ShopRarity.COMMON, 60, listOf(Color(0.494f, 0.596f, 0.427f))),
        ShopItem("frame.sky", ShopCategory.FRAME, "Sky Ring", "A calm blue ring.",
            ShopRarity.COMMON, 60, listOf(Color(0.353f, 0.596f, 0.769f))),
        ShopItem("frame.sunrise", ShopCategory.FRAME, "Sunrise Ring", "Warm gradient, dawn to noon.",
            ShopRarity.RARE, 180, listOf(Color(0.914f, 0.545f, 0.290f), Color(0.918f, 0.322f, 0.325f))),
        ShopItem("frame.bloom", ShopCategory.FRAME, "Bloom Ring", "The colour of a flowering stage.",
            ShopRarity.RARE, 180, listOf(Color(0.918f, 0.404f, 0.482f), Color(0.933f, 0.549f, 0.620f))),
        ShopItem("frame.gold", ShopCategory.FRAME, "Gold Ring", "The Legacy Plant's own gold.",
            ShopRarity.EPIC, 420, listOf(Color(0.851f, 0.741f, 0.404f), Color(0.722f, 0.596f, 0.286f))),
        ShopItem("frame.aurora", ShopCategory.FRAME, "Aurora Ring", "Every rarity's colour, all at once.",
            ShopRarity.LEGENDARY, 900, listOf(Color(0.514f, 0.376f, 0.729f), Color(0.271f, 0.541f, 0.741f), Color(0.851f, 0.741f, 0.404f))),

        // Pot Skins — recolours the pot every character stands in.
        ShopItem("pot.clay_white", ShopCategory.POT_SKIN, "Clay White", "Clean and pale.",
            ShopRarity.COMMON, 60, listOf(Color(0.964f, 0.960f, 0.949f), Color(0.843f, 0.835f, 0.816f), Color(0.996f, 0.992f, 0.988f))),
        ShopItem("pot.jade", ShopCategory.POT_SKIN, "Jade", "Deep green ceramic.",
            ShopRarity.COMMON, 60, listOf(Color(0.361f, 0.541f, 0.427f), Color(0.220f, 0.376f, 0.298f), Color(0.451f, 0.639f, 0.514f))),
        ShopItem("pot.terracotta_sunset", ShopCategory.POT_SKIN, "Terracotta Sunset", "Orange fading to rose.",
            ShopRarity.RARE, 180, listOf(Color(0.878f, 0.549f, 0.310f), Color(0.729f, 0.318f, 0.302f), Color(0.933f, 0.647f, 0.412f))),
        ShopItem("pot.charcoal", ShopCategory.POT_SKIN, "Charcoal", "Matte, modern, dark.",
            ShopRarity.RARE, 180, listOf(Color(0.278f, 0.282f, 0.271f), Color(0.145f, 0.149f, 0.145f), Color(0.376f, 0.380f, 0.369f))),
        ShopItem("pot.gilded", ShopCategory.POT_SKIN, "Gilded", "The Legacy Plant's band, on every pot.",
            ShopRarity.EPIC, 420, listOf(Color(0.851f, 0.741f, 0.404f), Color(0.686f, 0.573f, 0.267f), Color(0.945f, 0.867f, 0.616f))),
        ShopItem("pot.aurora_glass", ShopCategory.POT_SKIN, "Aurora Glass", "Iridescent, shifts as it catches the light.",
            ShopRarity.LEGENDARY, 900, listOf(Color(0.635f, 0.541f, 0.831f), Color(0.376f, 0.588f, 0.741f), Color(0.933f, 0.784f, 0.616f))),
    )

    fun item(id: String): ShopItem? = if (id.isEmpty()) null else all.firstOrNull { it.id == id }

    fun items(category: ShopCategory): List<ShopItem> = all.filter { it.category == category }
}
