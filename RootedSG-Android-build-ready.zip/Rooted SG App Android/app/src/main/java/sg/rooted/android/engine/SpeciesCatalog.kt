package sg.rooted.android.engine

/** Curated catalog of plants commonly grown in Singapore homes and school gardens. */
data class SpeciesEntry(val name: String, val emoji: String, val keywords: List<String> = emptyList())

object SpeciesCatalog {
    val all: List<SpeciesEntry> = listOf(
        SpeciesEntry("Chilli Plant", "🌶️", listOf("chili", "chilli", "pepper", "capsicum")),
        SpeciesEntry("Tomato Plant", "🍅", listOf("tomato")),
        SpeciesEntry("Basil", "🌿", listOf("basil", "herb")),
        SpeciesEntry("Mint", "🌱", listOf("mint")),
        SpeciesEntry("Curry Leaf Plant", "🍃", listOf("curry leaf", "murraya")),
        SpeciesEntry("Pandan", "🌾", listOf("pandan", "screwpine")),
        SpeciesEntry("Aloe Vera", "🪴", listOf("aloe", "succulent")),
        SpeciesEntry("Cactus", "🌵", listOf("cactus")),
        SpeciesEntry("Money Plant (Pothos)", "🪴", listOf("pothos", "money plant", "epipremnum", "ivy")),
        SpeciesEntry("Monstera", "🪴", listOf("monstera")),
        SpeciesEntry("Orchid", "🌸", listOf("orchid")),
        SpeciesEntry("Hibiscus", "🌺", listOf("hibiscus")),
        SpeciesEntry("Bougainvillea", "💮", listOf("bougainvillea")),
        SpeciesEntry("Frangipani", "🌼", listOf("frangipani", "plumeria")),
        SpeciesEntry("Rose", "🌹", listOf("rose")),
        SpeciesEntry("Sunflower", "🌻", listOf("sunflower")),
        SpeciesEntry("Fern", "🌿", listOf("fern")),
        SpeciesEntry("Bamboo", "🎋", listOf("bamboo")),
        SpeciesEntry("Banana Plant", "🍌", listOf("banana")),
        SpeciesEntry("Lime Tree", "🍋", listOf("lime", "citrus", "lemon")),
        SpeciesEntry("Bonsai Tree", "🌳", listOf("bonsai")),
        SpeciesEntry("Water Lily", "🪷", listOf("water lily", "lotus")),
        SpeciesEntry("Sweet Potato Vine", "🍠", listOf("sweet potato", "vine")),
        SpeciesEntry("Lavender", "💜", listOf("lavender")),
        SpeciesEntry("Jasmine", "🤍", listOf("jasmine")),
        SpeciesEntry("Snake Plant", "🪴", listOf("snake plant", "sansevieria")),
        SpeciesEntry("Other / Not Listed", "🌱"),
    )

    fun match(label: String): SpeciesEntry? =
        all.firstOrNull { it.keywords.isNotEmpty() && it.keywords.any { k -> label.contains(k) } }

    fun byName(name: String): SpeciesEntry? {
        val normalized = name.lowercase().trim()
        all.firstOrNull { it.name.lowercase() == normalized }?.let { return it }
        return all.firstOrNull { entry -> entry.keywords.any { normalized.contains(it) || it.contains(normalized) } }
    }
}
