package sg.rooted.android.engine

import android.graphics.Bitmap
import sg.rooted.android.model.ConfidenceLevel
import sg.rooted.android.model.HealthStatus
import kotlin.math.abs
import kotlin.math.pow

/**
 * On-device, key-free "AI-assisted" analysis — a direct port of the pixel
 * heuristics in VisionService.swift. Flags confidence levels rather than
 * claiming certainty. (The iOS app's on-device Vision *species* classifier
 * has no Android equivalent here without adding ML Kit; species suggestion
 * on this platform is cloud-assisted only, with the same manual catalog
 * fallback the iOS app already relies on for low confidence.)
 */
object VisionService {

    data class ColorProfile(
        val greenRatio: Double,
        val yellowBrownRatio: Double,
        val averageBrightness: Double,
        val luminanceVariance: Double,
        val edgeDensity: Double,
    )

    fun colorProfile(bitmap: Bitmap): ColorProfile {
        val width = 48
        val height = 48
        val scaled = Bitmap.createScaledBitmap(bitmap, width, height, true)
        val pixels = IntArray(width * height)
        scaled.getPixels(pixels, 0, width, 0, 0, width, height)

        val luminances = DoubleArray(width * height)
        var greenCount = 0
        var yellowBrownCount = 0
        var totalBrightness = 0.0

        for (i in pixels.indices) {
            val p = pixels[i]
            val r = ((p shr 16) and 0xFF).toDouble()
            val g = ((p shr 8) and 0xFF).toDouble()
            val b = (p and 0xFF).toDouble()
            val luminance = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255.0
            luminances[i] = luminance
            totalBrightness += luminance

            if (g > r * 1.05 && g > b * 1.05 && g > 40) {
                greenCount++
            } else if (r > 90 && g > 60 && b < minOf(r, g) * 0.75) {
                yellowBrownCount++
            }
        }

        val pixelCount = width * height
        return ColorProfile(
            greenRatio = greenCount.toDouble() / pixelCount,
            yellowBrownRatio = yellowBrownCount.toDouble() / pixelCount,
            averageBrightness = totalBrightness / pixelCount,
            luminanceVariance = luminanceVariance(luminances),
            edgeDensity = edgeDensity(luminances, width, height),
        )
    }

    private fun luminanceVariance(values: DoubleArray): Double {
        if (values.isEmpty()) return 0.0
        val mean = values.average()
        return values.sumOf { (it - mean).pow(2) } / values.size
    }

    private fun edgeDensity(values: DoubleArray, width: Int, height: Int): Double {
        if (values.size != width * height || width <= 1 || height <= 1) return 0.0
        var totalDifference = 0.0
        var comparisons = 0
        for (y in 0 until height) {
            for (x in 0 until width) {
                val index = y * width + x
                if (x > 0) { totalDifference += abs(values[index] - values[index - 1]); comparisons++ }
                if (y > 0) { totalDifference += abs(values[index] - values[index - width]); comparisons++ }
            }
        }
        return if (comparisons == 0) 0.0 else totalDifference / comparisons
    }

    data class VerificationResult(
        val vegetationDetected: Boolean,
        val confidence: ConfidenceLevel,
        val greenRatio: Double,
        val presenceScore: Double,
        val summary: String,
    )

    fun verifyVegetation(bitmap: Bitmap): VerificationResult = verification(colorProfile(bitmap))

    private fun verification(profile: ColorProfile): VerificationResult {
        val chromaSignal = minOf(1.0, profile.greenRatio * 2.4 + profile.yellowBrownRatio * 0.35)
        val structureSignal = minOf(1.0, profile.luminanceVariance * 12 + profile.edgeDensity * 2.4)
        val lightingSignal = when {
            profile.averageBrightness < 0.10 || profile.averageBrightness > 0.98 -> 0.25
            profile.averageBrightness < 0.16 || profile.averageBrightness > 0.90 -> 0.65
            else -> 1.0
        }
        val presenceScore = chromaSignal * 0.45 + structureSignal * 0.35 + lightingSignal * 0.20
        val detected = presenceScore >= 0.30 && (chromaSignal >= 0.08 || structureSignal >= 0.16)
        val confidence: ConfidenceLevel
        val summary: String
        when {
            presenceScore >= 0.66 -> {
                confidence = ConfidenceLevel.HIGH
                summary = "Strong vegetation signal from colour, visible structure, and lighting."
            }
            presenceScore >= 0.30 -> {
                confidence = ConfidenceLevel.MEDIUM
                summary = "A possible plant signal is present, but coverage or structure is partial, fill more of the frame next time."
            }
            else -> {
                confidence = ConfidenceLevel.LOW
                summary = "Unable to verify automatically. Please retake the photograph with the plant clearly in frame and good lighting."
            }
        }
        return VerificationResult(detected, confidence, profile.greenRatio, presenceScore, summary)
    }

    // MARK: Duplicate / re-use detection — 8x8 average-hash perceptual fingerprint.

    fun averageHash(bitmap: Bitmap): Long {
        val size = 8
        val scaled = Bitmap.createScaledBitmap(bitmap, size, size, true)
        val gray = IntArray(size * size)
        var sum = 0
        for (y in 0 until size) {
            for (x in 0 until size) {
                val p = scaled.getPixel(x, y)
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF
                val lum = (0.2126 * r + 0.7152 * g + 0.0722 * b).toInt()
                gray[y * size + x] = lum
                sum += lum
            }
        }
        val avg = sum / gray.size
        var hash = 0L
        for (i in gray.indices) if (gray[i] >= avg) hash = hash or (1L shl i)
        return hash
    }

    fun hammingDistance(a: Long, b: Long): Int = java.lang.Long.bitCount(a xor b)

    fun looksLikeDuplicate(a: Bitmap, b: Bitmap): Boolean =
        hammingDistance(averageHash(a), averageHash(b)) <= 3

    // MARK: Plant Doctor — cautious, non-definitive, on-device fallback.

    data class DoctorReport(val headline: String, val suggestions: List<String>, val severity: HealthStatus)

    fun plantDoctorReport(bitmap: Bitmap): DoctorReport {
        val profile = colorProfile(bitmap)
        val suggestions = mutableListOf<String>()
        var severity = HealthStatus.HEALTHY
        var headline = "Looking good."

        if (profile.greenRatio < 0.05) {
            headline = "We couldn't find much visible vegetation."
            suggestions.add("Frame the photo so leaves or stems fill more of the shot.")
            suggestions.add("Check lighting, very dark or backlit photos are harder to assess.")
            severity = HealthStatus.AT_RISK
        } else {
            when {
                profile.yellowBrownRatio > 0.28 -> {
                    headline = "Possible signs of stress worth a closer look."
                    suggestions.add("Possible signs of underwatering or leaf yellowing, check soil moisture.")
                    suggestions.add("Check the underside of leaves for pest damage.")
                    severity = HealthStatus.STRUGGLING
                }
                profile.yellowBrownRatio > 0.14 -> {
                    headline = "Mostly healthy, a little dryness visible."
                    suggestions.add("Some yellowing at the edges, keep an eye on watering consistency.")
                    severity = HealthStatus.RECOVERING
                }
                else -> {
                    suggestions.add("Green coverage looks strong and consistent.")
                    severity = HealthStatus.HEALTHY
                }
            }
            if (profile.averageBrightness < 0.18) {
                suggestions.add("The photo is quite dark, natural daylight gives ROOTED a clearer read next time.")
            }
        }
        suggestions.add("This is AI-assisted guidance, not a diagnosis, when in doubt, check with a caregiver or teacher.")
        return DoctorReport(headline, suggestions, severity)
    }
}
