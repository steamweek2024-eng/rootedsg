package sg.rooted.android.engine

import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.*

/**
 * Singapore growing conditions powered by NEA/data.gov.sg.
 *
 * ROOTED uses the current v2 real-time endpoints for station-level rainfall,
 * temperature, humidity and wind, plus UV and the 2h/24h/4-day forecasts.
 * Calls are intentionally keyless in the APK. A production data.gov.sg key
 * belongs on the optional backend proxy, not in extractable Android bytecode.
 */
object WeatherService {

    enum class Tint { RAIN, HEAT, UV, NORMAL }

    data class ForecastPeriod(
        val label: String,
        val west: String, val east: String, val central: String, val south: String, val north: String,
    )

    data class OutlookDay(
        val date: String,
        val forecast: String,
        val low: Int?,
        val high: Int?,
    )

    enum class UvCategory(val label: String) {
        LOW("Low"), MODERATE("Moderate"), HIGH("High"), VERY_HIGH("Very High"), EXTREME("Extreme");
        companion object {
            fun of(index: Int): UvCategory = when {
                index < 3 -> LOW
                index < 6 -> MODERATE
                index < 8 -> HIGH
                index < 11 -> VERY_HIGH
                else -> EXTREME
            }
        }
    }

    data class CareAdvisory(
        val headline: String,
        val detail: String,
        val icon: String,
        val tint: Tint,
        val recentRainfallMm: Double,
        val forecast: String,
        val uvIndex: Int?,
        val temperatureHigh: Int?,
        val temperatureLow: Int? = null,
        val stationsReportingRain: Int = 0,
        val totalStations: Int = 0,
        val periods: List<ForecastPeriod> = emptyList(),
        /** Nearest available station/forecast area to the profile neighbourhood. */
        val locationLabel: String = "Singapore",
        val localTemperatureC: Double? = null,
        val localHumidityPercent: Double? = null,
        val localWindKmh: Double? = null,
        val localRainfallMm: Double? = null,
        val twoHourForecast: String? = null,
        val fourDayOutlook: List<OutlookDay> = emptyList(),
        val fetchedAt: Long = System.currentTimeMillis(),
    ) {
        val careContext: String
            get() = buildList {
                localTemperatureC?.let { add("${it.roundToInt()}°C") }
                localHumidityPercent?.let { add("${it.roundToInt()}% humidity") }
                localRainfallMm?.let { if (it > 0) add("${"%.1f".format(Locale.US, it)} mm rain") }
                uvIndex?.let { add("UV $it") }
                twoHourForecast?.takeIf { it.isNotBlank() }?.let { add(it) }
            }.joinToString(" · ").ifBlank { forecast }

        companion object {
            val placeholder = CareAdvisory(
                headline = "Checking Singapore's growing conditions",
                detail = "ROOTED uses nearby NEA readings as care context, not as a substitute for checking the soil and plant itself.",
                icon = "leaf.fill", tint = Tint.NORMAL,
                recentRainfallMm = 0.0, forecast = "Updating…", uvIndex = null,
                temperatureHigh = null, temperatureLow = null,
            )
        }
    }

    private const val V2 = "https://api-open.data.gov.sg/v2/real-time/api"
    private const val V1 = "https://api.data.gov.sg/v1/environment"
    private val gson = Gson()
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .callTimeout(14, TimeUnit.SECONDS)
        .build()

    private data class Cached(val neighbourhood: String, val advisory: CareAdvisory, val at: Long)
    @Volatile private var cached: Cached? = null
    private const val CACHE_LIFETIME_MS = 10 * 60 * 1000L
    val lastKnown: CareAdvisory? get() = cached?.advisory

    private data class GeoPoint(val lat: Double, val lon: Double)
    private data class StationValue(val id: String, val name: String, val point: GeoPoint, val value: Double)

    /** Approximate centres are sufficient only for choosing the closest public sensor/forecast area. */
    private val neighbourhoodCentres = mapOf(
        "ang mo kio" to GeoPoint(1.3691, 103.8454), "bedok" to GeoPoint(1.3236, 103.9273),
        "bishan" to GeoPoint(1.3508, 103.8485), "bukit batok" to GeoPoint(1.3496, 103.7496),
        "bukit panjang" to GeoPoint(1.3774, 103.7719), "bukit timah" to GeoPoint(1.3294, 103.8021),
        "choa chu kang" to GeoPoint(1.3840, 103.7470), "clementi" to GeoPoint(1.3151, 103.7650),
        "geylang" to GeoPoint(1.3201, 103.8918), "hougang" to GeoPoint(1.3612, 103.8863),
        "jurong east" to GeoPoint(1.3329, 103.7436), "jurong west" to GeoPoint(1.3404, 103.7090),
        "kallang" to GeoPoint(1.3114, 103.8712), "marine parade" to GeoPoint(1.3020, 103.9070),
        "novena" to GeoPoint(1.3201, 103.8439), "pasir ris" to GeoPoint(1.3730, 103.9493),
        "punggol" to GeoPoint(1.4052, 103.9023), "queenstown" to GeoPoint(1.2942, 103.7861),
        "sembawang" to GeoPoint(1.4491, 103.8185), "sengkang" to GeoPoint(1.3868, 103.8914),
        "serangoon" to GeoPoint(1.3554, 103.8679), "tampines" to GeoPoint(1.3521, 103.9447),
        "toa payoh" to GeoPoint(1.3343, 103.8563), "woodlands" to GeoPoint(1.4382, 103.7890),
        "yishun" to GeoPoint(1.4304, 103.8354), "central" to GeoPoint(1.3521, 103.8198),
    )

    suspend fun todaysAdvisory(neighbourhood: String? = null): CareAdvisory? = withContext(Dispatchers.IO) {
        val key = neighbourhood.orEmpty().trim().lowercase(Locale.US)
        val now = System.currentTimeMillis()
        cached?.let { c ->
            if (c.neighbourhood == key && now - c.at < CACHE_LIFETIME_MS) return@withContext c.advisory
        }

        val result = runCatching { fetchV2Advisory(neighbourhood) }.getOrElse {
            runCatching { fetchLegacyAdvisory() }.getOrNull()
        } ?: cached?.advisory

        if (result != null) cached = Cached(key, result, now)
        result
    }

    private suspend fun fetchV2Advisory(neighbourhood: String?): CareAdvisory = coroutineScope {
        val paths = listOf(
            "rainfall", "air-temperature", "relative-humidity", "wind-speed",
            "uv", "two-hr-forecast", "twenty-four-hr-forecast", "four-day-outlook",
        )
        val docs = paths.map { path -> async { path to runCatching { fetchJson("$V2/$path") }.getOrNull() } }.awaitAll().toMap()
        if (docs.values.all { it == null }) throw IOException("No data.gov.sg feeds available")

        val target = neighbourhoodPoint(neighbourhood)
        val rainValues = parseStationValues(docs["rainfall"])
        val tempValues = parseStationValues(docs["air-temperature"])
        val humidityValues = parseStationValues(docs["relative-humidity"])
        val windValues = parseStationValues(docs["wind-speed"])

        val nearestRain = nearest(rainValues, target)
        val nearestTemp = nearest(tempValues, target)
        val nearestHumidity = nearest(humidityValues, target)
        val nearestWind = nearest(windValues, target)
        val uv = parseLatestUv(docs["uv"])
        val twoHr = parseAreaForecast(docs["two-hr-forecast"], neighbourhood, target)
        val general = parse24Hour(docs["twenty-four-hr-forecast"])
        val outlook = parseFourDay(docs["four-day-outlook"])

        val avgRain = rainValues.map { it.value }.takeIf { it.isNotEmpty() }?.average() ?: 0.0
        val totalRainStations = rainValues.size
        val wetStations = rainValues.count { it.value > 0.0 }
        val high = general.high
        val low = general.low
        val forecast = twoHr?.second ?: general.forecast.ifBlank { "Current conditions" }
        val locationLabel = nearestTemp?.name ?: nearestHumidity?.name ?: twoHr?.first ?: neighbourhood ?: "Singapore"

        buildAdvisory(
            localRain = nearestRain?.value,
            avgRain = avgRain,
            forecast = forecast,
            highTemp = high,
            uv = uv,
            humidity = nearestHumidity?.value,
        ).copy(
            temperatureLow = low,
            totalStations = totalRainStations,
            stationsReportingRain = wetStations,
            locationLabel = locationLabel,
            localTemperatureC = nearestTemp?.value,
            localHumidityPercent = nearestHumidity?.value,
            localWindKmh = nearestWind?.value,
            localRainfallMm = nearestRain?.value,
            twoHourForecast = twoHr?.second,
            fourDayOutlook = outlook,
            periods = general.periods,
            fetchedAt = System.currentTimeMillis(),
        )
    }

    private fun buildAdvisory(
        localRain: Double?, avgRain: Double, forecast: String, highTemp: Int?, uv: Int?, humidity: Double?,
    ): CareAdvisory {
        val lower = forecast.lowercase(Locale.US)
        val rain = localRain ?: avgRain
        val looksWet = rain > 0.2 || "rain" in lower || "shower" in lower || "thunder" in lower
        if (looksWet || (humidity != null && humidity >= 88 && rain > 0.0)) {
            return CareAdvisory(
                headline = "Let the pot dry before you water",
                detail = "Nearby NEA conditions are wet or very humid. Outdoor soil may dry more slowly, so check it before adding more water.",
                icon = "cloud.rain.fill", tint = Tint.RAIN,
                recentRainfallMm = avgRain, forecast = forecast, uvIndex = uv, temperatureHigh = highTemp,
            )
        }
        if (uv != null && uv >= 8) {
            return CareAdvisory(
                headline = "Harsh light window today",
                detail = "Singapore's UV index is $uv. Protect shade-loving or recently stressed leaves from strong afternoon sun.",
                icon = "sun.max.fill", tint = Tint.UV,
                recentRainfallMm = avgRain, forecast = forecast, uvIndex = uv, temperatureHigh = highTemp,
            )
        }
        if ((highTemp ?: 0) >= 34 || (humidity != null && humidity <= 50)) {
            return CareAdvisory(
                headline = "Soil may dry faster today",
                detail = "Warm or relatively dry conditions can increase moisture loss. Check the root zone rather than watering by schedule.",
                icon = "thermometer.sun.fill", tint = Tint.HEAT,
                recentRainfallMm = avgRain, forecast = forecast, uvIndex = uv, temperatureHigh = highTemp,
            )
        }
        return CareAdvisory(
            headline = "Steady growing conditions",
            detail = "No major weather adjustment detected nearby. Use the plant and soil as your primary care signals.",
            icon = "leaf.fill", tint = Tint.NORMAL,
            recentRainfallMm = avgRain, forecast = forecast, uvIndex = uv, temperatureHigh = highTemp,
        )
    }

    // ── v2 parsing helpers ────────────────────────────────────────────────

    private fun parseStationValues(root: JsonObject?): List<StationValue> {
        if (root == null) return emptyList()
        val data = root.obj("data") ?: return emptyList()
        val stations = data.arr("stations") ?: return emptyList()
        val stationMap = stations.mapNotNull { el ->
            val o = el.asJsonObjectOrNull() ?: return@mapNotNull null
            val id = o.string("id") ?: o.string("stationId") ?: return@mapNotNull null
            val loc = o.obj("location") ?: return@mapNotNull null
            val lat = loc.double("latitude") ?: loc.double("lat") ?: return@mapNotNull null
            val lon = loc.double("longitude") ?: loc.double("long") ?: loc.double("lon") ?: return@mapNotNull null
            id to Pair(o.string("name") ?: id, GeoPoint(lat, lon))
        }.toMap()

        val readingContainers = data.arr("readings") ?: data.arr("records") ?: return emptyList()
        val latest = readingContainers.lastOrNull()?.asJsonObjectOrNull() ?: return emptyList()
        val valuesArray = latest.arr("data") ?: latest.arr("readings") ?: return emptyList()
        return valuesArray.mapNotNull { el ->
            val o = el.asJsonObjectOrNull() ?: return@mapNotNull null
            val id = o.string("stationId") ?: o.string("station_id") ?: o.string("id") ?: return@mapNotNull null
            val value = o.double("value") ?: return@mapNotNull null
            val station = stationMap[id] ?: return@mapNotNull null
            StationValue(id, station.first, station.second, value)
        }
    }

    private fun parseLatestUv(root: JsonObject?): Int? {
        val data = root?.obj("data") ?: return null
        val records = data.arr("records") ?: data.arr("items") ?: return null
        val record = records.firstOrNull()?.asJsonObjectOrNull() ?: return null
        val index = record.arr("index") ?: return null
        return index.firstOrNull()?.asJsonObjectOrNull()?.double("value")?.roundToInt()
    }

    private fun parseAreaForecast(root: JsonObject?, neighbourhood: String?, target: GeoPoint): Pair<String, String>? {
        val data = root?.obj("data") ?: return null
        val metadata = data.arr("area_metadata") ?: data.arr("areaMetadata") ?: JsonArray()
        val points = metadata.mapNotNull { el ->
            val o = el.asJsonObjectOrNull() ?: return@mapNotNull null
            val name = o.string("name") ?: return@mapNotNull null
            val loc = o.obj("label_location") ?: o.obj("labelLocation") ?: return@mapNotNull null
            val lat = loc.double("latitude") ?: return@mapNotNull null
            val lon = loc.double("longitude") ?: return@mapNotNull null
            name to GeoPoint(lat, lon)
        }
        val desiredName = neighbourhood?.let { n ->
            points.minByOrNull { (_, pt) -> namePenalty(n, it.first) + haversineKm(target, pt) }?.first
        } ?: points.minByOrNull { haversineKm(target, it.second) }?.first

        val records = data.arr("items") ?: data.arr("records") ?: return null
        val latest = records.lastOrNull()?.asJsonObjectOrNull() ?: records.firstOrNull()?.asJsonObjectOrNull() ?: return null
        val forecasts = latest.arr("forecasts") ?: return null
        val chosen = forecasts.mapNotNull { it.asJsonObjectOrNull() }.firstOrNull {
            val area = it.string("area") ?: it.string("name") ?: ""
            desiredName != null && area.equals(desiredName, ignoreCase = true)
        } ?: forecasts.firstOrNull()?.asJsonObjectOrNull()
        val area = chosen?.string("area") ?: chosen?.string("name") ?: desiredName ?: "Singapore"
        val forecast = chosen?.string("forecast") ?: return null
        return area to forecast
    }

    private data class General24(val forecast: String, val low: Int?, val high: Int?, val periods: List<ForecastPeriod>)
    private fun parse24Hour(root: JsonObject?): General24 {
        val data = root?.obj("data") ?: return General24("", null, null, emptyList())
        val records = data.arr("records") ?: data.arr("items") ?: return General24("", null, null, emptyList())
        val record = records.firstOrNull()?.asJsonObjectOrNull() ?: return General24("", null, null, emptyList())
        val general = record.obj("general") ?: record
        val temp = general.obj("temperature")
        val low = temp?.double("low")?.roundToInt()
        val high = temp?.double("high")?.roundToInt()
        val forecast = general.string("forecast") ?: ""
        val periods = (record.arr("periods") ?: JsonArray()).mapIndexedNotNull { idx, el ->
            val o = el.asJsonObjectOrNull() ?: return@mapIndexedNotNull null
            val regions = o.obj("regions") ?: return@mapIndexedNotNull null
            ForecastPeriod(
                label = listOf("Later", "Next", "After").getOrElse(idx) { "Later" },
                west = regions.string("west") ?: "—", east = regions.string("east") ?: "—",
                central = regions.string("central") ?: "—", south = regions.string("south") ?: "—",
                north = regions.string("north") ?: "—",
            )
        }
        return General24(forecast, low, high, periods)
    }

    private fun parseFourDay(root: JsonObject?): List<OutlookDay> {
        val data = root?.obj("data") ?: return emptyList()
        val records = data.arr("records") ?: data.arr("items") ?: return emptyList()
        val record = records.firstOrNull()?.asJsonObjectOrNull() ?: return emptyList()
        val forecasts = record.arr("forecasts") ?: record.arr("items") ?: return emptyList()
        return forecasts.mapNotNull { el ->
            val o = el.asJsonObjectOrNull() ?: return@mapNotNull null
            val temp = o.obj("temperature")
            OutlookDay(
                date = o.string("date") ?: "",
                forecast = o.string("forecast") ?: "",
                low = temp?.double("low")?.roundToInt(),
                high = temp?.double("high")?.roundToInt(),
            )
        }.take(4)
    }

    private fun neighbourhoodPoint(name: String?): GeoPoint {
        val n = name.orEmpty().trim().lowercase(Locale.US)
        return neighbourhoodCentres.entries.firstOrNull { n.contains(it.key) || it.key.contains(n) && n.isNotBlank() }?.value
            ?: neighbourhoodCentres["central"]!!
    }

    private fun nearest(values: List<StationValue>, target: GeoPoint): StationValue? =
        values.minByOrNull { haversineKm(target, it.point) }

    private fun namePenalty(query: String, candidate: String): Double {
        val q = query.lowercase(Locale.US).replace("-", " ")
        val c = candidate.lowercase(Locale.US).replace("-", " ")
        return if (q.contains(c) || c.contains(q)) -50.0 else 0.0
    }

    private fun haversineKm(a: GeoPoint, b: GeoPoint): Double {
        val r = 6371.0
        val dLat = Math.toRadians(b.lat - a.lat)
        val dLon = Math.toRadians(b.lon - a.lon)
        val x = sin(dLat / 2).pow(2) + cos(Math.toRadians(a.lat)) * cos(Math.toRadians(b.lat)) * sin(dLon / 2).pow(2)
        return 2 * r * asin(sqrt(x))
    }

    // ── legacy fallback ──────────────────────────────────────────────────

    private suspend fun fetchLegacyAdvisory(): CareAdvisory {
        val forecast = fetchJson("$V1/24-hour-weather-forecast")
        val rainfall = runCatching { fetchJson("$V1/rainfall") }.getOrNull()
        val uv = runCatching { fetchJson("$V1/uv-index") }.getOrNull()

        val item = forecast.arr("items")?.firstOrNull()?.asJsonObjectOrNull()
        val general = item?.obj("general")
        val text = general?.string("forecast") ?: "Singapore conditions"
        val high = general?.obj("temperature")?.double("high")?.roundToInt()
        val low = general?.obj("temperature")?.double("low")?.roundToInt()
        val rainReadings = rainfall?.arr("items")?.firstOrNull()?.asJsonObjectOrNull()?.arr("readings")
        val rainValues = rainReadings?.mapNotNull { it.asJsonObjectOrNull()?.double("value") } ?: emptyList()
        val avg = rainValues.takeIf { it.isNotEmpty() }?.average() ?: 0.0
        val uvValue = uv?.arr("items")?.firstOrNull()?.asJsonObjectOrNull()?.arr("index")?.firstOrNull()?.asJsonObjectOrNull()?.double("value")?.roundToInt()
        return buildAdvisory(null, avg, text, high, uvValue, null).copy(
            temperatureLow = low,
            totalStations = rainValues.size,
            stationsReportingRain = rainValues.count { it > 0 },
            locationLabel = "Singapore",
        )
    }

    private fun fetchJson(url: String): JsonObject {
        val request = Request.Builder().url(url).header("Accept", "application/json").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("HTTP ${response.code}")
            val body = response.body?.string() ?: throw IOException("Empty body")
            return JsonParser.parseString(body).asJsonObject
        }
    }

    // Safe Gson helpers, because public API fields occasionally evolve.
    private fun JsonObject.obj(name: String): JsonObject? = get(name)?.takeIf { it.isJsonObject }?.asJsonObject
    private fun JsonObject.arr(name: String): JsonArray? = get(name)?.takeIf { it.isJsonArray }?.asJsonArray
    private fun JsonObject.string(name: String): String? = get(name)?.takeIf { it.isJsonPrimitive }?.asString
    private fun JsonObject.double(name: String): Double? = runCatching { get(name)?.asDouble }.getOrNull()
    private fun JsonElement.asJsonObjectOrNull(): JsonObject? = takeIf { it.isJsonObject }?.asJsonObject
}
