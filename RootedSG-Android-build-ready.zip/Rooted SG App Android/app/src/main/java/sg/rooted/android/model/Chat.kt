package sg.rooted.android.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

/**
 * A local mirror of the backend's conversation store — the backend is the
 * source of truth for delivery (see network/ChatService.kt and
 * backend/chatStore.mjs); this just lets the thread render instantly and
 * stay readable offline.
 */
@Entity(tableName = "chat_threads")
data class ChatThread(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val ownerId: String,
    val listingId: String,
    val listingHeadline: String,
    val produce: ProduceKind,
    val otherPartyId: String,
    val otherPartyName: String,
    val otherPartyAvatar: String = "🌱",
    /** True when the other side is a fictional seeded grower with no real backend account. */
    val isSeededOtherParty: Boolean = false,
    var remoteConversationId: String = "",
    var lastMessagePreview: String = "",
    var lastMessageDate: Long = System.currentTimeMillis(),
    val createdDate: Long = System.currentTimeMillis(),
)

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val threadId: String,
    val text: String,
    val isMine: Boolean,
    val senderName: String,
    val createdDate: Long = System.currentTimeMillis(),
    /** A locally-scripted reply from a seeded grower — not AI, not a real person. */
    val isSimulated: Boolean = false,
    /** The backend's own message id, once sent — used to de-duplicate on each poll. */
    val remoteId: String = "",
)
