package sg.rooted.android.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

/** One verified (or rejected) check-in event — the immutable ledger row. */
@Entity(tableName = "check_ins")
data class CheckIn(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val plantId: String,
    val date: Long,
    val imageFilename: String,
    val confidence: ConfidenceLevel,
    val verified: Boolean,
    val vegetationDetected: Boolean,
    val greenRatio: Double,
    val duplicateFlag: Boolean,
    val healthAtCheckIn: HealthStatus,
    val healthScoreAtCheckIn: Int = 88,
    /** How many Verified Plant-Days this single event credited — 0 or 1, never a catch-up. */
    val daysAwarded: Int,
    val note: String,
)
