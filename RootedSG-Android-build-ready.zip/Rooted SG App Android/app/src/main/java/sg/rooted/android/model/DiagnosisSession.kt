package sg.rooted.android.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.UUID

/**
 * One persisted "Save Your Plant" investigation.  It is deliberately separate
 * from CheckIn: a photo can be a valid plant-day verification without implying
 * that ROOTED has diagnosed a health issue, and a rescue can span multiple
 * app launches until a later re-check proves improvement.
 */
@Entity(tableName = "diagnosis_sessions")
data class DiagnosisSession(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val ownerId: String,
    val plantId: String,
    val createdDate: Long = System.currentTimeMillis(),
    var updatedDate: Long = System.currentTimeMillis(),
    var status: DiagnosisStatus = DiagnosisStatus.CLUES,
    var source: DiagnosisSource = DiagnosisSource.LOCAL,
    var headline: String = "",
    /** JSON arrays keep the schema resilient while the clue/choice copy evolves. */
    var cluesRaw: String = "[]",
    var choicesRaw: String = "[]",
    var likelyCause: String = "",
    var userChoice: String = "",
    var nextAction: String = "",
    var observeNext: String = "",
    var weatherContext: String = "",
    var baselineHealthScore: Int = 100,
    var recheckHealthScore: Int? = null,
    var diagnosisXP: Int = 0,
    var treatmentQuestId: String? = null,
    var completedDate: Long? = null,
) {
    val clues: List<DiagnosisClue> get() = DiagnosisCodec.cluesFrom(cluesRaw)
    val choices: List<DiagnosisChoice> get() = DiagnosisCodec.choicesFrom(choicesRaw)
    val isResolved: Boolean get() = status == DiagnosisStatus.COMPLETE

    fun withClues(items: List<DiagnosisClue>): DiagnosisSession = copy(cluesRaw = DiagnosisCodec.cluesTo(items))
    fun withChoices(items: List<DiagnosisChoice>): DiagnosisSession = copy(choicesRaw = DiagnosisCodec.choicesTo(items))
}

data class DiagnosisClue(
    val icon: String,
    val title: String,
    val detail: String,
    val confidence: Double = 0.5,
)

data class DiagnosisChoice(
    val label: String,
    val emoji: String,
    val rationale: String = "",
)

enum class DiagnosisStatus { CLUES, YOUR_READ, VERDICT, TREATMENT, RECHECK, COMPLETE }
enum class DiagnosisSource { LOCAL, CLOUD, HYBRID }

/** Small JSON codec so Room only needs primitive columns. */
object DiagnosisCodec {
    private val gson = Gson()
    private val clueType = object : TypeToken<List<DiagnosisClue>>() {}.type
    private val choiceType = object : TypeToken<List<DiagnosisChoice>>() {}.type

    fun cluesTo(items: List<DiagnosisClue>): String = gson.toJson(items)
    fun choicesTo(items: List<DiagnosisChoice>): String = gson.toJson(items)
    fun cluesFrom(raw: String): List<DiagnosisClue> = runCatching<List<DiagnosisClue>> {
        gson.fromJson(raw.ifBlank { "[]" }, clueType)
    }.getOrDefault(emptyList())
    fun choicesFrom(raw: String): List<DiagnosisChoice> = runCatching<List<DiagnosisChoice>> {
        gson.fromJson(raw.ifBlank { "[]" }, choiceType)
    }.getOrDefault(emptyList())
}
