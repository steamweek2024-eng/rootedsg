package sg.rooted.android.model

// ═══════════════════════════════════════════════════════════════════════════
// Core enums — a straight port of the iOS app's Models/Enums.kt and
// Models/Plant.swift value types. Colour/icon resolution lives in the ui.theme
// package instead of here, so this layer stays framework-agnostic (Room
// entities reference these directly).
// ═══════════════════════════════════════════════════════════════════════════

enum class PlantStage(val order: Int, val emoji: String, val displayName: String, val unlockDescription: String, val thresholdDays: Int) {
    SPROUT(0, "🌱", "Sprout", "Registration and first verified check-in.", 0),
    GROWING(1, "🌿", "Growing", "Multiple consecutive verified check-ins.", 14),
    BLOOMING(2, "🌺", "Blooming", "Verified flowering, fruiting or comparable visible growth.", 30),
    VETERAN(3, "🌳", "Veteran", "Long-term verified survival across many check-ins.", 90),
    LEGACY(4, "✨", "Legacy Plant", "Sustained survival plus recovery from a struggling period.", 180);

    companion object {
        val ordered: List<PlantStage> = entries.sortedBy { it.order }
    }
}

enum class HealthStatus(val label: String) {
    HEALTHY("Healthy"),
    RECOVERING("Recovering"),
    STRUGGLING("Struggling"),
    AT_RISK("Needs Check-in"),
    DECEASED("Lost"),
}

enum class ConfidenceLevel(val label: String) {
    HIGH("High confidence"),
    MEDIUM("Medium confidence"),
    LOW("Low confidence"),
}

enum class ObservationCategory(val label: String, val emoji: String) {
    BUTTERFLY("Butterfly", "🦋"),
    BEE("Bee", "🐝"),
    BIRD("Bird", "🐦"),
    BEETLE("Beetle", "🪲"),
    DRAGONFLY("Dragonfly", "🐉"),
    OTHER_INSECT("Other Insect", "🐛"),
    PLANT("Plant", "🪴"),
}

enum class VerificationStatus(val label: String) {
    AI_SUGGESTED("AI Suggested"),
    COMMUNITY_CONFIRMED("Community Confirmed"),
    EXPERT_VERIFIED("Expert Verified"),
}

enum class QuestType(val label: String) {
    CARE("Care Quest"),
    RECOVERY("Recovery Quest"),
    BIODIVERSITY("Biodiversity Quest"),
    EXPLORATION("Exploration Quest"),
    COMMUNITY("Community Quest"),
    SCHOOL("School Quest"),
}

enum class QuestStatus { ACTIVE, COMPLETED }

/**
 * [wireValue] must match the iOS app's Swift `rawValue` strings exactly
 * (camelCase, e.g. "ladiesFinger") — both platforms' clients serialize this
 * to the same backend field, and a listing one platform posts must decode
 * correctly as the same produce kind on the other.
 */
enum class ProduceKind(val label: String, val emoji: String, val weeksToHarvest: Int, val wireValue: String) {
    TOMATO("Tomatoes", "🍅", 12, "tomato"),
    CHILLI("Chillies", "🌶️", 10, "chilli"),
    BASIL("Basil", "🌿", 6, "basil"),
    MINT("Mint", "🌱", 4, "mint"),
    PANDAN("Pandan", "🌾", 10, "pandan"),
    KANGKONG("Kangkong", "🥬", 4, "kangkong"),
    LADIES_FINGER("Ladies' Finger", "🫛", 10, "ladiesFinger"),
    CURRY_LEAF("Curry Leaf", "🍃", 6, "curryLeaf"),
    SPRING_ONION("Spring Onion", "🧅", 4, "springOnion"),
    LEMONGRASS("Lemongrass", "🎋", 6, "lemongrass"),
    PAPAYA("Papaya", "🥭", 30, "papaya"),
    BANANA("Banana", "🍌", 30, "banana"),
    SWEET_POTATO("Sweet Potato", "🍠", 12, "sweetPotato"),
    OTHER("Other", "🧺", 8, "other");

    companion object {
        fun fromWireValue(value: String): ProduceKind = entries.firstOrNull { it.wireValue == value } ?: OTHER
    }
}

enum class ExchangeTerms(val label: String, val detail: String, val wireValue: String) {
    FREE("Free to a neighbour", "Given away. No money changes hands.", "free"),
    SWAP("Swap for produce", "Traded for something else home-grown.", "swap"),
    SMALL_PAYMENT("Small payment", "Settled directly between the two of you. ROOTED never handles the money.", "smallPayment");

    companion object {
        fun fromWireValue(value: String): ExchangeTerms = entries.firstOrNull { it.wireValue == value } ?: FREE
    }
}

enum class ListingStatus { OPEN, FULL, PAUSED, CLOSED }
enum class RequestStatus { OPEN, MATCHED, FULFILLED, CANCELLED }
enum class ExchangeStatus { PROPOSED, ACCEPTED, COMPLETED, DECLINED }

/** A Buy accepts the listing exactly as posted; an Offer proposes different terms. */
enum class ExchangeKind { BUY, OFFER }
