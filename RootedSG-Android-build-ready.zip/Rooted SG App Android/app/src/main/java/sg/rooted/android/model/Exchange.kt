package sg.rooted.android.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

// ═══════════════════════════════════════════════════════════════════════════
// The Grower Exchange — ported from Models/Exchange.swift. ROOTED never
// processes money; a listing just introduces neighbours and gets out of the
// way. Terminology and rules match the iOS app exactly so the same backend
// can serve both without translation.
// ═══════════════════════════════════════════════════════════════════════════

@Entity(tableName = "produce_listings")
data class ProduceListing(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val ownerId: String,
    var produce: ProduceKind,
    var headline: String,
    var detail: String = "",
    var terms: ExchangeTerms = ExchangeTerms.FREE,
    var capacityHouseholds: Int = 2,
    var claimedCount: Int = 0,
    var neighbourhood: String,
    var status: ListingStatus = ListingStatus.OPEN,
    val createdDate: Long = System.currentTimeMillis(),
    val isSeeded: Boolean = false,
    /** A real grower's own UserProfile id, or a stable synthetic slug for a seeded demo grower. */
    var growerId: String = "",
    var growerName: String,
    var growerAvatar: String = "🌱",
    var growerPlantDays: Int = 0,
    var imageFilename: String? = null,
    var quantityLabel: String = "",
    var isSeedListing: Boolean = false,
    var stockTotal: Int = 0,
    var stockRemaining: Int = 0,
    /** Singapore cents; only meaningful when terms == SMALL_PAYMENT. */
    var priceSGDCents: Int = 0,
    /** True once pushed to (or pulled from) the backend — see MarketSyncEngine. */
    var isSynced: Boolean = false,
) {
    val spacesLeft: Int get() = maxOf(0, capacityHouseholds - claimedCount)
    val isStockTracked: Boolean get() = stockTotal > 0
    val stockRemainingClamped: Int get() = stockRemaining.coerceIn(0, stockTotal)
    val stockDisplay: String?
        get() = if (isStockTracked) "$stockRemainingClamped of $stockTotal left" else null
    val priceDisplay: String?
        get() = if (terms == ExchangeTerms.SMALL_PAYMENT && priceSGDCents > 0)
            "S$${"%.2f".format(priceSGDCents / 100.0)}" else null
    val isAvailable: Boolean
        get() = status == ListingStatus.OPEN && spacesLeft > 0 && (!isStockTracked || stockRemainingClamped > 0)
}

@Entity(tableName = "produce_requests")
data class ProduceRequest(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val ownerId: String,
    var produce: ProduceKind,
    var note: String = "",
    var neighbourhood: String,
    var status: RequestStatus = RequestStatus.OPEN,
    val createdDate: Long = System.currentTimeMillis(),
    val isSeeded: Boolean = false,
    var requesterName: String,
    var requesterAvatar: String = "🧺",
    var requesterId: String = "",
    var isSynced: Boolean = false,
)

@Entity(tableName = "exchanges")
data class Exchange(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val ownerId: String,
    val listingId: String,
    val produce: ProduceKind,
    var growerName: String,
    val takerName: String,
    val neighbourhood: String,
    val terms: ExchangeTerms,
    var status: ExchangeStatus = ExchangeStatus.PROPOSED,
    val kind: ExchangeKind = ExchangeKind.BUY,
    val createdDate: Long = System.currentTimeMillis(),
    val note: String = "",
    val units: Int = 1,
    var reservedSlot: Boolean = false,
    val userIsGrower: Boolean = false,
)
