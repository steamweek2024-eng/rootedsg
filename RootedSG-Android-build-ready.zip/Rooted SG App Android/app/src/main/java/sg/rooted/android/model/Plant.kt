package sg.rooted.android.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID
import java.util.concurrent.TimeUnit

/** Room's counterpart to SwiftData's `@Model final class Plant` — the digital-twin record. */
@Entity(tableName = "plants")
data class Plant(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val ownerId: String,
    var name: String,
    var species: String,
    var speciesEmoji: String,
    val registeredDate: Long,
    var stage: PlantStage = PlantStage.SPROUT,
    var health: HealthStatus = HealthStatus.HEALTHY,
    var imageFilename: String? = null,
    var lastCheckInDate: Long? = null,
    var verifiedPlantDays: Int = 0,
    var careStreak: Int = 0,
    var hadRecoveryEvent: Boolean = false,
    /** Comma-separated milestone-day thresholds already paid out, e.g. "7,30,90". */
    var awardedMilestoneDaysRaw: String = "",
    var notes: String = "",
    /** Numeric health makes recovery visible and comparable across check-ins. */
    var healthScore: Int = 88,
    /** Set only while a rescue is active; cleared after a successful re-check. */
    var rescueBaselineHealthScore: Int? = null,
) {
    val awardedMilestoneDays: List<Int>
        get() = awardedMilestoneDaysRaw.split(",").mapNotNull { it.trim().toIntOrNull() }

    fun withAwardedMilestoneDays(days: List<Int>): Plant =
        copy(awardedMilestoneDaysRaw = days.joinToString(","))

    fun ageInDays(now: Long = System.currentTimeMillis()): Int =
        TimeUnit.MILLISECONDS.toDays(now - registeredDate).toInt()

    fun daysSinceLastCheckIn(now: Long = System.currentTimeMillis()): Int {
        val last = lastCheckInDate ?: return ageInDays(now)
        return TimeUnit.MILLISECONDS.toDays(now - last).toInt()
    }

    fun isCheckInDue(now: Long = System.currentTimeMillis()): Boolean =
        health != HealthStatus.DECEASED && daysSinceLastCheckIn(now) >= 7

    val nextStage: PlantStage?
        get() {
            val all = PlantStage.ordered
            val idx = all.indexOf(stage)
            return if (idx >= 0 && idx + 1 < all.size) all[idx + 1] else null
        }

    val daysToNextStage: Int
        get() = nextStage?.let { maxOf(0, it.thresholdDays - verifiedPlantDays) } ?: 0

    val progressToNextStage: Double
        get() {
            val next = nextStage ?: return 1.0
            val lower = stage.thresholdDays.toDouble()
            val upper = next.thresholdDays.toDouble()
            if (upper <= lower) return 1.0
            return ((verifiedPlantDays - lower) / (upper - lower)).coerceIn(0.0, 1.0)
        }
}
