package sg.rooted.android.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.UUID

@Entity(tableName = "quests")
data class Quest(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val ownerId: String,
    val type: QuestType,
    var title: String,
    var detail: String,
    var target: Int,
    var progress: Int = 0,
    val rewardXP: Int,
    var status: QuestStatus = QuestStatus.ACTIVE,
    val createdDate: Long = System.currentTimeMillis(),
    var completedDate: Long? = null,
    val relatedPlantID: String? = null,
    /** JSON encoded [QuestObjective] rows used by rescue missions. */
    var objectivesRaw: String = "[]",
    /** The health score at the moment a rescue starts, used for the recovery payoff. */
    var baselineHealthScore: Int? = null,
    /** Rescue quests hold their payout until a later check-in demonstrates improvement. */
    var requiresRecheck: Boolean = false,
    /** Optional memorable label such as "Drowned Roots" or "The Infestation". */
    var bossName: String = "",
) {
    val objectives: List<QuestObjective> get() = QuestCodec.decode(objectivesRaw)
    val isComplete: Boolean get() = status == QuestStatus.COMPLETED
    val progressFraction: Double get() = if (target <= 0) 0.0 else (progress.toDouble() / target).coerceAtMost(1.0)
    val objectivesComplete: Boolean get() = objectives.isNotEmpty() && objectives.all { it.isComplete }

    fun withObjectives(items: List<QuestObjective>): Quest = copy(
        objectivesRaw = QuestCodec.encode(items),
        target = if (items.isEmpty()) target else items.size,
        progress = if (items.isEmpty()) progress else items.count { it.isComplete },
    )
}

data class QuestObjective(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val detail: String = "",
    val icon: String = "🌿",
    val isComplete: Boolean = false,
    val completedDate: Long? = null,
)

object QuestCodec {
    private val gson = Gson()
    private val type = object : TypeToken<List<QuestObjective>>() {}.type
    fun encode(items: List<QuestObjective>): String = gson.toJson(items)
    fun decode(raw: String): List<QuestObjective> = runCatching<List<QuestObjective>> {
        gson.fromJson(raw.ifBlank { "[]" }, type)
    }.getOrDefault(emptyList())
}
