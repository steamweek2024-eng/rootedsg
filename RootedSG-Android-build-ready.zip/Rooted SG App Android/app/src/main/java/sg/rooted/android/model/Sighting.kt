package sg.rooted.android.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "sightings")
data class Sighting(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val ownerId: String,
    val date: Long = System.currentTimeMillis(),
    val speciesName: String,
    val category: ObservationCategory,
    val imageFilename: String,
    val verification: VerificationStatus,
    val neighbourhood: String,
)
