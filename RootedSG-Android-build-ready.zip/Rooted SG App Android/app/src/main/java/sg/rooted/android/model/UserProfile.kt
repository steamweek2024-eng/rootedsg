package sg.rooted.android.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import sg.rooted.android.engine.GameEngine
import sg.rooted.android.engine.ShopCatalog
import java.util.UUID

/**
 * The local profile — one row, since this device only ever holds one signed-in
 * user at a time. `googleAccountId` is populated once the user links a real
 * Google account; empty means a purely local, offline profile.
 */
@Entity(tableName = "user_profile")
data class UserProfile(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    var name: String,
    var school: String,
    var avatarEmoji: String = "🌱",
    var neighbourhood: String = "Tampines",
    var xp: Int = 0,
    val joinDate: Long = System.currentTimeMillis(),
    var locationSharingOptIn: Boolean = true,
    var googleAccountId: String = "",
    var email: String = "",
    /** The Shop's spendable balance — see [GameEngine.award]. */
    var seeds: Int = 0,
    /** Comma-joined IDs of every [sg.rooted.android.engine.ShopItem] ever bought — see [ownedItemIds]. */
    var ownedItemIdsRaw: String = "",
    var equippedTitleId: String = "",
    var equippedFrameId: String = "",
    var equippedPotSkinId: String = "",
) {
    val isSignedIn: Boolean get() = googleAccountId.isNotEmpty()
    val level: Int get() = GameEngine.level(forXP = xp)
    val xpIntoCurrentLevel: Int get() = GameEngine.xpProgress(xp).first
    val xpForNextLevel: Int get() = GameEngine.xpProgress(xp).second

    val ownedItemIds: List<String>
        get() = ownedItemIdsRaw.split(",").map { it.trim() }.filter { it.isNotEmpty() }

    fun withOwnedItemIds(ids: List<String>): UserProfile = copy(ownedItemIdsRaw = ids.joinToString(","))

    fun owns(item: sg.rooted.android.engine.ShopItem): Boolean = ownedItemIds.contains(item.id)
    val equippedTitle get() = ShopCatalog.item(equippedTitleId)
    val equippedFrame get() = ShopCatalog.item(equippedFrameId)
    val equippedPotSkin get() = ShopCatalog.item(equippedPotSkinId)
}
