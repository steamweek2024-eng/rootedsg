package sg.rooted.android.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

/**
 * One entry in the XP ledger — a Room-backed port of iOS's XPEvent.swift.
 * Logged by GardenRepository right alongside every GameEngine.award(...) call,
 * so the Progress screen's activity feed shows what was actually earned, not
 * just a running total.
 */
@Entity(tableName = "xp_events")
data class XPEvent(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val ownerId: String,
    val amount: Int,
    val reason: String,
    /** An SF-Symbol-style name, matching iOS's icon strings — mapped to a
     * Material icon at the Compose layer (see xpEventIcon in ProgressScreen.kt). */
    val icon: String,
    val date: Long = System.currentTimeMillis(),
)
