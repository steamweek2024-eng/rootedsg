package sg.rooted.android.network

import com.google.gson.annotations.SerializedName

// ═══════════════════════════════════════════════════════════════════════════
// Wire DTOs — field names match backend/server.mjs exactly (snake_case JSON),
// mirroring iOS's SyncService/ChatService/CloudAIService Codable structs.
// ═══════════════════════════════════════════════════════════════════════════

data class GoogleAuthRequest(@SerializedName("id_token") val idToken: String)

data class AccountResponse(
    val id: String,
    val email: String,
    val name: String,
    val picture: String,
    @SerializedName("session_token") val sessionToken: String,
)

data class RemoteListing(
    val id: String,
    @SerializedName("owner_id") val ownerId: String,
    @SerializedName("owner_name") val ownerName: String,
    @SerializedName("owner_avatar") val ownerAvatar: String,
    @SerializedName("owner_plant_days") val ownerPlantDays: Int,
    val produce: String,
    val headline: String,
    val detail: String,
    val terms: String,
    @SerializedName("price_sgd_cents") val priceSGDCents: Int,
    @SerializedName("capacity_households") val capacityHouseholds: Int,
    @SerializedName("claimed_count") val claimedCount: Int,
    @SerializedName("stock_total") val stockTotal: Int,
    @SerializedName("stock_remaining") val stockRemaining: Int,
    @SerializedName("quantity_label") val quantityLabel: String,
    @SerializedName("is_seed_listing") val isSeedListing: Boolean,
    val neighbourhood: String,
    val status: String,
    @SerializedName("created_at") val createdAt: String,
)

data class ListingsEnvelope(val listings: List<RemoteListing>)

data class ListingUpsertRequest(
    val produce: String,
    val headline: String,
    val detail: String,
    val terms: String,
    @SerializedName("price_sgd_cents") val priceSGDCents: Int,
    @SerializedName("capacity_households") val capacityHouseholds: Int,
    @SerializedName("stock_total") val stockTotal: Int,
    @SerializedName("quantity_label") val quantityLabel: String,
    @SerializedName("is_seed_listing") val isSeedListing: Boolean,
    val neighbourhood: String,
    val status: String,
    @SerializedName("owner_name") val ownerName: String,
    @SerializedName("owner_avatar") val ownerAvatar: String,
    @SerializedName("owner_plant_days") val ownerPlantDays: Int,
)

data class ClaimRequest(val units: Int)

data class RemoteRequest(
    val id: String,
    @SerializedName("requester_id") val requesterId: String,
    @SerializedName("requester_name") val requesterName: String,
    @SerializedName("requester_avatar") val requesterAvatar: String,
    val produce: String,
    val note: String,
    val neighbourhood: String,
    val status: String,
    @SerializedName("created_at") val createdAt: String,
)

data class RequestsEnvelope(val requests: List<RemoteRequest>)

data class RequestUpsertRequest(
    val produce: String,
    val note: String,
    val neighbourhood: String,
    val status: String,
    @SerializedName("requester_name") val requesterName: String,
    @SerializedName("requester_avatar") val requesterAvatar: String,
)

data class ConversationRequest(
    @SerializedName("listing_id") val listingId: String,
    @SerializedName("listing_headline") val listingHeadline: String,
    @SerializedName("grower_id") val growerId: String,
    @SerializedName("grower_name") val growerName: String,
    @SerializedName("taker_id") val takerId: String,
    @SerializedName("taker_name") val takerName: String,
)

data class RemoteConversation(val id: String)

data class RemoteMessage(
    val id: String,
    @SerializedName("sender_id") val senderId: String,
    @SerializedName("sender_name") val senderName: String,
    val text: String,
    @SerializedName("created_at") val createdAt: String,
)

data class MessagesEnvelope(val messages: List<RemoteMessage>)

data class SendMessageRequest(
    @SerializedName("sender_id") val senderId: String,
    @SerializedName("sender_name") val senderName: String,
    val text: String,
)

data class RemoteErrorBody(val error: String)

data class AnalysisRequest(
    val task: String,
    @SerializedName("image_base64") val imageBase64: String,
    @SerializedName("mime_type") val mimeType: String,
    @SerializedName("plant_species") val plantSpecies: String?,
    @SerializedName("client_user_id") val clientUserId: String?,
)

data class AnalysisEnvelope<T>(val analysis: T)

data class SpeciesCandidate(
    val name: String,
    @SerializedName("scientific_name") val scientificName: String,
    val confidence: Double,
    val rationale: String,
)

data class SpeciesAnalysis(
    val candidates: List<SpeciesCandidate>,
    @SerializedName("manual_confirmation_required") val manualConfirmationRequired: Boolean,
)

data class DoctorCause(
    @SerializedName("possible_cause") val possibleCause: String,
    @SerializedName("why_plausible") val whyPlausible: String,
)

data class DoctorAnalysis(
    val headline: String,
    val severity: String,
    val causes: List<DoctorCause>,
    @SerializedName("next_action") val nextAction: String,
    @SerializedName("observe_next") val observeNext: String,
)

data class BiodiversityCandidate(
    val name: String,
    val category: String,
    val confidence: Double,
    val rationale: String,
)

data class BiodiversityAnalysis(
    val candidates: List<BiodiversityCandidate>,
    @SerializedName("manual_confirmation_required") val manualConfirmationRequired: Boolean,
)
