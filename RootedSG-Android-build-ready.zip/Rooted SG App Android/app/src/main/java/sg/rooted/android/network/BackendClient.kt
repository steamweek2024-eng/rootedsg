package sg.rooted.android.network

import com.google.gson.Gson
import com.google.gson.JsonObject
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import sg.rooted.android.BuildConfig
import java.util.Base64
import java.util.concurrent.TimeUnit

/** What every wrapper method below can throw — mirrors each iOS service's own `ServiceError`. */
sealed class ServiceError(message: String) : Exception(message) {
    object Unavailable : ServiceError("This isn't configured on this build.")
    object NotSignedIn : ServiceError("Sign in to sync across devices.")
    class Remote(message: String) : ServiceError(message)
    object Malformed : ServiceError("The server returned an unexpected response.")
}

/**
 * Talks to the same ROOTED backend the iOS app uses (backend/server.mjs) —
 * plain REST, polled rather than pushed. One client for account sync, chat,
 * and AI plant analysis, exactly like the iOS app sharing one endpoint
 * resolution across SyncService/ChatService/CloudAIService.
 */
object BackendClient {
    private val gson = Gson()

    private val api: RootedApi? by lazy {
        val base = Endpoint.baseUrl ?: return@lazy null
        val logging = HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BASIC else HttpLoggingInterceptor.Level.NONE
        }
        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()
        Retrofit.Builder()
            .baseUrl(base)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()
            .create(RootedApi::class.java)
    }

    val isConfigured: Boolean get() = Endpoint.isConfigured

    private fun <T> unwrap(response: Response<T>): T {
        if (response.isSuccessful) {
            return response.body() ?: throw ServiceError.Malformed
        }
        if (response.code() == 401) throw ServiceError.NotSignedIn
        val message = try {
            response.errorBody()?.string()?.let { gson.fromJson(it, RemoteErrorBody::class.java)?.error }
        } catch (e: Exception) { null } ?: "The server is temporarily unavailable."
        throw ServiceError.Remote(message)
    }

    private fun requireApi(): RootedApi = api ?: throw ServiceError.Unavailable

    private fun wrap(block: () -> Unit) {
        try { block() } catch (e: ServiceError) { throw e } catch (e: Exception) {
            throw ServiceError.Remote("Couldn't reach the server. Check your connection and try again.")
        }
    }

    // MARK: Account

    suspend fun signInWithGoogle(idToken: String): AccountResponse {
        val api = requireApi()
        return try { unwrap(api.signInWithGoogle(GoogleAuthRequest(idToken))) }
        catch (e: ServiceError) { throw e }
        catch (e: Exception) { throw ServiceError.Remote("Couldn't reach the server. Check your connection and try again.") }
    }

    // MARK: Listings

    suspend fun fetchListings(neighbourhood: String? = null): List<RemoteListing> {
        val api = requireApi()
        return try { unwrap(api.fetchListings(neighbourhood)).listings }
        catch (e: ServiceError) { throw e }
        catch (e: Exception) { throw ServiceError.Remote("Couldn't reach the server. Check your connection and try again.") }
    }

    suspend fun pushListing(
        id: String, sessionToken: String, produce: String, headline: String, detail: String, terms: String,
        priceSGDCents: Int, capacityHouseholds: Int, stockTotal: Int, quantityLabel: String, isSeedListing: Boolean,
        neighbourhood: String, status: String, ownerName: String, ownerAvatar: String, ownerPlantDays: Int,
    ): RemoteListing {
        val api = requireApi()
        val body = ListingUpsertRequest(
            produce, headline, detail, terms, priceSGDCents, capacityHouseholds, stockTotal,
            quantityLabel, isSeedListing, neighbourhood, status, ownerName, ownerAvatar, ownerPlantDays
        )
        return try { unwrap(api.pushListing(id, "Bearer $sessionToken", body)) }
        catch (e: ServiceError) { throw e }
        catch (e: Exception) { throw ServiceError.Remote("Couldn't reach the server. Check your connection and try again.") }
    }

    suspend fun claimListing(id: String, sessionToken: String, units: Int): RemoteListing {
        val api = requireApi()
        return try { unwrap(api.claimListing(id, "Bearer $sessionToken", ClaimRequest(units))) }
        catch (e: ServiceError) { throw e }
        catch (e: Exception) { throw ServiceError.Remote("Couldn't reach the server. Check your connection and try again.") }
    }

    // MARK: Requests

    suspend fun fetchRequests(neighbourhood: String? = null): List<RemoteRequest> {
        val api = requireApi()
        return try { unwrap(api.fetchRequests(neighbourhood)).requests }
        catch (e: ServiceError) { throw e }
        catch (e: Exception) { throw ServiceError.Remote("Couldn't reach the server. Check your connection and try again.") }
    }

    suspend fun pushRequest(
        id: String, sessionToken: String, produce: String, note: String, neighbourhood: String, status: String,
        requesterName: String, requesterAvatar: String,
    ): RemoteRequest {
        val api = requireApi()
        val body = RequestUpsertRequest(produce, note, neighbourhood, status, requesterName, requesterAvatar)
        return try { unwrap(api.pushRequest(id, "Bearer $sessionToken", body)) }
        catch (e: ServiceError) { throw e }
        catch (e: Exception) { throw ServiceError.Remote("Couldn't reach the server. Check your connection and try again.") }
    }

    // MARK: Chat

    suspend fun startConversation(
        listingId: String, listingHeadline: String, growerId: String, growerName: String, takerId: String, takerName: String,
        sessionToken: String,
    ): String {
        val api = requireApi()
        val body = ConversationRequest(listingId, listingHeadline, growerId, growerName, takerId, takerName)
        return try { unwrap(api.startConversation("Bearer $sessionToken", body)).id }
        catch (e: ServiceError) { throw e }
        catch (e: Exception) { throw ServiceError.Remote("Couldn't reach the server. Check your connection and try again.") }
    }

    suspend fun fetchMessages(conversationId: String, sessionToken: String, since: Long? = null): List<RemoteMessage> {
        val api = requireApi()
        val sinceIso = since?.let { Iso8601.format(it) }
        return try { unwrap(api.fetchMessages(conversationId, "Bearer $sessionToken", sinceIso)).messages }
        catch (e: ServiceError) { throw e }
        catch (e: Exception) { throw ServiceError.Remote("Couldn't reach the server. Check your connection and try again.") }
    }

    suspend fun sendMessage(conversationId: String, sessionToken: String, senderName: String, text: String): RemoteMessage {
        val api = requireApi()
        // The server derives sender_id from the authenticated session; the body field is kept for wire compatibility.
        return try { unwrap(api.sendMessage(conversationId, "Bearer $sessionToken", SendMessageRequest("", senderName, text))) }
        catch (e: ServiceError) { throw e }
        catch (e: Exception) { throw ServiceError.Remote("Couldn't reach the server. Check your connection and try again.") }
    }

    // MARK: AI plant analysis

    suspend fun suggestSpecies(jpegBytes: ByteArray, clientUserId: String?): SpeciesAnalysis {
        val json = analyse("species", jpegBytes, null, clientUserId)
        return gson.fromJson(json, SpeciesAnalysis::class.java)
    }

    suspend fun plantDoctorReport(jpegBytes: ByteArray, species: String?, clientUserId: String?): DoctorAnalysis {
        val json = analyse("doctor", jpegBytes, species, clientUserId)
        return gson.fromJson(json, DoctorAnalysis::class.java)
    }

    suspend fun biodiversitySuggestions(jpegBytes: ByteArray, clientUserId: String?): BiodiversityAnalysis {
        val json = analyse("biodiversity", jpegBytes, null, clientUserId)
        return gson.fromJson(json, BiodiversityAnalysis::class.java)
    }

    private suspend fun analyse(task: String, jpegBytes: ByteArray, species: String?, clientUserId: String?): JsonObject {
        val api = requireApi()
        val body = AnalysisRequest(
            task = task,
            imageBase64 = Base64.getEncoder().encodeToString(jpegBytes),
            mimeType = "image/jpeg",
            plantSpecies = species,
            clientUserId = clientUserId,
        )
        val envelope = try { unwrap(api.analyse(body)) }
        catch (e: ServiceError) { throw e }
        catch (e: Exception) { throw ServiceError.Remote("Cloud analysis is temporarily unavailable.") }
        return envelope.getAsJsonObject("analysis") ?: throw ServiceError.Malformed
    }
}
