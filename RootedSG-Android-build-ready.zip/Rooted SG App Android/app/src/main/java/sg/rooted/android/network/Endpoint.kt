package sg.rooted.android.network

import sg.rooted.android.BuildConfig
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * Same backend the iOS app talks to (see backend/server.mjs) — plain REST,
 * polled rather than pushed. Debug builds default to the emulator's alias for
 * the host Mac's localhost (10.0.2.2); a real device on the same network
 * would need the Mac's LAN IP instead. Release builds need a real HTTPS URL
 * baked into AI_BASE_URL_RELEASE before this ships anywhere.
 */
object Endpoint {
    val baseUrl: String? = run {
        val raw = if (BuildConfig.DEBUG) BuildConfig.AI_BASE_URL_DEBUG else BuildConfig.AI_BASE_URL_RELEASE
        if (raw.isBlank()) return@run null
        val normalized = if (raw.endsWith("/")) raw else "$raw/"
        normalized
    }

    val isConfigured: Boolean get() = baseUrl != null
}

/** The backend encodes dates as ISO-8601 UTC (`Date.toISOString()`); this reverses that. */
object Iso8601 {
    private fun formatter() = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    fun parseToEpochMillis(value: String?): Long {
        if (value.isNullOrBlank()) return System.currentTimeMillis()
        return try {
            formatter().parse(value)?.time ?: System.currentTimeMillis()
        } catch (e: Exception) {
            // A handful of ISO-8601 variants (no millis, explicit +00:00 offset)
            // show up in practice; fall back to a couple of common shapes.
            try {
                SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
                    .apply { timeZone = TimeZone.getTimeZone("UTC") }
                    .parse(value)?.time ?: System.currentTimeMillis()
            } catch (e2: Exception) {
                System.currentTimeMillis()
            }
        }
    }

    fun format(epochMillis: Long): String = formatter().format(java.util.Date(epochMillis))
}
