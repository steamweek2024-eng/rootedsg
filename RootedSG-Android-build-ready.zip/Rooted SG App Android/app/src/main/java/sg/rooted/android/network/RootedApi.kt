package sg.rooted.android.network

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.PUT
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

/** One-to-one with backend/server.mjs's routes. */
interface RootedApi {

    @POST("v1/auth/google")
    suspend fun signInWithGoogle(@Body body: GoogleAuthRequest): Response<AccountResponse>

    @GET("v1/listings")
    suspend fun fetchListings(@Query("neighbourhood") neighbourhood: String? = null): Response<ListingsEnvelope>

    @PUT("v1/listings/{id}")
    suspend fun pushListing(
        @Path("id") id: String,
        @Header("Authorization") authorization: String,
        @Body body: ListingUpsertRequest,
    ): Response<RemoteListing>

    @POST("v1/listings/{id}/claim")
    suspend fun claimListing(
        @Path("id") id: String,
        @Header("Authorization") authorization: String,
        @Body body: ClaimRequest,
    ): Response<RemoteListing>

    @GET("v1/requests")
    suspend fun fetchRequests(@Query("neighbourhood") neighbourhood: String? = null): Response<RequestsEnvelope>

    @PUT("v1/requests/{id}")
    suspend fun pushRequest(
        @Path("id") id: String,
        @Header("Authorization") authorization: String,
        @Body body: RequestUpsertRequest,
    ): Response<RemoteRequest>

    @POST("v1/conversations")
    suspend fun startConversation(
        @Header("Authorization") authorization: String,
        @Body body: ConversationRequest,
    ): Response<RemoteConversation>

    @GET("v1/conversations/{id}/messages")
    suspend fun fetchMessages(
        @Path("id") id: String,
        @Header("Authorization") authorization: String,
        @Query("since") since: String? = null,
    ): Response<MessagesEnvelope>

    @POST("v1/conversations/{id}/messages")
    suspend fun sendMessage(
        @Path("id") id: String,
        @Header("Authorization") authorization: String,
        @Body body: SendMessageRequest,
    ): Response<RemoteMessage>

    @POST("v1/plant-analysis")
    suspend fun analyse(@Body body: AnalysisRequest): Response<com.google.gson.JsonObject>
}
