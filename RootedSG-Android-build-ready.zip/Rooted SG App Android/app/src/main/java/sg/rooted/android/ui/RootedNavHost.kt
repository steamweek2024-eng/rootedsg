package sg.rooted.android.ui

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import androidx.compose.runtime.collectAsState
import sg.rooted.android.RootedViewModel
import sg.rooted.android.ui.biodex.LogObservationScreen
import sg.rooted.android.ui.community.CommunityScreen
import sg.rooted.android.ui.exchange.ChatThreadScreen
import sg.rooted.android.ui.exchange.ListingDetailScreen
import sg.rooted.android.ui.garden.CheckInScreen
import sg.rooted.android.ui.garden.PlantDetailScreen
import sg.rooted.android.ui.garden.RegisterPlantScreen
import sg.rooted.android.ui.onboarding.OnboardingScreen
import sg.rooted.android.ui.pet.PetScreen
import sg.rooted.android.ui.profile.ProfileScreen
import sg.rooted.android.ui.profile.ThemePickerScreen
import sg.rooted.android.ui.root.RootShell
import sg.rooted.android.ui.theme.ThemeStore

object Routes {
    const val ONBOARDING = "onboarding"
    const val SHELL = "shell"
    const val REGISTER = "register"
    const val CHECK_IN = "checkin/{plantId}"
    const val PLANT_DETAIL = "plant/{plantId}"
    const val LISTING_DETAIL = "listing/{listingId}"
    const val CHAT_THREAD = "chat/{threadId}"
    const val LOG_OBSERVATION = "biodexLog"
    const val PROFILE = "profile"
    const val COMMUNITY = "community"
    const val THEME_PICKER = "themePicker"
    const val SHOP = "shop"
    const val PROGRESS = "progress"
    const val PET = "pet"

    fun checkIn(plantId: String) = "checkin/$plantId"
    fun plantDetail(plantId: String) = "plant/$plantId"
    fun listingDetail(listingId: String) = "listing/$listingId"
    fun chatThread(threadId: String) = "chat/$threadId"
}

// One consistent motion language for every pushed screen — a soft rise-and-fade in,
// a gentle sink-and-fade back out, echoing the iOS app's own easeOutQuint-style
// RootedMotion curves (Compose has no direct cubic-bezier helper here, so a plain
// tween stands in for the same "arrives quickly, settles slowly" feel).
private const val kMotionDurationMs = 320
private val kEnter = fadeIn(tween(kMotionDurationMs)) + slideInVertically(tween(kMotionDurationMs)) { it / 10 }
private val kExit = fadeOut(tween(220))
private val kPopEnter = fadeIn(tween(kMotionDurationMs))
private val kPopExit = fadeOut(tween(220)) + slideOutVertically(tween(220)) { it / 10 }
private val kFadeEnter = fadeIn(tween(360))
private val kFadeExit = fadeOut(tween(220))

@Composable
fun RootedNavHost(navController: NavHostController, viewModel: RootedViewModel, themeStore: ThemeStore) {
    val user by viewModel.user.collectAsState()
    val startDestination = if (user == null) Routes.ONBOARDING else Routes.SHELL

    NavHost(
        navController = navController, startDestination = startDestination,
        enterTransition = { kEnter }, exitTransition = { kExit },
        popEnterTransition = { kPopEnter }, popExitTransition = { kPopExit },
    ) {
        composable(
            Routes.ONBOARDING,
            enterTransition = { kFadeEnter }, exitTransition = { kFadeExit },
        ) {
            OnboardingScreen(viewModel = viewModel) {
                navController.navigate(Routes.SHELL) {
                    popUpTo(Routes.ONBOARDING) { inclusive = true }
                }
            }
        }
        composable(
            Routes.SHELL,
            enterTransition = { kFadeEnter }, exitTransition = { kFadeExit },
            popEnterTransition = { kFadeEnter }, popExitTransition = { kFadeExit },
        ) {
            RootShell(
                navController = navController, viewModel = viewModel,
                onOpenPet = { navController.navigate(Routes.PET) },
            )
        }
        composable(Routes.REGISTER) {
            RegisterPlantScreen(viewModel = viewModel, onClose = { navController.popBackStack() })
        }
        composable(
            Routes.CHECK_IN,
            arguments = listOf(navArgument("plantId") { type = NavType.StringType }),
        ) { entry ->
            val plantId = entry.arguments?.getString("plantId").orEmpty()
            CheckInScreen(viewModel = viewModel, plantId = plantId, onClose = { navController.popBackStack() })
        }
        composable(
            Routes.PLANT_DETAIL,
            arguments = listOf(navArgument("plantId") { type = NavType.StringType }),
        ) { entry ->
            val plantId = entry.arguments?.getString("plantId").orEmpty()
            PlantDetailScreen(
                viewModel = viewModel, plantId = plantId,
                onClose = { navController.popBackStack() },
                onCheckIn = { navController.navigate(Routes.checkIn(plantId)) },
            )
        }
        composable(
            Routes.LISTING_DETAIL,
            arguments = listOf(navArgument("listingId") { type = NavType.StringType }),
        ) { entry ->
            val listingId = entry.arguments?.getString("listingId").orEmpty()
            ListingDetailScreen(
                viewModel = viewModel, listingId = listingId,
                onClose = { navController.popBackStack() },
                onChat = { threadId -> navController.navigate(Routes.chatThread(threadId)) },
            )
        }
        composable(
            Routes.CHAT_THREAD,
            arguments = listOf(navArgument("threadId") { type = NavType.StringType }),
        ) { entry ->
            val threadId = entry.arguments?.getString("threadId").orEmpty()
            ChatThreadScreen(viewModel = viewModel, threadId = threadId, onClose = { navController.popBackStack() })
        }
        composable(Routes.LOG_OBSERVATION) {
            LogObservationScreen(viewModel = viewModel, onClose = { navController.popBackStack() })
        }
        composable(Routes.PROFILE) {
            ProfileScreen(
                viewModel = viewModel, onClose = { navController.popBackStack() },
                onOpenTheme = { navController.navigate(Routes.THEME_PICKER) },
                onOpenShop = { navController.navigate(Routes.SHOP) },
                onOpenPet = { navController.navigate(Routes.PET) },
            )
        }
        composable(Routes.PET) {
            PetScreen(viewModel = viewModel, onClose = { navController.popBackStack() })
        }
        composable(Routes.COMMUNITY) {
            CommunityScreen(viewModel = viewModel, onClose = { navController.popBackStack() })
        }
        composable(Routes.THEME_PICKER) {
            ThemePickerScreen(themeStore = themeStore, onClose = { navController.popBackStack() })
        }
        composable(Routes.SHOP) {
            sg.rooted.android.ui.profile.ShopScreen(viewModel = viewModel, onClose = { navController.popBackStack() })
        }
        composable(Routes.PROGRESS) {
            sg.rooted.android.ui.progress.ProgressScreen(
                viewModel = viewModel, onClose = { navController.popBackStack() },
                onOpenShop = { navController.navigate(Routes.SHOP) },
            )
        }
    }
}
