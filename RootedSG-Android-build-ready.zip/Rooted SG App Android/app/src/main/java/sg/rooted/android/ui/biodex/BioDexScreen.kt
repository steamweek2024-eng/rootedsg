package sg.rooted.android.ui.biodex

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import sg.rooted.android.RootedViewModel
import sg.rooted.android.model.Sighting
import sg.rooted.android.ui.common.RootedPhoto
import sg.rooted.android.ui.pet.WalkTarget
import sg.rooted.android.ui.pet.walkAnchor
import sg.rooted.android.ui.theme.GreenTag
import sg.rooted.android.ui.theme.LocalRootedAppearance
import sg.rooted.android.ui.theme.RisesIn
import sg.rooted.android.ui.theme.RootedMetrics

@Composable
fun BioDexScreen(viewModel: RootedViewModel, onLog: () -> Unit) {
    val appearance = LocalRootedAppearance.current
    val p = appearance.canvas
    val sightings by viewModel.sightings.collectAsState()

    Column(Modifier.fillMaxSize().padding(horizontal = (RootedMetrics.pagePadding + 8).dp)) {
        RisesIn(index = 1) { m ->
            Row(
                m.fillMaxWidth().padding(vertical = 12.dp).walkAnchor(WalkTarget.SCREEN_HERO),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("${sightings.size} species recorded", color = p.secondary, fontSize = 13.sp, modifier = Modifier.weight(1f))
                Button(
                    onClick = onLog,
                    colors = ButtonDefaults.buttonColors(containerColor = p.green, contentColor = p.onAccent),
                    shape = RoundedCornerShape(RootedMetrics.buttonRadius.dp),
                ) { Text("Log sighting", fontSize = 12.sp) }
            }
        }

        if (sightings.isEmpty()) {
            Text("Nothing logged yet, photograph a butterfly, bee, or bird near your plants.", color = p.secondary, fontSize = 13.sp)
            return@Column
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 120.dp),
        ) {
            items(sightings.sortedByDescending { it.date }, key = { it.id }) { sighting ->
                SightingCard(sighting)
            }
        }
    }
}

@Composable
private fun SightingCard(sighting: Sighting) {
    val p = LocalRootedAppearance.current.canvas
    Column(Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(RootedMetrics.cardRadius.dp)).padding(14.dp)) {
        RootedPhoto(
            filename = sighting.imageFilename, placeholderEmoji = sighting.category.emoji, placeholderTint = p.faintFill,
            emojiSize = 26.sp, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth().height(72.dp).clip(RoundedCornerShape(RootedMetrics.thumbRadius.dp)),
        )
        Spacer(Modifier.height(8.dp))
        Text(sighting.speciesName, color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 2)
        Spacer(Modifier.height(6.dp))
        GreenTag(text = sighting.verification.label, filled = sighting.verification == sg.rooted.android.model.VerificationStatus.EXPERT_VERIFIED)
    }
}
