package sg.rooted.android.ui.biodex

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import sg.rooted.android.RootedViewModel
import sg.rooted.android.model.ObservationCategory
import sg.rooted.android.ui.common.SheetHeader
import sg.rooted.android.ui.common.noRippleClickable
import sg.rooted.android.ui.common.rememberPhotoCapturePicker
import sg.rooted.android.ui.garden.PhotoPickerBlock
import sg.rooted.android.ui.theme.LocalRootedAppearance
import sg.rooted.android.ui.theme.RootedBackground
import sg.rooted.android.ui.theme.RootedMetrics

@Composable
fun LogObservationScreen(viewModel: RootedViewModel, onClose: () -> Unit) {
    val appearance = LocalRootedAppearance.current
    val p = appearance.canvas
    val user by viewModel.user.collectAsState()
    val photo = rememberPhotoCapturePicker()
    val scope = rememberCoroutineScope()

    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(ObservationCategory.BUTTERFLY) }
    var isSaving by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().background(appearance.ground).safeDrawingPadding()) {
        SheetHeader(title = "Log a Sighting", onClose = onClose)

        Column(Modifier.fillMaxSize().padding(horizontal = (RootedMetrics.pagePadding + 8).dp)) {
            PhotoPickerBlock(bitmap = photo.bitmap, onCamera = { photo.launchCamera() }, onGallery = { photo.launchGallery() })
            Spacer(Modifier.height(16.dp))

            OutlinedTextField(
                value = name, onValueChange = { name = it },
                label = { Text("Species name (best guess is fine)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(12.dp))
            Text("CATEGORY", color = p.secondary, fontSize = 10.sp, letterSpacing = 1.6.sp)
            Spacer(Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ObservationCategory.entries) { cat ->
                    val selected = cat == category
                    Text(
                        "${cat.emoji} ${cat.label}", fontSize = 12.sp,
                        color = if (selected) p.onAccent else p.text,
                        modifier = Modifier
                            .background(if (selected) p.green else Color.Transparent, RoundedCornerShape(RootedMetrics.buttonRadius.dp))
                            .noRippleClickable { category = cat }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                    )
                }
            }
            Spacer(Modifier.height(24.dp))

            Button(
                onClick = {
                    val u = user ?: return@Button
                    val bitmap = photo.bitmap ?: return@Button
                    if (name.isBlank() || isSaving) return@Button
                    isSaving = true
                    scope.launch {
                        viewModel.garden.logObservation(u, name.trim(), category, bitmap, u.neighbourhood)
                        onClose()
                    }
                },
                enabled = name.isNotBlank() && photo.bitmap != null && !isSaving,
                colors = ButtonDefaults.buttonColors(containerColor = p.green, contentColor = p.onAccent),
                shape = RoundedCornerShape(RootedMetrics.buttonRadius.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) { Text(if (isSaving) "Logging…" else "Log Sighting", fontWeight = FontWeight.Medium) }
        }
    }
}
