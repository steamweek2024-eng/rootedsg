package sg.rooted.android.ui.common

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import sg.rooted.android.model.PlantStage
import sg.rooted.android.ui.theme.LocalRootedAppearance
import sg.rooted.android.ui.theme.RootedMetrics
import kotlin.math.sin
import kotlin.random.Random

enum class CelebrationKind { REGISTERED, VERIFIED, STAGE_UP }

data class CelebrationPayload(
    val kind: CelebrationKind,
    val title: String,
    val subtitle: String,
    val stage: PlantStage,
    val xp: Int,
    val potSkin: sg.rooted.android.engine.ShopItem? = null,
)

/**
 * The reward moment — tied only to verified real-world progress, never shown
 * speculatively. A Compose port of CelebrationOverlay.swift: spring scale-in,
 * an animated progress ring, confetti on a stage-up, haptic confirmation.
 */
@Composable
fun CelebrationOverlay(payload: CelebrationPayload, onDismiss: () -> Unit) {
    val appearance = LocalRootedAppearance.current
    var show by remember { mutableStateOf(false) }
    val ringProgress = remember { Animatable(0f) }
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()

    val accent = when (payload.kind) {
        CelebrationKind.REGISTERED -> appearance.canvas.secondary
        CelebrationKind.VERIFIED -> appearance.canvas.green
        CelebrationKind.STAGE_UP -> appearance.canvas.warm
    }
    val eyebrow = when (payload.kind) {
        CelebrationKind.REGISTERED -> "PLANT REGISTERED"
        CelebrationKind.VERIFIED -> "VERIFIED ALIVE"
        CelebrationKind.STAGE_UP -> "DIGITAL TWIN EVOLVED"
    }

    LaunchedEffect(payload) {
        show = true
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        scope.launch { ringProgress.animateTo(1f, animationSpec = tween(1100, delayMillis = 150, easing = LinearEasing)) }
    }

    fun dismiss() {
        show = false
        scope.launch { delay(200); onDismiss() }
    }

    val scrimAlpha by androidx.compose.animation.core.animateFloatAsState(if (show) 0.5f else 0f, label = "scrim")
    val cardScale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (show) 1f else 0.85f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "cardScale",
    )
    val cardAlpha by androidx.compose.animation.core.animateFloatAsState(if (show) 1f else 0f, label = "cardAlpha")
    val plantScale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (show) 1f else 0.6f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "plantScale",
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = scrimAlpha))
            .noRippleClickable { dismiss() },
        contentAlignment = Alignment.Center,
    ) {
        if (payload.kind == CelebrationKind.STAGE_UP && show) {
            ConfettiCanvas(accent = accent, modifier = Modifier.fillMaxSize())
        }

        Column(
            Modifier
                .padding(horizontal = 28.dp)
                .widthIn(max = 340.dp)
                .scale(cardScale)
                .alpha(cardAlpha)
                .background(appearance.ground, RoundedCornerShape(RootedMetrics.chipRadius.dp))
                .padding(26.dp)
                // Absorbs taps so they don't fall through to the scrim's dismiss handler.
                .noRippleClickable { },
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(Modifier.size(186.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.size(220.dp).background(accent.copy(alpha = 0.16f), androidx.compose.foundation.shape.CircleShape))
                Canvas(Modifier.size(186.dp)) {
                    drawArc(
                        color = accent, startAngle = -90f, sweepAngle = 360f * ringProgress.value,
                        useCenter = false, style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round),
                    )
                }
                PlantCharacterView(
                    stage = payload.stage, health = sg.rooted.android.model.HealthStatus.HEALTHY,
                    growth = 0.7, streak = 3, animated = true, showsPot = true, potSkin = payload.potSkin,
                    modifier = Modifier.size(150.dp, 165.dp).scale(plantScale),
                )
            }
            Spacer(Modifier.height(18.dp))

            Text(eyebrow, color = accent, fontSize = 11.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(
                payload.title, color = appearance.canvas.text, fontSize = 22.sp, fontWeight = FontWeight.Light,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                payload.subtitle, color = appearance.canvas.secondary, fontSize = 13.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )

            if (payload.xp > 0) {
                Spacer(Modifier.height(14.dp))
                Row(
                    Modifier.background(accent, RoundedCornerShape(6.dp)).padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("+${payload.xp} XP", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.height(18.dp))
            Button(
                onClick = { dismiss() },
                colors = ButtonDefaults.buttonColors(containerColor = appearance.canvas.green, contentColor = appearance.canvas.onAccent),
                shape = RoundedCornerShape(RootedMetrics.buttonRadius.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp),
            ) { Text("Continue", fontWeight = FontWeight.Medium) }
        }
    }
}

@Composable
private fun ConfettiCanvas(accent: Color, modifier: Modifier = Modifier) {
    data class Piece(val x: Float, val delay: Float, val hue: Int, val size: Float, val spin: Float)

    val pieces = remember {
        val random = Random(System.nanoTime())
        List(44) {
            Piece(
                x = random.nextFloat() * 0.96f + 0.02f,
                delay = random.nextFloat() * 1.1f,
                hue = it % 4,
                size = random.nextFloat() * 6f + 6f,
                spin = (random.nextFloat() * 6f - 3f),
            )
        }
    }
    val colors = listOf(accent, Color(0xFFA3E68A), Color(0xFFE68AA3), Color(0xFF8AC7E6))
    var elapsed by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        val startNanos = withFrameNanos { it }
        while (elapsed < 3.6f) {
            val nowNanos = withFrameNanos { it }
            elapsed = (nowNanos - startNanos) / 1_000_000_000f
        }
    }

    Canvas(modifier) {
        for (piece in pieces) {
            val local = elapsed - piece.delay
            if (local <= 0f || local >= 3.4f) continue
            val progress = local / 3.4f
            val y = -20f + progress * (size.height + 60f)
            val drift = sin(local * 2.2f + piece.x * 10f) * 24f
            val x = piece.x * size.width + drift
            val alpha = (1f - progress * 0.7f).coerceIn(0f, 1f)
            rotate(degrees = local * piece.spin * 60f, pivot = Offset(x, y)) {
                drawRoundRect(
                    color = colors[piece.hue].copy(alpha = alpha),
                    topLeft = Offset(x, y),
                    size = Size(piece.size, piece.size * 1.5f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(RootedMetrics.chipRadius.toFloat()),
                )
            }
        }
    }
}
