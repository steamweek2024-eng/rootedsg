package sg.rooted.android.ui.common

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Google's own brand colours for the "G" mark — see Google Identity's Sign In
// button guidelines, which specify this exact four-colour logo for any
// third-party "Sign in with Google" button.
private val GoogleBlue = Color(0xFF4285F4)
private val GoogleGreen = Color(0xFF34A853)
private val GoogleYellow = Color(0xFFFBBC05)
private val GoogleRed = Color(0xFFEA4335)

/** The official Google "G" mark, drawn from its published path geometry (18x18 viewBox). */
@Composable
fun GoogleLogo(size: Dp = 18.dp) {
    Canvas(modifier = Modifier.size(size)) {
        val s = this.size.width / 18f
        fun p(x: Float, y: Float) = androidx.compose.ui.geometry.Offset(x * s, y * s)

        val blue = Path().apply {
            moveTo(17.64f * s, 9.20455f * s)
            cubicTo(17.64f * s, 8.56636f * s, 17.5827f * s, 7.95273f * s, 17.4764f * s, 7.36364f * s)
            lineTo(9f * s, 7.36364f * s)
            lineTo(9f * s, 10.845f * s)
            lineTo(13.8436f * s, 10.845f * s)
            cubicTo(13.635f * s, 11.97f * s, 13.0009f * s, 12.9231f * s, 12.0477f * s, 13.5614f * s)
            lineTo(12.0477f * s, 15.8195f * s)
            lineTo(14.9564f * s, 15.8195f * s)
            cubicTo(16.6582f * s, 14.2527f * s, 17.64f * s, 11.9455f * s, 17.64f * s, 9.20455f * s)
            close()
        }
        val green = Path().apply {
            moveTo(9f * s, 18f * s)
            cubicTo(11.43f * s, 18f * s, 13.4673f * s, 17.1941f * s, 14.9564f * s, 15.8195f * s)
            lineTo(12.0477f * s, 13.5614f * s)
            cubicTo(11.2418f * s, 14.1014f * s, 10.2109f * s, 14.4205f * s, 9f * s, 14.4205f * s)
            cubicTo(6.65591f * s, 14.4205f * s, 4.67182f * s, 12.8373f * s, 3.96409f * s, 10.71f * s)
            lineTo(0.957273f * s, 10.71f * s)
            lineTo(0.957273f * s, 13.0418f * s)
            cubicTo(2.43818f * s, 15.9832f * s, 5.48182f * s, 18f * s, 9f * s, 18f * s)
            close()
        }
        val yellow = Path().apply {
            moveTo(3.96409f * s, 10.71f * s)
            cubicTo(3.78409f * s, 10.17f * s, 3.68182f * s, 9.59318f * s, 3.68182f * s, 9f * s)
            cubicTo(3.68182f * s, 8.40682f * s, 3.78409f * s, 7.83f * s, 3.96409f * s, 7.29f * s)
            lineTo(3.96409f * s, 4.95818f * s)
            lineTo(0.957273f * s, 4.95818f * s)
            cubicTo(0.347727f * s, 6.17318f * s, 0f * s, 7.54773f * s, 0f * s, 9f * s)
            cubicTo(0f * s, 10.4523f * s, 0.347727f * s, 11.8268f * s, 0.957273f * s, 13.0418f * s)
            lineTo(3.96409f * s, 10.71f * s)
            close()
        }
        val red = Path().apply {
            moveTo(9f * s, 3.57955f * s)
            cubicTo(10.3214f * s, 3.57955f * s, 11.5077f * s, 4.03364f * s, 12.4405f * s, 4.92545f * s)
            lineTo(15.0218f * s, 2.34409f * s)
            cubicTo(13.4632f * s, 0.891818f * s, 11.4259f * s, 0f * s, 9f * s, 0f * s)
            cubicTo(5.48182f * s, 0f * s, 2.43818f * s, 2.01682f * s, 0.957273f * s, 4.95818f * s)
            lineTo(3.96409f * s, 7.29f * s)
            cubicTo(4.67182f * s, 5.16273f * s, 6.65591f * s, 3.57955f * s, 9f * s, 3.57955f * s)
            close()
        }

        drawPath(blue, color = GoogleBlue)
        drawPath(green, color = GoogleGreen)
        drawPath(yellow, color = GoogleYellow)
        drawPath(red, color = GoogleRed)
    }
}

/**
 * The standard "Sign in with Google" button, matching Google's own brand
 * guidelines (white surface, the full-colour "G", grey border) so it reads
 * as unmistakably the real thing rather than a themed list row — recognition
 * is the whole point of using Google's button style rather than inventing a
 * new one.
 */
@Composable
fun GoogleSignInButton(text: String, isLoading: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier
            .fillMaxWidth()
            .height(48.dp)
            .background(Color.White, RoundedCornerShape(4.dp))
            .border(1.dp, Color(0xFFDADCE0), RoundedCornerShape(4.dp))
            .noRippleClickable(enabled = !isLoading, onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (isLoading) {
            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Color(0xFF5F6368))
        } else {
            GoogleLogo(size = 18.dp)
        }
        androidx.compose.foundation.layout.Spacer(Modifier.width(12.dp))
        Text(
            text, color = Color(0xFF3C4043), fontSize = 14.sp, fontWeight = FontWeight.Medium,
        )
    }
}
