package sg.rooted.android.ui.common

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.FileProvider
import sg.rooted.android.engine.ImageStore

/**
 * A camera-or-gallery photo picker, the Android counterpart to PhotoSourceView.swift.
 * Call [PhotoCapturePicker.launchCamera] or [.launchGallery]; [bitmap] holds the
 * result once the user finishes, downsampled to a sensible upload size and
 * corrected for EXIF rotation (a common camera-intent gotcha).
 */
class PhotoCapturePicker internal constructor(
    private val takePicture: (Uri) -> Unit,
    private val pickImage: () -> Unit,
    private var pendingCaptureUri: Uri?,
    private val onCaptureUriPrepared: (Uri) -> Unit,
    private val onClear: () -> Unit,
    private val context: android.content.Context,
) {
    var bitmap by mutableStateOf<Bitmap?>(null)
        internal set

    fun launchCamera() {
        val file = ImageStore.newCaptureFile()
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        onCaptureUriPrepared(uri)
        takePicture(uri)
    }

    fun launchGallery() = pickImage()

    fun clear() { bitmap = null; onClear() }
}

@Composable
fun rememberPhotoCapturePicker(): PhotoCapturePicker {
    val context = LocalContext.current
    var captureUri by remember { mutableStateOf<Uri?>(null) }
    var resultBitmap by remember { mutableStateOf<Bitmap?>(null) }

    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success) {
            captureUri?.let { uri ->
                resultBitmap = loadAndOrient(context, uri)
            }
        }
    }
    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { resultBitmap = loadAndOrient(context, it) }
    }

    val picker = remember {
        PhotoCapturePicker(
            takePicture = { uri -> cameraLauncher.launch(uri) },
            pickImage = { galleryLauncher.launch("image/*") },
            pendingCaptureUri = null,
            onCaptureUriPrepared = { captureUri = it },
            onClear = { resultBitmap = null },
            context = context,
        )
    }
    picker.bitmap = resultBitmap
    return picker
}

private fun loadAndOrient(context: android.content.Context, uri: Uri): Bitmap? {
    val maxDimension = 1600
    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null

    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    var sample = 1
    while (bounds.outWidth / sample > maxDimension * 2 || bounds.outHeight / sample > maxDimension * 2) sample *= 2

    val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
        ?: return null

    val orientation = runCatching {
        ExifInterface(bytes.inputStream()).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
    }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)

    val rotationDegrees = when (orientation) {
        ExifInterface.ORIENTATION_ROTATE_90 -> 90f
        ExifInterface.ORIENTATION_ROTATE_180 -> 180f
        ExifInterface.ORIENTATION_ROTATE_270 -> 270f
        else -> 0f
    }
    val rotated = if (rotationDegrees != 0f) {
        val matrix = Matrix().apply { postRotate(rotationDegrees) }
        Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
    } else decoded

    val scale = minOf(1f, maxDimension.toFloat() / maxOf(rotated.width, rotated.height))
    return if (scale < 1f) {
        Bitmap.createScaledBitmap(rotated, (rotated.width * scale).toInt(), (rotated.height * scale).toInt(), true)
    } else rotated
}
