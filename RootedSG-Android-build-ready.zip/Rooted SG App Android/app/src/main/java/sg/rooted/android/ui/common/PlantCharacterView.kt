package sg.rooted.android.ui.common

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import sg.rooted.android.model.HealthStatus
import sg.rooted.android.model.PlantStage
import kotlin.math.cos
import kotlin.math.sin

/**
 * The digital twin — a Compose port of PlantCharacterView.swift. Fully
 * procedural, animated, driven by the plant's real verified progress: no
 * static asset here, the stem lengthens, leaves grow, blooms open, and a
 * Legacy plant gains an aura, all from real stage/health/growth/streak data.
 */
@Composable
fun PlantCharacterView(
    stage: PlantStage,
    health: HealthStatus,
    growth: Double,
    streak: Int,
    modifier: Modifier = Modifier,
    animated: Boolean = true,
    showsPot: Boolean = true,
    /** Set when the character sits on a dark ground — foliage switches to a lighter palette. */
    onDark: Boolean = false,
    /** Renders the character with a specular sheen, so it reads as a soft 3D object. */
    glossy: Boolean = false,
    /** Renders the plant as a cast brass object rather than living foliage. */
    brass: Boolean = false,
    /** A Shop-purchased pot recolour, equipped from the Profile. Overrides the
     * default terracotta whenever set, on every character it's passed to. */
    potSkin: sg.rooted.android.engine.ShopItem? = null,
) {
    var time by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(animated) {
        if (!animated) return@LaunchedEffect
        val start = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            time = (now - start) / 1_000_000_000f
        }
    }

    Canvas(
        modifier.semantics { contentDescription = "${stage.displayName} plant character, ${health.label}" },
    ) {
        drawPlantCharacter(stage, health, growth.toFloat(), streak, animated, showsPot, onDark, glossy, brass, potSkin, time)
    }
}

private fun leafCountFor(stage: PlantStage) = when (stage) {
    PlantStage.SPROUT -> 2
    PlantStage.GROWING -> 5
    // Veteran/legacy's extra foliage reads as the canopy below, not more leaf
    // pairs stacked into the same crowded zone at the stem's top.
    PlantStage.BLOOMING, PlantStage.VETERAN, PlantStage.LEGACY -> 7
}

/** Where along the stem the ascending leaf pairs live — see [leafCountFor]'s note. */
private fun leafFracRangeFor(stage: PlantStage): Pair<Float, Float> =
    if (stage.order >= PlantStage.VETERAN.order) 0.14f to 0.46f else 0.20f to 0.78f

/** This color shifted toward black (`amount < 0`) or white (`amount > 0`). Used to
 * build a layered canopy from solid fills instead of stacking translucent copies. */
private fun Color.shaded(amount: Float): Color = if (amount >= 0f) {
    Color(red + (1f - red) * amount, green + (1f - green) * amount, blue + (1f - blue) * amount, alpha)
} else {
    val f = 1f + amount
    Color(red * f, green * f, blue * f, alpha)
}

private fun stemHeightBaseFor(stage: PlantStage) = when (stage) {
    PlantStage.SPROUT -> 0.20f
    PlantStage.GROWING -> 0.34f
    PlantStage.BLOOMING -> 0.44f
    PlantStage.VETERAN -> 0.52f
    PlantStage.LEGACY -> 0.56f
}

private fun bloomCountFor(stage: PlantStage) = when (stage) {
    PlantStage.BLOOMING -> 3
    PlantStage.VETERAN -> 4
    PlantStage.LEGACY -> 6
    else -> 0
}

private fun foliageTintFor(health: HealthStatus, onDark: Boolean, brass: Boolean): Color {
    if (brass) return Color(0.784f, 0.612f, 0.235f)
    if (onDark) {
        return when (health) {
            HealthStatus.HEALTHY -> Color(0.086f, 0.373f, 0.216f)
            HealthStatus.RECOVERING -> Color(0.157f, 0.435f, 0.263f)
            HealthStatus.STRUGGLING -> Color(0.463f, 0.365f, 0.110f)
            HealthStatus.AT_RISK -> Color(0.478f, 0.290f, 0.114f)
            HealthStatus.DECEASED -> Color(0.341f, 0.318f, 0.290f)
        }
    }
    return when (health) {
        HealthStatus.HEALTHY -> Color(0.267f, 0.702f, 0.298f) // rootedLeaf-equivalent
        HealthStatus.RECOVERING -> Color(0.45f, 0.63f, 0.35f)
        HealthStatus.STRUGGLING -> Color(0.62f, 0.60f, 0.26f)
        HealthStatus.AT_RISK -> Color(0.58f, 0.52f, 0.32f)
        HealthStatus.DECEASED -> Color(0.48f, 0.44f, 0.38f)
    }
}

private fun DrawScope.drawPlantCharacter(
    stage: PlantStage, health: HealthStatus, growth: Float, streak: Int,
    animated: Boolean, showsPot: Boolean, onDark: Boolean, glossy: Boolean, brass: Boolean,
    potSkin: sg.rooted.android.engine.ShopItem?, time: Float,
) {
    val w = size.width
    val h = size.height
    val potTop = if (showsPot) h * 0.78f else h * 0.96f
    val baseX = w / 2f
    val sway = if (animated) sin(time * 0.9f) * 0.018f else 0f
    val breathe = if (animated) 1f + sin(time * 1.4f) * 0.012f else 1f

    val leafCount = leafCountFor(stage)
    val stemHeight = stemHeightBaseFor(stage) + growth * 0.06f
    val bloomCount = bloomCountFor(stage)
    val foliageTint = foliageTintFor(health, onDark, brass)

    // Legacy aura — a soft radiance behind sustained-survival plants.
    if (stage == PlantStage.LEGACY && !brass) {
        val pulse = if (animated) 0.5f + 0.5f * sin(time * 1.1f) else 0.6f
        val auraW = w * 0.84f; val auraH = h * 0.92f
        val auraLeft = baseX - w * 0.42f; val auraTop = potTop - h * 0.85f
        val warmWhite = Color(1f, 0.976f, 0.878f)
        drawOval(
            brush = Brush.radialGradient(
                colors = listOf(warmWhite.copy(alpha = 0.28f + 0.10f * pulse), warmWhite.copy(alpha = 0f)),
                center = Offset(auraLeft + auraW / 2, auraTop + auraH / 2), radius = auraW * 0.5f,
            ),
            topLeft = Offset(auraLeft, auraTop), size = Size(auraW, auraH),
        )
    }

    // A soft contact shadow grounds the glossy object.
    if (glossy) {
        val gW = w * 0.60f; val gH = h * 0.075f
        val gLeft = baseX - w * 0.30f; val gTop = potTop + h * 0.16f
        drawOval(
            brush = Brush.radialGradient(
                colors = listOf(Color.Black.copy(alpha = 0.16f), Color.Black.copy(alpha = 0f)),
                center = Offset(gLeft + gW / 2, gTop + gH / 2), radius = gW * 0.5f,
            ),
            topLeft = Offset(gLeft, gTop), size = Size(gW, gH),
        )
    }

    // Ground shadow.
    val shW = w * 0.44f; val shH = h * 0.035f
    val shLeft = baseX - w * 0.22f; val shTop = potTop + (if (showsPot) h * 0.19f else h * 0.005f)
    drawOval(color = Color.Black.copy(alpha = 0.10f), topLeft = Offset(shLeft, shTop), size = Size(shW, shH))

    val stemTopY = potTop - h * stemHeight * breathe
    val stemTopX = baseX + w * sway * 1.2f
    val ctrl1 = Offset(baseX - w * 0.03f + w * sway * 0.4f, potTop - h * stemHeight * 0.4f)
    val ctrl2 = Offset(baseX + w * 0.03f + w * sway * 0.8f, potTop - h * stemHeight * 0.75f)

    // Main stem (tapered, curved).
    val stem = Path().apply {
        moveTo(baseX, potTop + h * 0.01f)
        cubicTo(ctrl1.x, ctrl1.y, ctrl2.x, ctrl2.y, stemTopX, stemTopY)
    }
    val stemWidth = maxOf(2.5f, w * (if (stage == PlantStage.SPROUT) 0.016f else if (stage == PlantStage.GROWING) 0.022f else 0.030f))
    drawPath(
        stem,
        brush = Brush.linearGradient(
            colors = listOf(foliageTint.copy(alpha = 0.95f), foliageTint.copy(alpha = 0.75f)),
            start = Offset(baseX, potTop), end = Offset(stemTopX, stemTopY),
        ),
        style = Stroke(width = stemWidth, cap = StrokeCap.Round),
    )

    // Leaves — alternating up the stem, scaled by position.
    val (leafFracStart, leafFracSpan) = leafFracRangeFor(stage)
    for (i in 0 until leafCount) {
        val frac = if (leafCount == 1) 0.6f else leafFracStart + (i.toFloat() / maxOf(1, leafCount - 1)) * leafFracSpan
        val point = pointOnStem(frac, baseX, potTop, stemTopX, stemTopY, ctrl1, ctrl2)
        val side = if (i % 2 == 0) 1f else -1f
        val leafPhase = if (animated) sin(time * 1.25f + i * 0.8f) else 0f
        val sizeFactor = (1f - frac * 0.35f) * (if (stage == PlantStage.SPROUT) 0.85f else 1f)
        val leafLen = w * 0.20f * sizeFactor
        val angle = side * (0.62f + leafPhase * 0.07f) - (frac * 0.35f)
        val tint = if (brass) {
            if (i % 2 == 0) Color(0.859f, 0.686f, 0.322f) else Color(0.624f, 0.475f, 0.169f)
        } else foliageTint
        drawLeaf(point, leafLen, angle, tint, highlight = i % 3 == 0)
    }

    // Crown for veteran / legacy — a fuller canopy, drawn *before* the blooms so
    // they sit cleanly on top of it rather than dissolving into it. Every puff is
    // a solid fill (no stacked translucency) so overlaps read as layered foliage,
    // not a haze — back puffs darker and wide, a bright puff on top for the highlight.
    if (stage.order >= PlantStage.VETERAN.order) {
        data class Puff(val dx: Float, val dy: Float, val scale: Float, val shade: Float)
        val puffs = listOf(
            Puff(-0.135f, 0.040f, 0.88f, -0.14f), Puff(0.135f, 0.040f, 0.88f, -0.14f), Puff(0.0f, 0.078f, 0.80f, -0.18f),
            Puff(-0.072f, -0.018f, 1.00f, 0.0f), Puff(0.072f, -0.018f, 1.00f, 0.0f),
            Puff(0.0f, -0.062f, 0.92f, 0.16f),
        )
        // A wide-but-short frame (the Home hero, a card illustration) leaves far
        // less headroom above the stem than a tall one does. Rather than risk the
        // canopy's top puffs clipping against the canvas edge there, work out how
        // far the highest puff would reach past y = 0 and nudge the whole cluster
        // down by exactly that much (plus a small margin) — it never overflows,
        // whatever the frame's aspect ratio, and only shifts when it has to.
        val highestPuff = puffs.minByOrNull { it.dy - it.scale * 0.86f * 0.125f }!!
        val naiveCenterY = stemTopY - h * 0.03f
        val highestTopY = naiveCenterY + h * highestPuff.dy - (w * 0.125f * highestPuff.scale) * 0.86f
        val correction = maxOf(0f, 6f - highestTopY)
        val crownCenter = Offset(stemTopX, naiveCenterY + correction)
        puffs.forEachIndexed { i, puff ->
            val wobble = if (animated) sin(time * 0.55f + i * 1.7f) * w * 0.006f else 0f
            val center = Offset(crownCenter.x + w * puff.dx + wobble, crownCenter.y + h * puff.dy)
            val r = w * 0.125f * puff.scale
            val tint = if (brass) {
                when {
                    puff.shade < 0f -> Color(0.639f, 0.490f, 0.180f)
                    puff.shade > 0f -> Color(0.925f, 0.804f, 0.529f)
                    else -> Color(0.784f, 0.612f, 0.235f)
                }
            } else foliageTint.shaded(puff.shade)
            drawOval(color = tint, topLeft = Offset(center.x - r, center.y - r * 0.86f), size = Size(r * 2, r * 1.72f))
        }
    }

    // Blooms — drawn after the canopy so they read as distinct accents on top of
    // it, spread wide so they don't stack into one clump.
    if (bloomCount > 0) {
        for (i in 0 until bloomCount) {
            val frac = 0.42f + (i.toFloat() / maxOf(1, bloomCount)) * 0.40f
            val jitter = (i - (bloomCount - 1) / 2f) * w * 0.085f
            var point = pointOnStem(frac, baseX, potTop, stemTopX, stemTopY, ctrl1, ctrl2)
            val bobble = if (animated) sin(time * 1.05f + i) * h * 0.006f else 0f
            val liftBase = if (stage.order >= PlantStage.VETERAN.order) 0.05f else 0.015f
            point = Offset(point.x + jitter, point.y - h * liftBase - kotlin.math.abs(jitter) * 0.12f + bobble)
            drawBloom(point, w * 0.052f, i, brass)
        }
    }

    // A specular sheen across the upper-left of the whole character.
    if (glossy) {
        val sheenW = w * 0.20f; val sheenH = h * 0.13f
        val sheenLeft = baseX - w * 0.20f; val sheenTop = stemTopY + h * 0.02f
        drawOval(
            brush = Brush.radialGradient(
                colors = listOf(Color.White.copy(alpha = if (brass) 0.42f else 0.24f), Color.White.copy(alpha = 0f)),
                center = Offset(sheenLeft + sheenW / 2, sheenTop + sheenH / 2), radius = sheenW * 0.55f,
            ),
            topLeft = Offset(sheenLeft, sheenTop), size = Size(sheenW, sheenH),
        )
    }

    // Sparkles (legacy) — earned only after recovery + sustained survival.
    if (stage == PlantStage.LEGACY && animated && !brass) {
        for (i in 0 until 11) {
            val phase = time * 0.7f + i * 1.3f
            val a = phase % (2 * Math.PI).toFloat()
            val r = w * (0.24f + 0.11f * sin(phase * 0.5f))
            val p = Offset(stemTopX + cos(a) * r, stemTopY + sin(a) * r * 0.75f + h * 0.06f)
            val alpha = 0.35f + 0.45f * kotlin.math.abs(sin(phase))
            drawSparkle(p, w * 0.042f, alpha)
        }
    }

    // Streak embers — a warm glow at the base for long care streaks.
    if (streak >= 3 && animated) {
        for (i in 0 until minOf(streak, 6)) {
            val phase = time * 0.9f + i * 1.1f
            val lift = (phase % 2.4f) / 2.4f
            val x = baseX + sin(phase * 1.7f) * w * 0.12f
            val y = potTop - lift * h * 0.16f
            drawOval(
                color = Color(1.0f, 0.988f, 0.929f, (1 - lift) * 0.40f),
                topLeft = Offset(x - w * 0.010f, y), size = Size(w * 0.020f, w * 0.020f),
            )
        }
    }

    // Pot.
    if (showsPot) drawPot(stage, potTop, baseX, brass, glossy, onDark, potSkin)

    // A purchased pot skin shimmers a little life into what would otherwise be
    // a flat recolour — legendary skins are the only ones that get this.
    if (showsPot && potSkin?.rarity == sg.rooted.android.engine.ShopRarity.LEGENDARY && animated) {
        val shimmer = 0.5f + 0.5f * sin(time * 0.8f)
        val potTopWidth = w * 0.42f
        val rimLeft = baseX - potTopWidth / 2 - w * 0.012f
        val rimTop = potTop - h * 0.026f
        val rimW = potTopWidth + w * 0.024f
        val rimH = h * 0.045f
        drawRoundRect(
            color = Color.White.copy(alpha = 0.12f + shimmer * 0.14f),
            topLeft = Offset(rimLeft, rimTop), size = Size(rimW, rimH),
            cornerRadius = CornerRadius(h * 0.014f, h * 0.014f),
        )
    }
}

private fun pointOnStem(frac: Float, baseX: Float, potTop: Float, stemTopX: Float, stemTopY: Float, ctrl1: Offset, ctrl2: Offset): Offset {
    val p0x = baseX; val p0y = potTop
    val p3x = stemTopX; val p3y = stemTopY
    val t = frac; val mt = 1 - frac
    val x = mt * mt * mt * p0x + 3 * mt * mt * t * ctrl1.x + 3 * mt * t * t * ctrl2.x + t * t * t * p3x
    val y = mt * mt * mt * p0y + 3 * mt * mt * t * ctrl1.y + 3 * mt * t * t * ctrl2.y + t * t * t * p3y
    return Offset(x, y)
}

private fun DrawScope.drawLeaf(origin: Offset, length: Float, angle: Float, tint: Color, highlight: Boolean) {
    val tip = Offset(origin.x + cos(angle - Math.PI.toFloat() / 2) * length, origin.y + sin(angle - Math.PI.toFloat() / 2) * length)
    val width = length * 0.52f
    val perp = angle // matches iOS's (angle - pi/2 + pi/2) simplification
    val c1 = Offset(
        origin.x + cos(perp) * width + (tip.x - origin.x) * 0.35f,
        origin.y + sin(perp) * width + (tip.y - origin.y) * 0.35f,
    )
    val c2 = Offset(
        origin.x - cos(perp) * width + (tip.x - origin.x) * 0.35f,
        origin.y - sin(perp) * width + (tip.y - origin.y) * 0.35f,
    )
    val leaf = Path().apply {
        moveTo(origin.x, origin.y)
        quadraticBezierTo(c1.x, c1.y, tip.x, tip.y)
        quadraticBezierTo(c2.x, c2.y, origin.x, origin.y)
        close()
    }
    drawPath(leaf, brush = Brush.linearGradient(listOf(tint.copy(alpha = 0.95f), tint.copy(alpha = 0.62f)), start = origin, end = tip))

    val vein = Path().apply {
        moveTo(origin.x, origin.y)
        lineTo(origin.x + (tip.x - origin.x) * 0.88f, origin.y + (tip.y - origin.y) * 0.88f)
    }
    drawPath(
        vein, color = Color.White.copy(alpha = if (highlight) 0.35f else 0.18f),
        style = Stroke(width = maxOf(0.8f, length * 0.035f), cap = StrokeCap.Round),
    )
}

private val petalColors = listOf(Color(0.93f, 0.42f, 0.55f), Color(0.929f, 0.616f, 0.463f), Color(0.93f, 0.55f, 0.62f))

private fun DrawScope.drawBloom(center: Offset, radius: Float, index: Int, brass: Boolean) {
    val tint = if (brass) {
        if (index % 2 == 0) Color(0.925f, 0.804f, 0.529f) else Color(0.612f, 0.463f, 0.161f)
    } else petalColors[index % petalColors.size]
    for (p in 0 until 5) {
        val a = (p / 5f) * (2 * Math.PI).toFloat()
        val pc = Offset(center.x + cos(a) * radius * 0.62f, center.y + sin(a) * radius * 0.62f)
        drawOval(color = tint.copy(alpha = 0.88f), topLeft = Offset(pc.x - radius * 0.52f, pc.y - radius * 0.52f), size = Size(radius * 1.04f, radius * 1.04f))
    }
    val amber = Color(0.929f, 0.616f, 0.463f)
    drawOval(color = amber, topLeft = Offset(center.x - radius * 0.30f, center.y - radius * 0.30f), size = Size(radius * 0.60f, radius * 0.60f))
}

private fun DrawScope.drawSparkle(p: Offset, sparkleSize: Float, opacity: Float) {
    val star = Path().apply {
        moveTo(p.x, p.y - sparkleSize)
        quadraticBezierTo(p.x, p.y, p.x + sparkleSize, p.y)
        quadraticBezierTo(p.x, p.y, p.x, p.y + sparkleSize)
        quadraticBezierTo(p.x, p.y, p.x - sparkleSize, p.y)
        quadraticBezierTo(p.x, p.y, p.x, p.y - sparkleSize)
        close()
    }
    drawPath(star, color = Color(1.0f, 0.988f, 0.929f, opacity))
}

private fun DrawScope.drawPot(
    stage: PlantStage, potTop: Float, baseX: Float, brass: Boolean, glossy: Boolean, onDark: Boolean,
    potSkin: sg.rooted.android.engine.ShopItem?,
) {
    val w = size.width; val h = size.height
    val potTopWidth = w * 0.42f
    val potBottomWidth = w * 0.32f
    val potHeight = h * 0.19f

    val pot = Path().apply {
        moveTo(baseX - potTopWidth / 2, potTop)
        lineTo(baseX + potTopWidth / 2, potTop)
        lineTo(baseX + potBottomWidth / 2, potTop + potHeight)
        quadraticBezierTo(baseX, potTop + potHeight + h * 0.018f, baseX - potBottomWidth / 2, potTop + potHeight)
        close()
    }
    val skinColors = potSkin?.colors?.takeIf { it.size >= 3 }
    val potTopColor = skinColors?.get(0) ?: (if (brass || glossy) Color(0.964f, 0.960f, 0.949f)
    else if (onDark) Color(0.996f, 0.976f, 0.941f) else Color(0.80f, 0.51f, 0.38f))
    val potBottomColor = skinColors?.get(1) ?: (if (brass || glossy) Color(0.843f, 0.835f, 0.816f)
    else if (onDark) Color(0.945f, 0.898f, 0.831f) else Color(0.63f, 0.37f, 0.27f))
    drawPath(
        pot,
        brush = Brush.linearGradient(
            listOf(potTopColor, potBottomColor),
            start = Offset(baseX - potTopWidth / 2, potTop), end = Offset(baseX + potTopWidth / 2, potTop + potHeight),
        ),
    )

    // Rim.
    val rimLeft = baseX - potTopWidth / 2 - w * 0.012f
    val rimTop = potTop - h * 0.026f
    val rimW = potTopWidth + w * 0.024f
    val rimH = h * 0.045f
    val rimColor = skinColors?.get(2) ?: (if (brass || glossy) Color(0.996f, 0.992f, 0.988f)
    else if (onDark) Color(1.0f, 0.992f, 0.976f) else Color(0.85f, 0.56f, 0.42f))
    drawRoundRect(
        color = rimColor, topLeft = Offset(rimLeft, rimTop), size = Size(rimW, rimH),
        cornerRadius = CornerRadius(h * 0.014f, h * 0.014f),
    )
    // A Legacy Plant's pot is banded in gold — the only stage that earns it.
    if (stage == PlantStage.LEGACY) {
        drawRoundRect(
            color = Color(0.851f, 0.741f, 0.404f), topLeft = Offset(rimLeft, rimTop), size = Size(rimW, rimH),
            cornerRadius = CornerRadius(h * 0.014f, h * 0.014f),
            style = Stroke(width = maxOf(1.2f, h * 0.004f)),
        )
    }

    // Soil.
    drawOval(
        color = Color(0.30f, 0.22f, 0.16f),
        topLeft = Offset(baseX - potTopWidth / 2 + w * 0.012f, potTop - h * 0.018f),
        size = Size(potTopWidth - w * 0.024f, h * 0.028f),
    )
}

/** Compact avatar version used in lists when there's no real photo to show instead. */
@Composable
fun PlantAvatarCharacter(stage: PlantStage, health: HealthStatus, growth: Double, streak: Int, sizeDp: Int = 64) {
    PlantCharacterView(
        stage = stage, health = health, growth = growth, streak = streak,
        animated = false, showsPot = false,
        modifier = Modifier.size(sizeDp.dp),
    )
}
