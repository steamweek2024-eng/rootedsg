package sg.rooted.android.ui.common

import androidx.compose.animation.core.EaseInOutCubic
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import sg.rooted.android.ui.theme.LocalRootedAppearance
import kotlin.math.cos
import kotlin.math.sin

/**
 * A small, continuously-growing plant — the loading indicator, wherever the
 * app needs one, instead of a generic spinner. One seedling breathes in and
 * out of the soil on a loop: stem rises, two leaves unfurl, a bud opens at
 * full height, then it eases back down and does it again.
 */
@Composable
fun PlantLoader(modifier: Modifier = Modifier, size: Dp = 64.dp, tint: Color? = null) {
    val p = LocalRootedAppearance.current.canvas
    val green = tint ?: p.green
    val warm = p.warm

    val infinite = rememberInfiniteTransition(label = "plantLoader")
    val growth by infinite.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "growth",
    )
    val sway by infinite.animateFloat(
        initialValue = -1f, targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(1900, easing = EaseInOutCubic), repeatMode = RepeatMode.Reverse),
        label = "sway",
    )

    Canvas(modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val baseX = w / 2f
        val potTop = h * 0.86f

        // Soil.
        drawOval(color = Color(0.30f, 0.22f, 0.16f), topLeft = Offset(baseX - w * 0.22f, potTop - h * 0.02f), size = androidx.compose.ui.geometry.Size(w * 0.44f, h * 0.06f))

        // Stem — height eased by growth, with a gentle sway.
        val stemH = h * 0.5f * growth
        val stemTopX = baseX + sway * w * 0.05f * growth
        val stemTopY = potTop - stemH
        val ctrl1 = Offset(baseX - w * 0.02f, potTop - stemH * 0.4f)
        val ctrl2 = Offset(baseX + w * 0.02f + sway * w * 0.03f, potTop - stemH * 0.75f)
        if (growth > 0.02f) {
            val stem = Path().apply {
                moveTo(baseX, potTop)
                cubicTo(ctrl1.x, ctrl1.y, ctrl2.x, ctrl2.y, stemTopX, stemTopY)
            }
            drawPath(
                stem,
                brush = Brush.linearGradient(listOf(green, green.copy(alpha = 0.75f)), start = Offset(baseX, potTop), end = Offset(stemTopX, stemTopY)),
                style = Stroke(width = (w * 0.045f).coerceAtLeast(3f), cap = StrokeCap.Round),
            )

            // Two leaves, each popping in once growth passes its threshold.
            drawLeafAt(0.42f, growth, 1f, ctrl1, ctrl2, baseX, potTop, stemTopX, stemTopY, w, green)
            drawLeafAt(0.68f, growth, -1f, ctrl1, ctrl2, baseX, potTop, stemTopX, stemTopY, w, green)

            // A small bud that opens near full growth.
            if (growth > 0.82f) {
                val budProgress = ((growth - 0.82f) / 0.18f).coerceIn(0f, 1f)
                val budRadius = w * 0.09f * budProgress
                drawCircle(color = warm.copy(alpha = 0.9f), radius = budRadius, center = Offset(stemTopX, stemTopY - budRadius * 0.6f))
                drawCircle(color = warm.copy(alpha = 0.5f), radius = budRadius * 1.7f, center = Offset(stemTopX, stemTopY - budRadius * 0.6f))
            }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawLeafAt(
    threshold: Float, growth: Float, side: Float,
    ctrl1: Offset, ctrl2: Offset, baseX: Float, potTop: Float, stemTopX: Float, stemTopY: Float,
    w: Float, tint: Color,
) {
    if (growth < threshold) return
    val leafProgress = ((growth - threshold) / 0.2f).coerceIn(0f, 1f)
    val frac = threshold + 0.05f
    val p0x = baseX; val p0y = potTop
    val t = frac; val mt = 1 - frac
    val originX = mt * mt * mt * p0x + 3 * mt * mt * t * ctrl1.x + 3 * mt * t * t * ctrl2.x + t * t * t * stemTopX
    val originY = mt * mt * mt * p0y + 3 * mt * mt * t * ctrl1.y + 3 * mt * t * t * ctrl2.y + t * t * t * stemTopY
    val origin = Offset(originX, originY)

    val length = w * 0.16f * leafProgress
    val angle = side * 0.9f
    val tip = Offset(origin.x + cos(angle - Math.PI.toFloat() / 2) * length, origin.y + sin(angle - Math.PI.toFloat() / 2) * length)
    val width = length * 0.55f
    val c1 = Offset(origin.x + cos(angle) * width, origin.y + sin(angle) * width)
    val c2 = Offset(origin.x - cos(angle) * width, origin.y - sin(angle) * width)

    val leaf = Path().apply {
        moveTo(origin.x, origin.y)
        quadraticBezierTo(c1.x, c1.y, tip.x, tip.y)
        quadraticBezierTo(c2.x, c2.y, origin.x, origin.y)
        close()
    }
    drawPath(leaf, color = tint.copy(alpha = 0.9f * leafProgress))
}
