package sg.rooted.android.ui.common

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import sg.rooted.android.engine.ImageStore
import sg.rooted.android.model.HealthStatus
import sg.rooted.android.model.PlantStage

/**
 * A plant's real check-in photo where one exists on disk, or its live
 * animated digital twin as the fallback — never a bare emoji, matching how
 * iOS's PlantAvatar always shows something alive.
 */
@Composable
fun PlantPhoto(
    imageFilename: String?,
    stage: PlantStage,
    health: HealthStatus,
    growth: Double,
    streak: Int,
    placeholderTint: Color,
    modifier: Modifier = Modifier,
    animatedFallback: Boolean = false,
) {
    val context = LocalContext.current
    val file = remember(imageFilename) { ImageStore.file(imageFilename) }

    if (file != null && file.exists()) {
        AsyncImage(
            model = ImageRequest.Builder(context).data(file).crossfade(280).build(),
            contentDescription = null, contentScale = ContentScale.Crop, modifier = modifier,
        )
    } else {
        Box(modifier.background(placeholderTint), contentAlignment = Alignment.Center) {
            PlantCharacterView(
                stage = stage, health = health, growth = growth, streak = streak,
                animated = animatedFallback, showsPot = false,
                modifier = Modifier.fillMaxSize().padding(6.dp),
            )
        }
    }
}
