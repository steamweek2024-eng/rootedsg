package sg.rooted.android.ui.common

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalView
import kotlin.math.PI
import kotlin.math.sin

/** Shared motion primitives so ROOTED feels like one game instead of unrelated screens. */
object RootedMotion {
    const val fast = 220
    const val standard = 420
    const val reveal = 620
    val settle = CubicBezierEasing(0.16f, 1f, 0.3f, 1f)
}

/** Slow, tiny idle motion for characters/cards. It never blocks taps. */
@Composable
fun Modifier.rootedBreathe(amplitudePx: Float = 8f, durationMs: Int = 2600): Modifier {
    val transition = rememberInfiniteTransition(label = "rootedBreathe")
    val t by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(durationMs, easing = LinearEasing), RepeatMode.Restart),
        label = "rootedBreatheT",
    )
    return this.graphicsLayer {
        translationY = sin(t * PI.toFloat() * 2f) * amplitudePx
        rotationZ = sin(t * PI.toFloat() * 2f) * 0.35f
    }
}

/** Decorative ambient particles. Kept subtle and deterministic. */
@Composable
fun RootedAmbientField(
    modifier: Modifier = Modifier,
    color: Color,
    content: @Composable BoxScope.() -> Unit,
) {
    val transition = rememberInfiniteTransition(label = "ambient")
    val t by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "ambientT",
    )
    Box(modifier) {
        Canvas(Modifier.fillMaxSize()) {
            val seeds = listOf(
                0.08f to 0.22f, 0.22f to 0.72f, 0.44f to 0.34f, 0.70f to 0.18f,
                0.84f to 0.64f, 0.58f to 0.86f, 0.15f to 0.90f,
            )
            seeds.forEachIndexed { index, (x, y) ->
                val drift = sin((t + index * 0.17f) * PI.toFloat() * 2f)
                drawCircle(
                    color = color.copy(alpha = 0.045f + (index % 3) * 0.012f),
                    radius = size.minDimension * (0.018f + (index % 2) * 0.008f),
                    center = Offset(size.width * x + drift * 13f, size.height * y - drift * 20f),
                )
            }
        }
        content()
    }
}
