package sg.rooted.android.ui.common

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import sg.rooted.android.engine.ImageStore

/**
 * The saved photo for a plant, check-in, listing or sighting — a real photo
 * where this device has one on disk (loaded via Coil, with a crossfade),
 * falling back to the emoji-on-a-tint placeholder everywhere a real photo
 * isn't available yet (a synced listing from another account, for instance).
 */
@Composable
fun RootedPhoto(
    filename: String?,
    placeholderEmoji: String,
    placeholderTint: Color,
    modifier: Modifier = Modifier,
    emojiSize: androidx.compose.ui.unit.TextUnit = 24.sp,
    contentScale: ContentScale = ContentScale.Crop,
) {
    val context = LocalContext.current
    val file = remember(filename) { ImageStore.file(filename) }

    if (file != null && file.exists()) {
        AsyncImage(
            model = ImageRequest.Builder(context).data(file).crossfade(280).build(),
            contentDescription = null,
            contentScale = contentScale,
            modifier = modifier,
        )
    } else {
        Box(modifier.background(placeholderTint), contentAlignment = Alignment.Center) {
            Text(placeholderEmoji, fontSize = emojiSize)
        }
    }
}
