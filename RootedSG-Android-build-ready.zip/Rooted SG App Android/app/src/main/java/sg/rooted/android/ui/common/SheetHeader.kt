package sg.rooted.android.ui.common

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import sg.rooted.android.ui.theme.LocalRootedAppearance
import sg.rooted.android.ui.theme.RootedMetrics

/**
 * A thin header for a pushed screen — a Compose port of iOS's SheetHeader:
 * a centred title over a solid ground-coloured bar, with a circular "close"
 * glyph on the left rather than a literal text button. `leading` is kept as
 * the icon's accessibility label so existing call sites don't need to change.
 */
@Composable
fun SheetHeader(title: String, onClose: () -> Unit, leading: String = "Close", trailing: (@Composable () -> Unit)? = null) {
    val p = LocalRootedAppearance.current.canvas
    Box(
        Modifier.fillMaxWidth()
            .background(LocalRootedAppearance.current.ground)
            .padding(horizontal = RootedMetrics.pagePadding.dp, vertical = 12.dp),
    ) {
        Text(
            title, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Medium,
            modifier = Modifier.align(Alignment.Center),
        )
        Box(
            Modifier
                .align(Alignment.CenterStart)
                .size(34.dp)
                .background(p.text.copy(alpha = 0.06f), CircleShape)
                .noRippleClickable(onClick = onClose),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Filled.Close, contentDescription = leading, tint = p.text, modifier = Modifier.size(16.dp))
        }
        if (trailing != null) {
            Box(Modifier.align(Alignment.CenterEnd)) { trailing() }
        }
    }
}
