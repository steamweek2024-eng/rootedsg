package sg.rooted.android.ui.common

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.ui.graphics.vector.ImageVector

/** The same four Material icons used for the Home weather card, shared here so the
 * animated detail view's icon composables match it exactly. */
object WeatherGlyphs {
    val cloud: ImageVector = Icons.Filled.Cloud
    val sun: ImageVector = Icons.Filled.WbSunny
    val heat: ImageVector = Icons.Filled.Whatshot
    val leaf: ImageVector = Icons.Filled.Eco
}
