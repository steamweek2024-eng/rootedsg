package sg.rooted.android.ui.community

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import sg.rooted.android.RootedViewModel
import sg.rooted.android.engine.ExchangeEngine
import sg.rooted.android.ui.common.SheetHeader
import sg.rooted.android.ui.theme.LocalRootedAppearance
import sg.rooted.android.ui.theme.RisesIn
import sg.rooted.android.ui.theme.RootedBackground
import sg.rooted.android.ui.theme.RootedMetrics

@Composable
fun CommunityScreen(viewModel: RootedViewModel, onClose: () -> Unit) {
    val appearance = LocalRootedAppearance.current
    val p = appearance.canvas
    val plants by viewModel.plants.collectAsState()
    val listings by viewModel.listings.collectAsState()
    val user by viewModel.user.collectAsState()

    val totalDays = plants.sumOf { it.verifiedPlantDays }
    val householdsServed = listings.filter { it.ownerId == user?.id }.sumOf { it.claimedCount }

    Column(Modifier.fillMaxSize().background(appearance.ground).safeDrawingPadding()) {
        SheetHeader(title = "Singapore", onClose = onClose)

        Column(Modifier.fillMaxSize().padding(horizontal = (RootedMetrics.pagePadding + 8).dp)) {
            RisesIn(index = 1) { m ->
                Column(m) {
                    Text(
                        "Singapore's Green Plan targets 30% of nutritional need grown locally by 2030, \"30 by 30\".",
                        color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Light,
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(ExchangeEngine.IMPORT_DEPENDENCE_NOTE, color = p.secondary, fontSize = 13.sp)
                }
            }
            Spacer(Modifier.height(24.dp))

            RisesIn(index = 2) { m ->
                Row(
                    m.fillMaxWidth().background(p.faintFill, RoundedCornerShape(RootedMetrics.cardRadius.dp)).padding(18.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("$totalDays", color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Light)
                        Text(
                            "Your Verified Plant-Days", color = p.secondary, fontSize = 11.sp, lineHeight = 14.sp,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    Column(Modifier.weight(1f)) {
                        Text("$householdsServed", color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Light)
                        Text(
                            "Households you've served", color = p.secondary, fontSize = 11.sp, lineHeight = 14.sp,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            RisesIn(index = 3) { m ->
                Text(
                    "ROOTED never claims this app alone moves that national number, it just makes your own small plot, and the produce it grows, count toward something real.",
                    color = p.secondary, fontSize = 12.sp, modifier = m,
                )
            }
        }
    }
}
