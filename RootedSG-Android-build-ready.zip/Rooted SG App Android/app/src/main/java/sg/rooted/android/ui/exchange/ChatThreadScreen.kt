package sg.rooted.android.ui.exchange

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import sg.rooted.android.RootedViewModel
import sg.rooted.android.data.MarketRepository
import sg.rooted.android.model.ChatMessage
import sg.rooted.android.ui.common.SheetHeader
import sg.rooted.android.ui.theme.LocalRootedAppearance
import sg.rooted.android.ui.theme.RootedBackground
import sg.rooted.android.ui.theme.RootedMetrics
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatThreadScreen(viewModel: RootedViewModel, threadId: String, onClose: () -> Unit) {
    val appearance = LocalRootedAppearance.current
    val p = appearance.canvas
    val user by viewModel.user.collectAsState()
    val thread by remember(threadId) { viewModel.market.observeChatThread(threadId) }.collectAsState(initial = null)
    val messages by remember(threadId) { viewModel.market.observeChatMessages(threadId) }.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val timeFormat = remember { SimpleDateFormat("h:mm a", Locale.getDefault()) }

    var draft by remember { mutableStateOf("") }
    var isSending by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Ensures the backend conversation exists, then polls every 4 seconds while this
    // thread is on screen — matches the iOS app's bootstrap()/startPolling() cadence.
    LaunchedEffect(threadId) {
        while (thread == null) delay(50)
        var current = thread!!
        if (current.remoteConversationId.isEmpty()) {
            val u = user
            if (u != null) {
                viewModel.market.ensureConversation(current, u)
                    .onSuccess { current = it }
                    .onFailure { errorMessage = it.message }
            }
        }
        var initial = true
        while (true) {
            if (current.remoteConversationId.isNotEmpty()) {
                viewModel.market.pollMessages(current, initial)
                    .onSuccess { errorMessage = null }
                    .onFailure { if (initial) errorMessage = it.message }
                initial = false
            }
            delay(4000)
            thread?.let { current = it }
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    Column(Modifier.fillMaxSize().background(appearance.ground).safeDrawingPadding()) {
        SheetHeader(title = "${thread?.otherPartyAvatar ?: ""} ${thread?.otherPartyName ?: "Chat"}", onClose = onClose)

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (messages.isEmpty()) {
                Column(Modifier.padding(horizontal = (RootedMetrics.pagePadding + 8).dp).padding(top = 20.dp)) {
                    Text("About \"${thread?.listingHeadline ?: ""}\"", color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        if (thread?.isSeededOtherParty == true)
                            "${thread?.otherPartyName} is one of the sample marketplace's growers. Your message really sends through ROOTED's server, they'll write back with a quick, clearly-scripted note since there's no real account behind them yet."
                        else "Messages here go through ROOTED's own server, not straight between your devices.",
                        color = p.secondary, fontSize = 12.sp,
                    )
                }
            }
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize().padding(horizontal = (RootedMetrics.pagePadding + 8).dp),
                contentPadding = PaddingValues(top = 8.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(messages, key = { it.id }) { message ->
                    ChatBubble(message, timeFormat)
                }
            }
        }

        if (errorMessage != null) {
            Text(errorMessage!!, color = p.warm, fontSize = 12.sp, modifier = Modifier.padding(horizontal = (RootedMetrics.pagePadding + 8).dp))
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = (RootedMetrics.pagePadding + 8).dp).padding(vertical = 10.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            OutlinedTextField(
                value = draft, onValueChange = { draft = it },
                placeholder = { Text("Message ${thread?.otherPartyName ?: ""}") },
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(8.dp))
            IconButton(
                onClick = {
                    val u = user ?: return@IconButton
                    val currentThread = thread ?: return@IconButton
                    val text = draft.trim()
                    if (text.isEmpty() || isSending) return@IconButton
                    draft = ""
                    isSending = true
                    scope.launch {
                        val result = viewModel.market.sendChatMessage(currentThread, u, text)
                        isSending = false
                        if (result is MarketRepository.SendResult.Failed) {
                            errorMessage = result.message
                            draft = text
                        } else {
                            errorMessage = null
                        }
                    }
                },
                enabled = draft.isNotBlank() && !isSending,
                modifier = Modifier.background(p.green, androidx.compose.foundation.shape.CircleShape),
            ) { Icon(Icons.Filled.Send, contentDescription = "Send", tint = p.onAccent) }
        }
    }
}

@Composable
private fun ChatBubble(message: ChatMessage, timeFormat: SimpleDateFormat) {
    val p = LocalRootedAppearance.current.canvas
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.isMine) Arrangement.End else Arrangement.Start) {
        Column(horizontalAlignment = if (message.isMine) Alignment.End else Alignment.Start, modifier = Modifier.fillMaxWidth(0.8f)) {
            Text(
                message.text,
                color = if (message.isMine) p.onAccent else p.text,
                fontSize = 14.sp,
                modifier = Modifier
                    .background(if (message.isMine) p.green else p.faintFill, RoundedCornerShape(RootedMetrics.chipRadius.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
            )
            Spacer(Modifier.height(2.dp))
            Text(timeFormat.format(Date(message.createdDate)), color = p.secondary.copy(alpha = 0.8f), fontSize = 9.sp)
        }
    }
}
