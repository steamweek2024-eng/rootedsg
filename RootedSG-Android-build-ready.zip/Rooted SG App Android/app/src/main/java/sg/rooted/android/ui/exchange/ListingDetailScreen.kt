package sg.rooted.android.ui.exchange

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import sg.rooted.android.RootedViewModel
import sg.rooted.android.data.MarketRepository
import sg.rooted.android.ui.common.RootedPhoto
import sg.rooted.android.ui.common.SheetHeader
import sg.rooted.android.ui.theme.LocalRootedAppearance
import sg.rooted.android.ui.theme.RootedBackground
import sg.rooted.android.ui.theme.RootedMetrics

@Composable
fun ListingDetailScreen(viewModel: RootedViewModel, listingId: String, onClose: () -> Unit, onChat: (String) -> Unit) {
    val appearance = LocalRootedAppearance.current
    val p = appearance.canvas
    val user by viewModel.user.collectAsState()
    val listing by remember(listingId) { viewModel.market.observeListing(listingId) }.collectAsState(initial = null)
    val scope = rememberCoroutineScope()

    var isBusy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var showOfferField by remember { mutableStateOf(false) }
    var offerNote by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().background(appearance.ground).safeDrawingPadding()) {
        SheetHeader(title = "Listing", onClose = onClose)

        val current = listing
        if (current == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                Text("This listing is no longer available.", color = p.secondary, fontSize = 14.sp)
            }
            return@Column
        }

        Column(Modifier.fillMaxSize().padding(horizontal = (RootedMetrics.pagePadding + 8).dp)) {
            RootedPhoto(
                filename = current.imageFilename, placeholderEmoji = current.produce.emoji, placeholderTint = p.faintFill,
                emojiSize = 52.sp, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(RootedMetrics.heroRadius.dp)),
            )
            Spacer(Modifier.height(14.dp))
            Text(current.headline, color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Light)
            Spacer(Modifier.height(6.dp))
            Text("${current.growerAvatar} ${current.growerName} · ${current.neighbourhood}", color = p.secondary, fontSize = 13.sp)
            Spacer(Modifier.height(4.dp))
            Text("${current.growerPlantDays} Verified Plant-Days", color = p.secondary, fontSize = 12.sp)
            Spacer(Modifier.height(16.dp))
            if (current.detail.isNotBlank()) {
                Text(current.detail, color = p.text, fontSize = 14.sp)
                Spacer(Modifier.height(12.dp))
            }
            current.stockDisplay?.let { Text(it, color = p.secondary, fontSize = 13.sp) }
            if (current.quantityLabel.isNotBlank()) Text(current.quantityLabel, color = p.secondary, fontSize = 13.sp)
            current.priceDisplay?.let { Text(it, color = p.warm, fontSize = 15.sp, fontWeight = FontWeight.Medium) }
            Text(current.terms.detail, color = p.secondary, fontSize = 12.sp)

            Spacer(Modifier.height(24.dp))
            message?.let {
                Text(it, color = p.warm, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
            }

            val isOwn = current.ownerId == user?.id
            if (!isOwn) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            val u = user ?: return@Button
                            if (isBusy) return@Button
                            isBusy = true
                            scope.launch {
                                val result = if (current.isSynced && u.isSignedIn) {
                                    when (val outcome = viewModel.market.confirmedBuy(current, 1, "", u)) {
                                        is MarketRepository.ClaimOutcome.Confirmed -> "Reserved! The grower will be in touch."
                                        is MarketRepository.ClaimOutcome.Failed -> outcome.message
                                    }
                                } else {
                                    when (viewModel.market.buy(current, u)) {
                                        is MarketRepository.ClaimResult.Claimed -> "Reserved! Message the grower to arrange pick-up."
                                        MarketRepository.ClaimResult.Full -> "That listing just filled up."
                                        MarketRepository.ClaimResult.OwnListing -> "This is your own listing."
                                        MarketRepository.ClaimResult.AlreadyClaimed -> "You've already claimed this listing."
                                    }
                                }
                                message = result
                                isBusy = false
                            }
                        },
                        enabled = current.isAvailable && !isBusy,
                        colors = ButtonDefaults.buttonColors(containerColor = p.green, contentColor = p.onAccent),
                        shape = RoundedCornerShape(RootedMetrics.buttonRadius.dp),
                    ) { Text(if (isBusy) "Working…" else "Buy") }

                    OutlinedButton(onClick = { showOfferField = !showOfferField }, shape = RoundedCornerShape(RootedMetrics.buttonRadius.dp)) {
                        Text("Make an offer")
                    }
                }

                if (showOfferField) {
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = offerNote, onValueChange = { offerNote = it },
                        label = { Text("Your offer (quantity, swap, timing…)") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = {
                        val u = user ?: return@Button
                        scope.launch {
                            viewModel.market.proposeOffer(current, u, offerNote)
                            message = "Offer sent, the grower will review it."
                            showOfferField = false
                        }
                    }) { Text("Send offer") }
                }

                Spacer(Modifier.height(14.dp))
                TextButton(onClick = {
                    val u = user ?: return@TextButton
                    scope.launch {
                        val thread = viewModel.market.chatThreadFor(current, u)
                        onChat(thread.id)
                    }
                }) { Text("Message ${current.growerName}") }
            } else {
                Text("This is your listing, ${current.claimedCount} of ${current.capacityHouseholds} households claimed.", color = p.secondary, fontSize = 13.sp)
            }
        }
    }
}
