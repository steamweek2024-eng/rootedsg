package sg.rooted.android.ui.exchange

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import sg.rooted.android.RootedViewModel
import sg.rooted.android.engine.ExchangeEngine
import sg.rooted.android.model.ExchangeTerms
import sg.rooted.android.model.ProduceKind
import sg.rooted.android.model.ProduceListing
import sg.rooted.android.model.ProduceRequest
import sg.rooted.android.ui.common.noRippleClickable
import sg.rooted.android.ui.common.rootedPressable
import sg.rooted.android.ui.pet.WalkTarget
import sg.rooted.android.ui.pet.walkAnchor
import sg.rooted.android.ui.theme.GreenTag
import sg.rooted.android.ui.theme.LocalRootedAppearance
import sg.rooted.android.ui.theme.RisesIn
import sg.rooted.android.ui.theme.RootedMetrics

@Composable
fun MarketScreen(viewModel: RootedViewModel, onOpenListing: (String) -> Unit) {
    val appearance = LocalRootedAppearance.current
    val p = appearance.canvas
    val user by viewModel.user.collectAsState()
    val listings by viewModel.listings.collectAsState()
    val requests by viewModel.requests.collectAsState()
    val scope = rememberCoroutineScope()

    var showOffer by remember { mutableStateOf(false) }
    var showRequest by remember { mutableStateOf(false) }
    var isSyncing by remember { mutableStateOf(false) }

    LaunchedEffect(user?.isSignedIn) {
        val u = user ?: return@LaunchedEffect
        if (u.isSignedIn) {
            viewModel.market.pullListings(u)
            viewModel.market.pullRequests(u)
        }
    }

    Column(Modifier.fillMaxSize()) {
        RisesIn(index = 1) { m ->
            Row(
                m.fillMaxWidth().padding(horizontal = (RootedMetrics.pagePadding + 8).dp, vertical = 10.dp)
                    .walkAnchor(WalkTarget.SCREEN_HERO),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Button(
                    onClick = { showOffer = true },
                    colors = ButtonDefaults.buttonColors(containerColor = p.green, contentColor = p.onAccent),
                    shape = RoundedCornerShape(RootedMetrics.buttonRadius.dp),
                ) { Text("Offer produce", fontSize = 13.sp) }
                Button(
                    onClick = { showRequest = true },
                    colors = ButtonDefaults.buttonColors(containerColor = p.faintFill, contentColor = p.text),
                    shape = RoundedCornerShape(RootedMetrics.buttonRadius.dp),
                ) { Text("Request produce", fontSize = 13.sp) }
                if (user?.isSignedIn == true) {
                    Spacer(Modifier.weight(1f))
                    Text(
                        if (isSyncing) "Syncing…" else "Refresh",
                        color = p.secondary, fontSize = 12.sp,
                        modifier = Modifier.noRippleClickable {
                            val u = user ?: return@noRippleClickable
                            isSyncing = true
                            scope.launch {
                                viewModel.market.pullListings(u)
                                viewModel.market.pullRequests(u)
                                isSyncing = false
                            }
                        }.align(Alignment.CenterVertically),
                    )
                }
            }
        }

        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = (RootedMetrics.pagePadding + 8).dp),
            contentPadding = PaddingValues(bottom = 120.dp),
        ) {
            item {
                Text(ExchangeEngine.IMPORT_DEPENDENCE_NOTE, color = p.secondary, fontSize = 11.sp)
                Spacer(Modifier.height(16.dp))
                Text("LISTINGS", color = p.secondary, fontSize = 10.sp, letterSpacing = 1.6.sp)
                Spacer(Modifier.height(10.dp))
            }
            val available = listings.filter { it.isAvailable || it.ownerId == user?.id }
            if (available.isEmpty()) {
                item { Text("No listings yet, be the first to offer something.", color = p.secondary, fontSize = 13.sp) }
            }
            items(available.sortedByDescending { it.createdDate }, key = { it.id }) { listing ->
                ListingRow(listing, onOpenListing)
                Spacer(Modifier.height(10.dp))
            }

            item {
                Spacer(Modifier.height(20.dp))
                Text("REQUESTS", color = p.secondary, fontSize = 10.sp, letterSpacing = 1.6.sp)
                Spacer(Modifier.height(10.dp))
            }
            val openRequests = requests.filter { it.status == sg.rooted.android.model.RequestStatus.OPEN }
            if (openRequests.isEmpty()) {
                item { Text("No open requests.", color = p.secondary, fontSize = 13.sp) }
            }
            items(openRequests.sortedByDescending { it.createdDate }, key = { it.id }) { request ->
                RequestRow(request)
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    if (showOffer) {
        OfferProduceSheet(viewModel = viewModel, onDismiss = { showOffer = false })
    }
    if (showRequest) {
        RequestProduceSheet(viewModel = viewModel, onDismiss = { showRequest = false })
    }
}

@Composable
private fun ListingRow(listing: ProduceListing, onOpenListing: (String) -> Unit) {
    val p = LocalRootedAppearance.current.canvas
    Row(
        Modifier
            .fillMaxWidth()
            .background(p.faintFill, RoundedCornerShape(RootedMetrics.cardRadius.dp))
            .rootedPressable(haptic = false) { onOpenListing(listing.id) }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        sg.rooted.android.ui.common.RootedPhoto(
            filename = listing.imageFilename, placeholderEmoji = listing.produce.emoji, placeholderTint = p.faintFill,
            emojiSize = 26.sp, contentScale = androidx.compose.ui.layout.ContentScale.Crop,
            modifier = Modifier.size(56.dp).clip(RoundedCornerShape(RootedMetrics.thumbRadius.dp)),
        )
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(listing.headline, color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 2)
            Spacer(Modifier.height(4.dp))
            Text(
                "${listing.growerAvatar} ${listing.growerName} · ${listing.neighbourhood}",
                color = p.secondary, fontSize = 11.sp,
            )
            listing.priceDisplay?.let { Text(it, color = p.warm, fontSize = 12.sp, fontWeight = FontWeight.Medium) }
        }
        GreenTag(text = if (listing.isAvailable) "${listing.spacesLeft} left" else "Full", filled = listing.isAvailable)
    }
}

@Composable
private fun RequestRow(request: ProduceRequest) {
    val p = LocalRootedAppearance.current.canvas
    Row(
        Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(RootedMetrics.chipRadius.dp)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(request.produce.emoji, fontSize = 20.sp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("${request.requesterAvatar} ${request.requesterName} wants ${request.produce.label.lowercase()}", color = p.text, fontSize = 13.sp)
            if (request.note.isNotBlank()) Text(request.note, color = p.secondary, fontSize = 11.sp)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun OfferProduceSheet(viewModel: RootedViewModel, onDismiss: () -> Unit) {
    val user by viewModel.user.collectAsState()
    var eligibility by remember { mutableStateOf<ExchangeEngine.ListingEligibility?>(null) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(user?.id) { user?.let { eligibility = viewModel.market.eligibility(it) } }

    var produce by remember { mutableStateOf(ProduceKind.TOMATO) }
    var headline by remember { mutableStateOf("") }
    var detail by remember { mutableStateOf("") }
    var terms by remember { mutableStateOf(ExchangeTerms.FREE) }
    var households by remember { mutableStateOf(2) }
    var quantityLabel by remember { mutableStateOf("") }
    var isSaving by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 32.dp)) {
            Text("Offer produce", fontSize = 18.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(12.dp))
            val elig = eligibility
            if (elig != null && !elig.isEligible) {
                Text(elig.explanation, fontSize = 13.sp)
                return@Column
            }
            ProduceKindPicker(selected = produce, onSelect = { produce = it })
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = headline, onValueChange = { headline = it }, label = { Text("Headline") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = detail, onValueChange = { detail = it }, label = { Text("Detail") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = quantityLabel, onValueChange = { quantityLabel = it }, label = { Text("Quantity (e.g. \"a small bunch\")") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            TermsPicker(selected = terms, onSelect = { terms = it })
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    val u = user ?: return@Button
                    if (isSaving) return@Button
                    isSaving = true
                    scope.launch {
                        viewModel.market.offerProduce(
                            user = u, produce = produce, headline = headline, detail = detail, terms = terms,
                            households = households, bitmap = null, quantityLabel = quantityLabel,
                        )
                        isSaving = false
                        onDismiss()
                    }
                },
                enabled = !isSaving,
                modifier = Modifier.fillMaxWidth(),
            ) { Text(if (isSaving) "Posting…" else "Post listing") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RequestProduceSheet(viewModel: RootedViewModel, onDismiss: () -> Unit) {
    val user by viewModel.user.collectAsState()
    val scope = rememberCoroutineScope()
    var produce by remember { mutableStateOf(ProduceKind.TOMATO) }
    var note by remember { mutableStateOf("") }
    var isSaving by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 32.dp)) {
            Text("Request produce", fontSize = 18.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(12.dp))
            ProduceKindPicker(selected = produce, onSelect = { produce = it })
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Note") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    val u = user ?: return@Button
                    if (isSaving) return@Button
                    isSaving = true
                    scope.launch {
                        viewModel.market.requestProduce(u, produce, note)
                        isSaving = false
                        onDismiss()
                    }
                },
                enabled = !isSaving,
                modifier = Modifier.fillMaxWidth(),
            ) { Text(if (isSaving) "Posting…" else "Post request") }
        }
    }
}

@Composable
fun ProduceKindPicker(selected: ProduceKind, onSelect: (ProduceKind) -> Unit) {
    androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(ProduceKind.entries) { kind ->
            val isSelected = kind == selected
            Text(
                "${kind.emoji} ${kind.label}", fontSize = 12.sp,
                modifier = Modifier
                    .background(
                        if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else androidx.compose.ui.graphics.Color.Transparent,
                        RoundedCornerShape(RootedMetrics.buttonRadius.dp),
                    )
                    .noRippleClickable { onSelect(kind) }
                    .padding(horizontal = 10.dp, vertical = 6.dp),
            )
        }
    }
}

@Composable
fun TermsPicker(selected: ExchangeTerms, onSelect: (ExchangeTerms) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ExchangeTerms.entries.forEach { t ->
            val isSelected = t == selected
            Text(
                t.label, fontSize = 12.sp,
                modifier = Modifier
                    .background(
                        if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else androidx.compose.ui.graphics.Color.Transparent,
                        RoundedCornerShape(RootedMetrics.buttonRadius.dp),
                    )
                    .noRippleClickable { onSelect(t) }
                    .padding(horizontal = 10.dp, vertical = 6.dp),
            )
        }
    }
}
