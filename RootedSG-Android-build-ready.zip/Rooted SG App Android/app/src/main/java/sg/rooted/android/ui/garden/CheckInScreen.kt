package sg.rooted.android.ui.garden

import android.graphics.Bitmap
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import sg.rooted.android.RootedViewModel
import sg.rooted.android.data.GardenRepository
import sg.rooted.android.engine.VisionService
import sg.rooted.android.model.*
import sg.rooted.android.ui.common.RootedAmbientField
import sg.rooted.android.ui.common.SheetHeader
import sg.rooted.android.ui.common.rememberPhotoCapturePicker
import sg.rooted.android.ui.common.rootedBreathe
import sg.rooted.android.ui.theme.GreenBar
import sg.rooted.android.ui.theme.LocalRootedAppearance
import sg.rooted.android.ui.theme.RootedMetrics

private enum class MissionPhase {
    INTRO, PHOTO, SCANNING, CLUES, YOUR_READ, VERDICT, TREATMENT, RECHECK_READY, RESULT
}

@Composable
fun CheckInScreen(viewModel: RootedViewModel, plantId: String, onClose: () -> Unit) {
    val appearance = LocalRootedAppearance.current
    val p = appearance.canvas
    val user by viewModel.user.collectAsState()
    val plant by remember(plantId) { viewModel.garden.observePlant(plantId) }.collectAsState(initial = null)
    val quests by viewModel.quests.collectAsState()
    val diagnosisHistory by remember(plantId) { viewModel.garden.observeDiagnosisSessions(plantId) }.collectAsState(initial = emptyList())
    val photo = rememberPhotoCapturePicker()
    val scope = rememberCoroutineScope()

    val activeRescue = quests.firstOrNull {
        it.relatedPlantID == plantId && it.type == QuestType.RECOVERY && it.status == QuestStatus.ACTIVE
    }
    var phase by remember(plantId) {
        mutableStateOf(if (activeRescue?.objectivesComplete == true) MissionPhase.RECHECK_READY else MissionPhase.INTRO)
    }
    var profile by remember { mutableStateOf<VisionService.ColorProfile?>(null) }
    var verification by remember { mutableStateOf<VisionService.VerificationResult?>(null) }
    var duplicate by remember { mutableStateOf(false) }
    var session by remember { mutableStateOf<DiagnosisSession?>(diagnosisHistory.firstOrNull()) }
    var choiceOutcome by remember { mutableStateOf<GardenRepository.DiagnosisChoiceOutcome?>(null) }
    var checkInOutcome by remember { mutableStateOf<GardenRepository.CheckInOutcome?>(null) }
    var revealedClues by remember { mutableIntStateOf(0) }
    var scanStep by remember { mutableIntStateOf(0) }
    var isRecheck by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(diagnosisHistory.firstOrNull()?.id) {
        if (session == null) session = diagnosisHistory.firstOrNull()
    }

    LaunchedEffect(photo.bitmap) {
        val bitmap = photo.bitmap ?: return@LaunchedEffect
        profile = VisionService.colorProfile(bitmap)
        verification = VisionService.verifyVegetation(bitmap)
        val u = user
        val pl = plant
        duplicate = if (u != null && pl != null) {
            viewModel.garden.duplicatePlant(u, bitmap)?.id == pl.id
        } else false
    }

    LaunchedEffect(phase, session?.id) {
        if (phase == MissionPhase.CLUES) {
            revealedClues = 0
            val count = session?.clues?.size ?: 0
            repeat(count) {
                delay(520)
                revealedClues = it + 1
            }
        }
    }

    Column(Modifier.fillMaxSize().background(appearance.ground).safeDrawingPadding()) {
        SheetHeader(
            title = when (phase) {
                MissionPhase.INTRO -> "Plant Health Quest"
                MissionPhase.PHOTO -> if (isRecheck) "Recovery Recheck" else "Collect Evidence"
                MissionPhase.SCANNING -> "Investigating"
                MissionPhase.CLUES -> "Clues Found"
                MissionPhase.YOUR_READ -> "Your Read"
                MissionPhase.VERDICT -> "ROOTED's Read"
                MissionPhase.TREATMENT -> "Treatment Quest"
                MissionPhase.RECHECK_READY -> "Recheck Ready"
                MissionPhase.RESULT -> "Mission Result"
            },
            onClose = onClose,
        )

        RootedAmbientField(
            modifier = Modifier.fillMaxSize(), color = p.green,
        ) {
            AnimatedContent(
                targetState = phase,
                transitionSpec = {
                    (fadeIn(tween(340)) + slideInVertically(tween(420)) { it / 14 }) togetherWith
                        (fadeOut(tween(220)) + slideOutVertically(tween(260)) { -it / 20 })
                },
                label = "missionPhase",
            ) { current ->
                when (current) {
                    MissionPhase.INTRO -> MissionIntro(
                        plant = plant,
                        activeRescue = activeRescue,
                        onStart = {
                            isRecheck = false
                            errorMessage = null
                            phase = MissionPhase.PHOTO
                        },
                        onContinueRescue = {
                            phase = if (activeRescue?.objectivesComplete == true) MissionPhase.RECHECK_READY else MissionPhase.TREATMENT
                        },
                    )
                    MissionPhase.PHOTO -> PhotoMission(
                        plant = plant, bitmap = photo.bitmap, verification = verification, duplicate = duplicate,
                        isRecheck = isRecheck, error = errorMessage,
                        onCamera = photo::launchCamera, onGallery = photo::launchGallery, onClear = photo::clear,
                        onScan = {
                            val u = user; val pl = plant; val bitmap = photo.bitmap; val v = verification; val pr = profile
                            if (u == null || pl == null || bitmap == null || v == null || pr == null) return@PhotoMission
                            scope.launch {
                                errorMessage = null
                                phase = MissionPhase.SCANNING
                                scanStep = 0
                                val ticker = launch {
                                    while (true) {
                                        delay(520)
                                        scanStep = (scanStep + 1) % 5
                                    }
                                }
                                runCatching {
                                    val outcome = viewModel.garden.processCheckIn(pl, u, bitmap, v, pr, duplicate)
                                    checkInOutcome = outcome
                                    if (!outcome.verified) {
                                        ticker.cancel()
                                        phase = MissionPhase.RESULT
                                        return@runCatching
                                    }
                                    if (isRecheck && activeRescue != null) {
                                        ticker.cancel()
                                        phase = MissionPhase.RESULT
                                    } else {
                                        val created = viewModel.garden.createDiagnosisSession(pl, u, bitmap, v, pr)
                                        session = created
                                        ticker.cancel()
                                        phase = MissionPhase.CLUES
                                    }
                                }.onFailure {
                                    ticker.cancel()
                                    errorMessage = it.message ?: "Something interrupted the investigation. Try again."
                                    phase = MissionPhase.PHOTO
                                }
                            }
                        },
                    )
                    MissionPhase.SCANNING -> ScanningMission(photo.bitmap, scanStep)
                    MissionPhase.CLUES -> CluesMission(
                        plant = plant, session = session, revealed = revealedClues,
                        onContinue = { phase = MissionPhase.YOUR_READ },
                    )
                    MissionPhase.YOUR_READ -> YourReadMission(
                        session = session,
                        onChoose = { choice ->
                            val s = session ?: return@YourReadMission
                            scope.launch {
                                runCatching { viewModel.garden.submitDiagnosisChoice(s.id, choice.label) }
                                    .onSuccess {
                                        choiceOutcome = it
                                        session = it.session
                                        phase = MissionPhase.VERDICT
                                    }
                                    .onFailure { errorMessage = it.message }
                            }
                        },
                    )
                    MissionPhase.VERDICT -> VerdictMission(
                        plant = plant, outcome = choiceOutcome, session = session,
                        onContinue = {
                            phase = if (choiceOutcome?.quest != null) MissionPhase.TREATMENT else MissionPhase.RESULT
                        },
                    )
                    MissionPhase.TREATMENT -> TreatmentMission(
                        plant = plant,
                        quest = activeRescue ?: choiceOutcome?.quest,
                        onCompleteObjective = { questId, objectiveId ->
                            scope.launch { viewModel.garden.completeQuestObjective(questId, objectiveId) }
                        },
                        onRecheck = {
                            photo.clear()
                            profile = null
                            verification = null
                            duplicate = false
                            isRecheck = true
                            phase = MissionPhase.RECHECK_READY
                        },
                    )
                    MissionPhase.RECHECK_READY -> RecheckReadyMission(
                        plant = plant,
                        quest = activeRescue ?: choiceOutcome?.quest,
                        onStart = {
                            photo.clear()
                            profile = null
                            verification = null
                            duplicate = false
                            isRecheck = true
                            phase = MissionPhase.PHOTO
                        },
                    )
                    MissionPhase.RESULT -> MissionResult(
                        plant = plant,
                        outcome = checkInOutcome,
                        session = session,
                        rescueQuest = quests.firstOrNull { it.id == (activeRescue?.id ?: choiceOutcome?.quest?.id) },
                        onRetake = {
                            photo.clear(); profile = null; verification = null; duplicate = false
                            phase = MissionPhase.PHOTO
                        },
                        onDone = onClose,
                    )
                }
            }
        }
    }
}

@Composable
private fun MissionIntro(plant: Plant?, activeRescue: Quest?, onStart: () -> Unit, onContinueRescue: () -> Unit) {
    val p = LocalRootedAppearance.current.canvas
    val hasRescue = activeRescue != null
    Column(
        Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(20.dp))
        Box(
            Modifier.size(170.dp).background(p.green.copy(alpha = 0.10f), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            if (plant != null) {
                Text(plant.speciesEmoji, fontSize = 82.sp, modifier = Modifier.rootedBreathe(10f))
                Canvas(Modifier.fillMaxSize()) {
                    drawCircle(p.green.copy(alpha = 0.22f), style = Stroke(width = 2.dp.toPx()))
                }
            }
        }
        Spacer(Modifier.height(24.dp))
        Text(if (hasRescue) "${plant?.name ?: "Your plant"} has an active rescue" else "Something may have changed…", color = p.text, fontSize = 25.sp, fontWeight = FontWeight.Light, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(
            if (hasRescue) "Finish the care objectives, then prove the recovery with a fresh photo."
            else "Collect evidence, reveal the clues, make your read, then let ROOTED guide the safest next action.",
            color = p.secondary, fontSize = 14.sp, textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(22.dp))
        MissionLoopStrip()
        Spacer(Modifier.weight(1f))
        if (hasRescue) {
            PrimaryMissionButton(
                text = if (activeRescue?.objectivesComplete == true) "START RECOVERY RECHECK" else "CONTINUE RESCUE QUEST",
                onClick = onContinueRescue,
            )
            Spacer(Modifier.height(10.dp))
            TextButton(onClick = onStart) { Text("Run a new plant investigation", color = p.secondary) }
        } else {
            PrimaryMissionButton("START INVESTIGATION 🌿", onStart)
        }
    }
}

@Composable
private fun MissionLoopStrip() {
    val p = LocalRootedAppearance.current.canvas
    val stages = listOf("SCAN", "CLUES", "READ", "TREAT", "RECHECK")
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        stages.forEachIndexed { index, item ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(24.dp).background(p.green.copy(alpha = 0.12f), CircleShape), contentAlignment = Alignment.Center) {
                    Text("${index + 1}", color = p.green, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(5.dp))
                Text(item, color = p.secondary, fontSize = 8.sp, letterSpacing = 0.8.sp)
            }
        }
    }
}

@Composable
private fun PhotoMission(
    plant: Plant?, bitmap: Bitmap?, verification: VisionService.VerificationResult?, duplicate: Boolean,
    isRecheck: Boolean, error: String?, onCamera: () -> Unit, onGallery: () -> Unit, onClear: () -> Unit, onScan: () -> Unit,
) {
    val p = LocalRootedAppearance.current.canvas
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 24.dp),
        contentPadding = PaddingValues(bottom = 34.dp),
    ) {
        item {
            Text(if (isRecheck) "RECOVERY EVIDENCE" else "3 CLUES NEEDED", color = p.warm, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
            Spacer(Modifier.height(8.dp))
            Text(
                if (isRecheck) "Show us what changed" else "Photograph ${plant?.name ?: "your plant"} like a detective",
                color = p.text, fontSize = 23.sp, fontWeight = FontWeight.Light,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                if (isRecheck) "Use a fresh photo from roughly the same angle so the recovery comparison is meaningful."
                else "Try to include a damaged or representative leaf, the soil/pot, and some new growth if visible.",
                color = p.secondary, fontSize = 13.sp,
            )
            Spacer(Modifier.height(14.dp))
            PhotoObjective("🍃", "Leaves", bitmap != null)
            PhotoObjective("🪴", "Soil / pot context", bitmap != null)
            PhotoObjective("🌱", "Growth area", bitmap != null)
            Spacer(Modifier.height(14.dp))
            CapturePane(
                bitmap = bitmap,
                title = if (isRecheck) "Take the recovery photo" else "Collect your evidence",
                subtitle = "Bright, even daylight works best. Avoid screenshots or reusing an old photo.",
                onCamera = onCamera,
                onGallery = onGallery,
                onCleared = onClear,
            )
            verification?.let { v ->
                Spacer(Modifier.height(12.dp))
                val good = v.vegetationDetected && v.confidence != sg.rooted.android.model.ConfidenceLevel.LOW && !duplicate
                Column(Modifier.fillMaxWidth().background(if (good) p.green.copy(alpha = 0.08f) else p.alert.copy(alpha = 0.08f), RoundedCornerShape(16.dp)).padding(14.dp)) {
                    Text(if (good) "Evidence quality looks usable" else "Retake recommended", color = if (good) p.green else p.alert, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text(if (duplicate) "This is too close to a previous photo." else v.summary, color = p.secondary, fontSize = 12.sp)
                }
            }
            error?.let {
                Spacer(Modifier.height(10.dp))
                Text(it, color = p.alert, fontSize = 12.sp)
            }
            Spacer(Modifier.height(18.dp))
            PrimaryMissionButton(
                text = if (isRecheck) "ANALYSE RECOVERY" else "SCAN FOR CLUES",
                onClick = onScan,
                enabled = bitmap != null && verification != null,
            )
        }
    }
}

@Composable
private fun PhotoObjective(icon: String, title: String, complete: Boolean) {
    val p = LocalRootedAppearance.current.canvas
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 18.sp)
        Spacer(Modifier.width(10.dp))
        Text(title, color = p.text, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(if (complete) "FOUND ✓" else "LOOK FOR IT", color = if (complete) p.green else p.secondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ScanningMission(bitmap: Bitmap?, scanStep: Int) {
    val p = LocalRootedAppearance.current.canvas
    val transition = rememberInfiniteTransition(label = "scan")
    val scanY by transition.animateFloat(
        initialValue = 0.08f, targetValue = 0.92f,
        animationSpec = infiniteRepeatable(tween(1250, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "scanY",
    )
    val pulse by transition.animateFloat(
        initialValue = 0.96f, targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "scanPulse",
    )
    val steps = listOf("Reading leaf colour…", "Checking visible structure…", "Comparing health signals…", "Reading Singapore conditions…", "Building your clue board…")

    Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.fillMaxWidth().aspectRatio(0.86f).clip(RoundedCornerShape(28.dp)).background(p.faintFill), contentAlignment = Alignment.Center) {
            if (bitmap != null) Image(bitmap.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Canvas(Modifier.fillMaxSize()) {
                val y = size.height * scanY
                drawLine(p.green.copy(alpha = 0.95f), start = androidx.compose.ui.geometry.Offset(0f, y), end = androidx.compose.ui.geometry.Offset(size.width, y), strokeWidth = 3.dp.toPx())
                drawRect(p.green.copy(alpha = 0.08f), topLeft = androidx.compose.ui.geometry.Offset(0f, (y - 40.dp.toPx()).coerceAtLeast(0f)), size = androidx.compose.ui.geometry.Size(size.width, 80.dp.toPx()))
                listOf(0.18f to 0.24f, 0.72f to 0.34f, 0.35f to 0.70f).forEach { (x, yy) ->
                    drawCircle(p.warm, radius = 6.dp.toPx(), center = androidx.compose.ui.geometry.Offset(size.width * x, size.height * yy), style = Stroke(2.dp.toPx()))
                }
            }
        }
        Spacer(Modifier.height(22.dp))
        Text("ROOTED IS INVESTIGATING", color = p.green, fontSize = 10.sp, letterSpacing = 1.8.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(9.dp))
        Text(steps[scanStep.coerceIn(0, steps.lastIndex)], color = p.text, fontSize = 18.sp, modifier = Modifier.graphicsLayer(scaleX = pulse, scaleY = pulse))
        Spacer(Modifier.height(8.dp))
        Text("On-device evidence first. Cloud AI only enriches the read when your backend is configured.", color = p.secondary, fontSize = 12.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun CluesMission(plant: Plant?, session: DiagnosisSession?, revealed: Int, onContinue: () -> Unit) {
    val p = LocalRootedAppearance.current.canvas
    val clues = session?.clues.orEmpty()
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 24.dp), contentPadding = PaddingValues(bottom = 30.dp)) {
        item {
            Text("CASE: ${plant?.name?.uppercase() ?: "YOUR PLANT"}", color = p.secondary, fontSize = 10.sp, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(8.dp))
            Text(session?.headline ?: "Evidence collected", color = p.text, fontSize = 23.sp, fontWeight = FontWeight.Light)
            if (!session?.weatherContext.isNullOrBlank()) {
                Spacer(Modifier.height(6.dp))
                Text("Singapore clue · ${session?.weatherContext}", color = p.green, fontSize = 11.sp)
            }
            Spacer(Modifier.height(18.dp))
        }
        items(clues.size) { index ->
            AnimatedVisibility(
                visible = index < revealed,
                enter = fadeIn(tween(400)) + slideInVertically(tween(500)) { it / 3 } + scaleIn(initialScale = 0.96f),
            ) {
                ClueCard(index + 1, clues[index])
            }
            Spacer(Modifier.height(10.dp))
        }
        item {
            Spacer(Modifier.height(8.dp))
            PrimaryMissionButton("WHAT'S YOUR READ?", onContinue, enabled = clues.isNotEmpty() && revealed >= clues.size)
        }
    }
}

@Composable
private fun ClueCard(number: Int, clue: DiagnosisClue) {
    val p = LocalRootedAppearance.current.canvas
    Column(Modifier.fillMaxWidth().border(1.dp, p.rule, RoundedCornerShape(18.dp)).background(p.faintFill, RoundedCornerShape(18.dp)).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(clue.icon, fontSize = 24.sp)
            Spacer(Modifier.width(10.dp))
            Column {
                Text("CLUE #$number FOUND", color = p.warm, fontSize = 9.sp, letterSpacing = 1.3.sp, fontWeight = FontWeight.Bold)
                Text(clue.title, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(clue.detail, color = p.secondary, fontSize = 12.5.sp)
    }
}

@Composable
private fun YourReadMission(session: DiagnosisSession?, onChoose: (DiagnosisChoice) -> Unit) {
    val p = LocalRootedAppearance.current.canvas
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("YOU'VE SEEN THE EVIDENCE", color = p.warm, fontSize = 10.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("What do you think is going on?", color = p.text, fontSize = 25.sp, fontWeight = FontWeight.Light)
        Spacer(Modifier.height(6.dp))
        Text("This is a learning choice, not a medical-style diagnosis. ROOTED will still show its likely cause and guide the care plan.", color = p.secondary, fontSize = 12.5.sp)
        Spacer(Modifier.height(20.dp))
        session?.choices.orEmpty().forEachIndexed { index, choice ->
            val transition = remember { MutableTransitionState(false).apply { targetState = true } }
            AnimatedVisibility(
                visibleState = transition,
                enter = fadeIn(tween(300, delayMillis = index * 70)) + slideInVertically(tween(420, delayMillis = index * 70)) { it / 4 },
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp).border(1.dp, p.rule, RoundedCornerShape(18.dp)).clickable { onChoose(choice) }.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(choice.emoji, fontSize = 26.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(choice.label, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        if (choice.rationale.isNotBlank()) Text(choice.rationale, color = p.secondary, fontSize = 11.5.sp, maxLines = 2)
                    }
                    Text("›", color = p.green, fontSize = 25.sp)
                }
            }
        }
    }
}

@Composable
private fun VerdictMission(plant: Plant?, outcome: GardenRepository.DiagnosisChoiceOutcome?, session: DiagnosisSession?, onContinue: () -> Unit) {
    val p = LocalRootedAppearance.current.canvas
    val matched = outcome?.matched == true
    Column(Modifier.fillMaxSize().padding(26.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(28.dp))
        Box(Modifier.size(104.dp).background(if (matched) p.green.copy(alpha = 0.12f) else p.warm.copy(alpha = 0.12f), CircleShape), contentAlignment = Alignment.Center) {
            Text(if (matched) "✨" else "🔎", fontSize = 48.sp, modifier = Modifier.rootedBreathe(6f))
        }
        Spacer(Modifier.height(18.dp))
        Text(if (matched) "NICE CALL!" else "CLOSE — GOOD CLUE WORK", color = if (matched) p.green else p.warm, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
        Spacer(Modifier.height(8.dp))
        Text("ROOTED's likely cause", color = p.secondary, fontSize = 12.sp)
        Text(session?.likelyCause ?: "Still uncertain", color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Light, textAlign = TextAlign.Center)
        Spacer(Modifier.height(14.dp))
        Text("+${outcome?.xpAwarded ?: 0} XP", color = p.green, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        Column(Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(18.dp)).padding(16.dp)) {
            Text("NEXT ACTION", color = p.secondary, fontSize = 9.sp, letterSpacing = 1.3.sp)
            Spacer(Modifier.height(6.dp))
            Text(session?.nextAction.orEmpty(), color = p.text, fontSize = 13.sp)
            Spacer(Modifier.height(12.dp))
            Text("WATCH NEXT", color = p.secondary, fontSize = 9.sp, letterSpacing = 1.3.sp)
            Spacer(Modifier.height(6.dp))
            Text(session?.observeNext.orEmpty(), color = p.text, fontSize = 13.sp)
        }
        Spacer(Modifier.weight(1f))
        PrimaryMissionButton(if (outcome?.quest != null) "START TREATMENT QUEST" else "COMPLETE CHECK", onContinue)
    }
}

@Composable
private fun TreatmentMission(
    plant: Plant?, quest: Quest?, onCompleteObjective: (String, String) -> Unit, onRecheck: () -> Unit,
) {
    val p = LocalRootedAppearance.current.canvas
    val objectives = quest?.objectives.orEmpty()
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 24.dp), contentPadding = PaddingValues(bottom = 30.dp)) {
        item {
            if (!quest?.bossName.isNullOrBlank() && quest?.bossName != "Plant Rescue") {
                Row(Modifier.fillMaxWidth().background(p.alert.copy(alpha = 0.08f), RoundedCornerShape(18.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("🚨", fontSize = 25.sp)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("BOSS EVENT", color = p.alert, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                        Text(quest?.bossName.orEmpty(), color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                    }
                }
                Spacer(Modifier.height(14.dp))
            }
            Text(quest?.title ?: "Treatment Quest", color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Light)
            Spacer(Modifier.height(6.dp))
            Text("${objectives.count { it.isComplete }}/${objectives.size} objectives complete · +25 XP each", color = p.secondary, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            GreenBar(if (objectives.isEmpty()) 0.0 else objectives.count { it.isComplete }.toDouble() / objectives.size)
            Spacer(Modifier.height(16.dp))
        }
        items(objectives.size) { index ->
            val objective = objectives[index]
            ObjectiveCard(index + 1, objective) {
                if (quest != null && !objective.isComplete) onCompleteObjective(quest.id, objective.id)
            }
            Spacer(Modifier.height(10.dp))
        }
        item {
            Spacer(Modifier.height(10.dp))
            if (objectives.isNotEmpty() && objectives.all { it.isComplete }) {
                PrimaryMissionButton("CARE PLAN DONE · PREPARE RECHECK", onRecheck)
            } else {
                Text("Complete each real-world care step. ROOTED will only pay the rescue reward after a later photo shows improvement.", color = p.secondary, fontSize = 11.5.sp, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun ObjectiveCard(number: Int, objective: QuestObjective, onDone: () -> Unit) {
    val p = LocalRootedAppearance.current.canvas
    val completeColor by animateColorAsState(if (objective.isComplete) p.green.copy(alpha = 0.10f) else p.faintFill, label = "objectiveColor")
    Row(
        Modifier.fillMaxWidth().background(completeColor, RoundedCornerShape(18.dp)).border(1.dp, if (objective.isComplete) p.green.copy(alpha = 0.25f) else p.rule, RoundedCornerShape(18.dp)).clickable(enabled = !objective.isComplete, onClick = onDone).padding(15.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Box(Modifier.size(34.dp).background(if (objective.isComplete) p.green else p.rule.copy(alpha = 0.35f), CircleShape), contentAlignment = Alignment.Center) {
            Text(if (objective.isComplete) "✓" else "$number", color = if (objective.isComplete) p.onAccent else p.text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("${objective.icon} ${objective.title}", color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            if (objective.detail.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(objective.detail, color = p.secondary, fontSize = 11.5.sp)
            }
            if (!objective.isComplete) {
                Spacer(Modifier.height(7.dp))
                Text("TAP WHEN DONE · +25 XP", color = p.green, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun RecheckReadyMission(plant: Plant?, quest: Quest?, onStart: () -> Unit) {
    val p = LocalRootedAppearance.current.canvas
    val baseline = quest?.baselineHealthScore ?: plant?.rescueBaselineHealthScore
    Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(28.dp))
        Text("🌱", fontSize = 74.sp, modifier = Modifier.rootedBreathe(9f))
        Spacer(Modifier.height(18.dp))
        Text("Treatment complete", color = p.green, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
        Spacer(Modifier.height(8.dp))
        Text("Now prove the recovery", color = p.text, fontSize = 25.sp, fontWeight = FontWeight.Light, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text("ROOTED will compare a fresh verified photo against ${plant?.name ?: "your plant"}'s rescue baseline${baseline?.let { " of $it/100" } ?: ""}.", color = p.secondary, fontSize = 13.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        RecoveryLadder(baseline ?: 50, plant?.healthScore ?: baseline ?: 50)
        Spacer(Modifier.weight(1f))
        PrimaryMissionButton("TAKE RECHECK PHOTO", onStart)
    }
}

@Composable
private fun MissionResult(
    plant: Plant?, outcome: GardenRepository.CheckInOutcome?, session: DiagnosisSession?, rescueQuest: Quest?, onRetake: () -> Unit, onDone: () -> Unit,
) {
    val p = LocalRootedAppearance.current.canvas
    val verified = outcome?.verified == true
    val score = outcome?.checkIn?.healthScoreAtCheckIn ?: plant?.healthScore ?: 0
    val baseline = rescueQuest?.baselineHealthScore ?: session?.baselineHealthScore
    val rescueComplete = rescueQuest?.status == QuestStatus.COMPLETED || (baseline != null && score >= baseline + 8)
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 26.dp), contentPadding = PaddingValues(bottom = 32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        item {
            Spacer(Modifier.height(18.dp))
            Box(Modifier.size(112.dp).background((if (verified) p.green else p.alert).copy(alpha = 0.10f), CircleShape), contentAlignment = Alignment.Center) {
                Text(if (rescueComplete) "🏆" else if (verified) "🌿" else "📸", fontSize = 48.sp, modifier = Modifier.rootedBreathe(5f))
            }
            Spacer(Modifier.height(16.dp))
            Text(
                when {
                    !verified -> "We need a better photo"
                    rescueComplete -> "PLANT RESCUE COMPLETE"
                    else -> "CHECK-IN VERIFIED"
                },
                color = if (verified) p.green else p.alert, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                when {
                    !verified -> "No health or streak penalty applied"
                    rescueComplete && baseline != null -> "You brought ${plant?.name ?: "your plant"} from $baseline → $score health"
                    else -> "${plant?.name ?: "Your plant"} is at $score/100 health"
                },
                color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Light, textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(8.dp))
            Text(outcome?.checkIn?.note.orEmpty(), color = p.secondary, fontSize = 12.5.sp, textAlign = TextAlign.Center)
            if (verified) {
                Spacer(Modifier.height(18.dp))
                RecoveryLadder(baseline ?: score, score)
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricTile("+${outcome?.checkIn?.daysAwarded ?: 0}", "PLANT-DAY", Modifier.weight(1f))
                    MetricTile("+${outcome?.xpGained ?: 0}", "CHECK-IN XP", Modifier.weight(1f))
                    MetricTile("$score", "HEALTH", Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(22.dp))
            if (!verified) PrimaryMissionButton("RETAKE PHOTO", onRetake) else PrimaryMissionButton("BACK TO GREENHOUSE", onDone)
        }
    }
}

@Composable
private fun RecoveryLadder(baseline: Int, current: Int) {
    val p = LocalRootedAppearance.current.canvas
    val labels = listOf("CRITICAL" to 25, "STRUGGLING" to 45, "RECOVERING" to 65, "HEALTHY" to 80, "THRIVING" to 92)
    Column(Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(18.dp)).padding(15.dp)) {
        Text("RECOVERY JOURNEY", color = p.secondary, fontSize = 9.sp, letterSpacing = 1.3.sp)
        Spacer(Modifier.height(10.dp))
        labels.forEach { (label, threshold) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).background(if (current >= threshold) p.green else p.rule, CircleShape))
                Spacer(Modifier.width(9.dp))
                Text(label, color = if (current >= threshold) p.text else p.secondary, fontSize = 10.sp, modifier = Modifier.weight(1f))
                when {
                    current >= threshold && baseline < threshold -> Text("UNLOCKED", color = p.green, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    current >= threshold -> Text("✓", color = p.green, fontSize = 10.sp)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Baseline $baseline  →  Current $current", color = p.green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun MetricTile(value: String, label: String, modifier: Modifier = Modifier) {
    val p = LocalRootedAppearance.current.canvas
    Column(modifier.background(p.faintFill, RoundedCornerShape(14.dp)).padding(vertical = 13.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(label, color = p.secondary, fontSize = 8.sp, letterSpacing = 0.6.sp)
    }
}

@Composable
private fun PrimaryMissionButton(text: String, onClick: () -> Unit, enabled: Boolean = true) {
    val p = LocalRootedAppearance.current.canvas
    Button(
        onClick = onClick,
        enabled = enabled,
        colors = ButtonDefaults.buttonColors(containerColor = p.green, contentColor = p.onAccent, disabledContainerColor = p.rule, disabledContentColor = p.secondary),
        shape = RoundedCornerShape(RootedMetrics.buttonRadius.dp),
        modifier = Modifier.fillMaxWidth().height(54.dp),
    ) { Text(text, fontSize = 12.sp, letterSpacing = 0.8.sp, fontWeight = FontWeight.Bold) }
}
