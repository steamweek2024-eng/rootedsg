package sg.rooted.android.ui.garden

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import sg.rooted.android.RootedViewModel
import sg.rooted.android.engine.GameEngine
import sg.rooted.android.model.HealthStatus
import sg.rooted.android.model.Plant
import sg.rooted.android.model.QuestStatus
import sg.rooted.android.model.QuestType
import sg.rooted.android.ui.common.PlantCharacterView
import sg.rooted.android.ui.common.RootedAmbientField
import sg.rooted.android.ui.common.rootedBreathe
import sg.rooted.android.ui.common.rootedPressable
import sg.rooted.android.ui.pet.WalkTarget
import sg.rooted.android.ui.pet.walkAnchor
import sg.rooted.android.ui.theme.LocalRootedAppearance
import sg.rooted.android.ui.theme.RisesIn
import sg.rooted.android.ui.theme.RootedMetrics

private enum class GardenFilter(val label: String) { ALL("All"), THRIVING("Thriving"), RESCUE("Rescue"), DUE("Due") }

@Composable
fun GardenScreen(viewModel: RootedViewModel, onOpenPlant: (String) -> Unit, onRegister: () -> Unit) {
    val appearance = LocalRootedAppearance.current
    val p = appearance.canvas
    val plants by viewModel.plants.collectAsState()
    val quests by viewModel.quests.collectAsState()
    val user by viewModel.user.collectAsState()
    var filter by remember { mutableStateOf(GardenFilter.ALL) }

    if (plants.isEmpty()) {
        RootedAmbientField(Modifier.fillMaxSize().padding((RootedMetrics.pagePadding + 8).dp), p.green) {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text("🌱", fontSize = 76.sp, modifier = Modifier.rootedBreathe(9f))
                Spacer(Modifier.height(16.dp))
                Text("Your greenhouse is waiting.", color = p.text, fontSize = 29.sp, fontWeight = FontWeight.Light, textAlign = TextAlign.Center)
                Spacer(Modifier.height(8.dp))
                Text("Register a real plant. Its in-app character will grow as your verified care history grows.", color = p.secondary, fontSize = 14.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(24.dp))
                Button(onClick = onRegister, colors = ButtonDefaults.buttonColors(containerColor = p.green, contentColor = p.onAccent), shape = RoundedCornerShape(RootedMetrics.buttonRadius.dp)) {
                    Text("PLANT YOUR FIRST SPROUT")
                }
            }
        }
        return
    }

    val active = plants.filter { it.health != HealthStatus.DECEASED }
    val rescuePlantIds = quests.filter { it.type == QuestType.RECOVERY && it.status == QuestStatus.ACTIVE }.mapNotNull { it.relatedPlantID }.toSet()
    val shown = active.filter { plant ->
        when (filter) {
            GardenFilter.ALL -> true
            GardenFilter.THRIVING -> plant.healthScore >= 80
            GardenFilter.RESCUE -> plant.id in rescuePlantIds || plant.healthScore < 80
            GardenFilter.DUE -> plant.isCheckInDue()
        }
    }.sortedWith(compareBy<Plant> { it.id !in rescuePlantIds }.thenByDescending { it.healthScore })

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 18.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 120.dp),
    ) {
        item {
            RisesIn(index = 0) { m ->
                Column(m.walkAnchor(WalkTarget.SCREEN_HERO)) {
                    GuardianHeader(
                        level = user?.level ?: 1,
                        xp = user?.xp ?: 0,
                        plants = active.size,
                        thriving = active.count { it.healthScore >= 80 },
                        rescues = rescuePlantIds.size,
                    )
                    Spacer(Modifier.height(18.dp))
                    FilterStrip(filter) { filter = it }
                    Spacer(Modifier.height(18.dp))
                    Text("MY GREENHOUSE", color = p.secondary, fontSize = 10.sp, letterSpacing = 1.8.sp)
                    Spacer(Modifier.height(7.dp))
                    Text("Tap a plant to enter its world.", color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Light)
                    Spacer(Modifier.height(12.dp))
                }
            }
        }

        if (shown.isEmpty()) {
            item {
                Text("Nothing in this greenhouse view yet.", color = p.secondary, fontSize = 14.sp, modifier = Modifier.padding(vertical = 20.dp))
            }
        } else {
            val rows = shown.chunked(2)
            rows.forEachIndexed { rowIndex, row ->
                item(key = "shelf-$rowIndex") {
                    AnimatedVisibility(
                        visible = true,
                        enter = fadeIn() + slideInVertically { it / 5 },
                    ) {
                        GreenhouseShelf(
                            plants = row,
                            rescueIds = rescuePlantIds,
                            potSkin = user?.equippedPotSkin,
                            onOpenPlant = onOpenPlant,
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                }
            }
        }

        item {
            Spacer(Modifier.height(8.dp))
            GreenhouseZones(level = user?.level ?: 1)
            Spacer(Modifier.height(18.dp))
            Button(
                onClick = onRegister,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = p.text, contentColor = appearance.ground),
                shape = RoundedCornerShape(RootedMetrics.buttonRadius.dp),
            ) { Text("ADD ANOTHER REAL PLANT", fontSize = 11.sp, letterSpacing = 0.7.sp) }
        }
    }
}

@Composable
private fun GuardianHeader(level: Int, xp: Int, plants: Int, thriving: Int, rescues: Int) {
    val p = LocalRootedAppearance.current.canvas
    val progress = GameEngine.xpProgress(xp)
    val fraction = if (progress.second <= 0) 0f else (progress.first.toFloat() / progress.second).coerceIn(0f, 1f)
    val animated by animateFloatAsState(fraction, label = "guardianXp")
    Column(Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(24.dp)).padding(17.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).background(p.green.copy(alpha = 0.14f), CircleShape), contentAlignment = Alignment.Center) {
                Text("🌿", fontSize = 25.sp, modifier = Modifier.rootedBreathe(4f))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("LEVEL $level PLANT GUARDIAN", color = p.green, fontSize = 10.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
                Text("Your real garden powers this world", color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Light)
            }
        }
        Spacer(Modifier.height(13.dp))
        Box(Modifier.fillMaxWidth().height(7.dp).background(p.rule, CircleShape)) {
            Box(Modifier.fillMaxWidth(animated).fillMaxHeight().background(p.green, CircleShape))
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TinyStat("🌱", plants.toString(), "plants")
            TinyStat("❤️", thriving.toString(), "thriving")
            TinyStat("🕵️", rescues.toString(), "rescues")
            TinyStat("✨", xp.toString(), "XP")
        }
    }
}

@Composable
private fun TinyStat(icon: String, value: String, label: String) {
    val p = LocalRootedAppearance.current.canvas
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 12.sp)
        Spacer(Modifier.width(3.dp))
        Column {
            Text(value, color = p.text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(label.uppercase(), color = p.secondary, fontSize = 7.sp, letterSpacing = 0.5.sp)
        }
    }
}

@Composable
private fun FilterStrip(selected: GardenFilter, onSelect: (GardenFilter) -> Unit) {
    val p = LocalRootedAppearance.current.canvas
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        GardenFilter.entries.forEach { filter ->
            val active = filter == selected
            Text(
                filter.label.uppercase(), color = if (active) p.onAccent else p.secondary, fontSize = 8.5.sp, letterSpacing = 0.8.sp,
                modifier = Modifier
                    .background(if (active) p.green else Color.Transparent, RoundedCornerShape(20.dp))
                    .border(if (active) 0.dp else 1.dp, p.rule, RoundedCornerShape(20.dp))
                    .rootedPressable(haptic = false) { onSelect(filter) }
                    .padding(horizontal = 10.dp, vertical = 7.dp),
            )
        }
    }
}

@Composable
private fun GreenhouseShelf(
    plants: List<Plant>, rescueIds: Set<String>, potSkin: sg.rooted.android.engine.ShopItem?, onOpenPlant: (String) -> Unit,
) {
    val p = LocalRootedAppearance.current.canvas
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Bottom) {
            plants.forEach { plant ->
                PlantWorldCard(plant, plant.id in rescueIds, potSkin, Modifier.weight(1f)) { onOpenPlant(plant.id) }
            }
            if (plants.size == 1) Spacer(Modifier.weight(1f))
        }
        Spacer(Modifier.height(3.dp))
        Canvas(Modifier.fillMaxWidth().height(12.dp)) {
            drawRoundRect(p.rule.copy(alpha = 0.65f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f))
        }
    }
}

@Composable
private fun PlantWorldCard(
    plant: Plant, rescue: Boolean, potSkin: sg.rooted.android.engine.ShopItem?, modifier: Modifier = Modifier, onClick: () -> Unit,
) {
    val p = LocalRootedAppearance.current.canvas
    Column(
        modifier
            .background(if (rescue) p.alert.copy(alpha = 0.06f) else p.faintFill, RoundedCornerShape(22.dp))
            .border(1.dp, if (rescue) p.alert.copy(alpha = 0.25f) else p.rule, RoundedCornerShape(22.dp))
            .rootedPressable(haptic = false, onClick = onClick)
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.fillMaxWidth().height(116.dp), contentAlignment = Alignment.BottomCenter) {
            PlantCharacterView(
                stage = plant.stage, health = plant.health, growth = plant.progressToNextStage, streak = plant.careStreak,
                animated = true, glossy = true, potSkin = potSkin,
                modifier = Modifier.size(108.dp),
            )
            if (rescue) {
                Text("🚨 QUEST", color = p.alert, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.TopEnd).background(p.alert.copy(alpha = 0.09f), RoundedCornerShape(12.dp)).padding(horizontal = 7.dp, vertical = 4.dp))
            }
        }
        Text(plant.name, color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Medium, maxLines = 1)
        Text("${plant.stage.displayName} · Lv.${plant.stage.order + 1}", color = p.secondary, fontSize = 9.sp)
        Spacer(Modifier.height(7.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("❤️ ${plant.healthScore}", color = if (plant.healthScore >= 80) p.green else if (plant.healthScore >= 60) p.warm else p.alert, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(7.dp))
            Text(moodFor(plant), color = p.secondary, fontSize = 9.sp)
        }
        Spacer(Modifier.height(5.dp))
        Text(personalityLine(plant), color = p.secondary, fontSize = 9.5.sp, textAlign = TextAlign.Center, maxLines = 2)
    }
}

private fun moodFor(plant: Plant): String = when {
    plant.healthScore >= 90 -> "😊 Flourishing"
    plant.healthScore >= 80 -> "🙂 Happy"
    plant.healthScore >= 65 -> "😌 Recovering"
    plant.healthScore >= 45 -> "😟 Worried"
    else -> "🆘 Needs you"
}

private fun personalityLine(plant: Plant): String = when {
    plant.careStreak >= 10 -> "“We’re on a roll. Don’t break our rhythm.”"
    plant.healthScore < 60 -> "“Something feels off. Can we investigate?”"
    plant.stage.order >= 3 -> "“I’ve seen a lot. Keep me growing.”"
    plant.verifiedPlantDays <= 7 -> "“Still getting settled in my new home.”"
    else -> "“I’m stronger than I was when we started.”"
}

@Composable
private fun GreenhouseZones(level: Int) {
    val p = LocalRootedAppearance.current.canvas
    val zones = listOf(
        Triple(8, "SUN ROOM", "☀️"),
        Triple(15, "RAINFOREST WALL", "🌧️"),
        Triple(25, "LEGACY CONSERVATORY", "✨"),
    )
    Column(Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(22.dp)).padding(15.dp)) {
        Text("GREENHOUSE EXPANSION", color = p.secondary, fontSize = 9.sp, letterSpacing = 1.3.sp)
        Spacer(Modifier.height(10.dp))
        zones.forEach { (required, label, icon) ->
            val unlocked = level >= required
            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(35.dp).background(if (unlocked) p.green.copy(alpha = 0.12f) else p.rule.copy(alpha = 0.3f), CircleShape), contentAlignment = Alignment.Center) {
                    Text(if (unlocked) icon else "🔒", fontSize = 17.sp)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(label, color = if (unlocked) p.text else p.secondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(if (unlocked) "Unlocked" else "Unlocks at Guardian Level $required", color = if (unlocked) p.green else p.secondary, fontSize = 9.sp)
                }
            }
        }
    }
}
