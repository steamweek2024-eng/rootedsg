package sg.rooted.android.ui.garden

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import sg.rooted.android.RootedViewModel
import sg.rooted.android.model.CheckIn
import sg.rooted.android.model.DiagnosisSession
import sg.rooted.android.model.DiagnosisStatus
import sg.rooted.android.model.HealthStatus
import sg.rooted.android.model.PlantStage
import sg.rooted.android.ui.common.PlantCharacterView
import sg.rooted.android.ui.common.RootedPhoto
import sg.rooted.android.ui.common.SheetHeader
import sg.rooted.android.ui.common.noRippleClickable
import sg.rooted.android.ui.common.rootedBreathe
import sg.rooted.android.ui.theme.GreenBar
import sg.rooted.android.ui.theme.LocalRootedAppearance
import sg.rooted.android.ui.theme.RootedBackground
import sg.rooted.android.ui.theme.RootedMetrics
import sg.rooted.android.ui.theme.RootedSurface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PlantDetailScreen(viewModel: RootedViewModel, plantId: String, onClose: () -> Unit, onCheckIn: () -> Unit) {
    val appearance = LocalRootedAppearance.current
    val p = appearance.canvas
    val plant by remember(plantId) { viewModel.garden.observePlant(plantId) }.collectAsState(initial = null)
    val checkIns by remember(plantId) { viewModel.garden.observeCheckIns(plantId) }.collectAsState(initial = emptyList())
    val diagnosisSessions by remember(plantId) { viewModel.garden.observeDiagnosisSessions(plantId) }.collectAsState(initial = emptyList())
    val user by viewModel.user.collectAsState()
    val dateFormat = remember { SimpleDateFormat("d MMM", Locale.getDefault()) }
    val scope = rememberCoroutineScope()

    var showMenu by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showNotesEditor by remember { mutableStateOf(false) }
    var noteDraft by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().background(appearance.ground).safeDrawingPadding()) {
        val current = plant
        if (current == null) {
            SheetHeader(title = "Plant", onClose = onClose)
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("This plant isn't available.", color = p.secondary, fontSize = 14.sp)
            }
            return@Column
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = (RootedMetrics.pagePadding + 8).dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("‹ Back", color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Medium, modifier = Modifier.noRippleClickable { onClose() })
            Spacer(Modifier.weight(1f))
            Box {
                Box(
                    Modifier.size(36.dp).background(p.faintFill, CircleShape).noRippleClickable { showMenu = true },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.MoreVert, contentDescription = "More", tint = p.text) }
                DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                    DropdownMenuItem(text = { Text("Edit notes") }, onClick = { showMenu = false; noteDraft = current.notes; showNotesEditor = true })
                    DropdownMenuItem(text = { Text("Remove plant") }, onClick = { showMenu = false; showDeleteConfirm = true })
                }
            }
        }

        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = (RootedMetrics.pagePadding + 8).dp),
            contentPadding = PaddingValues(bottom = 120.dp),
        ) {
            item {
                Text(
                    "For you, since ${SimpleDateFormat("MMM yyyy", Locale.getDefault()).format(Date(current.registeredDate))}",
                    color = p.secondary, fontSize = 12.sp,
                    modifier = Modifier.background(p.faintFill, RoundedCornerShape(50)).padding(horizontal = 12.dp, vertical = 6.dp),
                )
                Spacer(Modifier.height(16.dp))

                Box(
                    Modifier.fillMaxWidth().height(240.dp).background(healthTint(current.health, p).copy(alpha = 0.85f), RoundedCornerShape(RootedMetrics.heroRadius.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    PlantCharacterView(
                        stage = current.stage, health = current.health, growth = current.progressToNextStage,
                        streak = current.careStreak, onDark = true, potSkin = user?.equippedPotSkin,
                        modifier = Modifier.height(210.dp).fillMaxWidth().rootedBreathe(5f),
                    )
                }
                Spacer(Modifier.height(16.dp))

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    Text("✓ ", color = p.green, fontSize = 12.sp)
                    Text(
                        "${checkIns.count { it.verified }} verified check-ins · ${current.stage.displayName}",
                        color = p.secondary, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                    )
                }
                Spacer(Modifier.height(14.dp))

                Text(
                    current.name, color = p.text, fontSize = 32.sp, fontWeight = FontWeight.Light,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "${current.species}. Kept alive for ${current.verifiedPlantDays} verified Plant-Days, ${current.stage.unlockDescription.lowercase()}",
                    color = p.secondary, fontSize = 14.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(18.dp))

                Button(
                    onClick = onCheckIn,
                    colors = ButtonDefaults.buttonColors(containerColor = p.green, contentColor = p.onAccent),
                    shape = RoundedCornerShape(RootedMetrics.buttonRadius.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                ) { Text(if (current.isCheckInDue()) "Check in now" else "Check in ${current.name}", fontWeight = FontWeight.Medium) }
                Spacer(Modifier.height(20.dp))

                // Stats card
                Column(Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(RootedMetrics.cardRadius.dp)).padding(18.dp)) {
                    Row(Modifier.fillMaxWidth()) {
                        StatFigure("${current.verifiedPlantDays}", "Plant-Days", p.warm, Modifier.weight(1f))
                        Box(Modifier.width(1.dp).height(36.dp).background(p.rule))
                        StatFigure("${current.careStreak}", "Care streak", p.green, Modifier.weight(1f))
                        Box(Modifier.width(1.dp).height(36.dp).background(p.rule))
                        StatFigure("${current.healthScore}", "Health", if (current.healthScore >= 80) p.green else if (current.healthScore >= 60) p.warm else p.alert, Modifier.weight(1f))
                    }
                    current.nextStage?.let { next ->
                        Spacer(Modifier.height(16.dp))
                        Row(Modifier.fillMaxWidth()) {
                            Text("Next: ${next.displayName}", color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                            Text("${current.daysToNextStage} days to go", color = p.secondary, fontSize = 13.sp)
                        }
                        Spacer(Modifier.height(8.dp))
                        GreenBar(fraction = current.progressToNextStage, surface = RootedSurface.CANVAS)
                    }
                }
                Spacer(Modifier.height(24.dp))

                HealthJourneyCard(current.healthScore, current.rescueBaselineHealthScore, diagnosisSessions)
                Spacer(Modifier.height(24.dp))

                // Stage journey
                Text("GROWTH STAGES", color = p.secondary, fontSize = 10.sp, letterSpacing = 1.6.sp)
                Spacer(Modifier.height(12.dp))
                PlantStage.ordered.forEach { stage ->
                    val reached = current.stage.order >= stage.order
                    val isCurrent = stage == current.stage
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .background(if (isCurrent) p.warm.copy(alpha = 0.12f) else p.faintFill, RoundedCornerShape(RootedMetrics.smallRadius.dp))
                            .padding(13.dp)
                            .padding(bottom = 0.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.size(18.dp), contentAlignment = Alignment.Center) {
                            when {
                                reached && !isCurrent -> Text("✓", color = p.green, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                isCurrent -> Canvas(Modifier.size(16.dp)) { drawCircle(color = p.text.copy(alpha = 0.35f), style = Stroke(width = 1.5.dp.toPx())) }
                                else -> Canvas(Modifier.size(16.dp)) { drawCircle(color = p.text.copy(alpha = 0.15f), style = Stroke(width = 1.5.dp.toPx())) }
                            }
                        }
                        Spacer(Modifier.width(13.dp))
                        Column {
                            Text(stage.displayName, color = if (reached) p.text else p.secondary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                            Text(stage.unlockDescription, color = p.secondary, fontSize = 12.sp)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }

                if (current.notes.isNotBlank()) {
                    Spacer(Modifier.height(14.dp))
                    Text("NOTES", color = p.secondary, fontSize = 10.sp, letterSpacing = 1.6.sp)
                    Spacer(Modifier.height(10.dp))
                    Text(
                        current.notes, color = p.text, fontSize = 14.sp,
                        modifier = Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(RootedMetrics.cardRadius.dp)).padding(16.dp),
                    )
                }

                Spacer(Modifier.height(24.dp))
                Text("CHECK-IN HISTORY · ${checkIns.size} TOTAL", color = p.secondary, fontSize = 10.sp, letterSpacing = 1.2.sp)
                Spacer(Modifier.height(12.dp))

                if (checkIns.isEmpty()) {
                    Text("No check-ins yet. Photograph ${current.name} to log the first verified day.", color = p.secondary, fontSize = 13.sp)
                } else {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                        items(checkIns.sortedByDescending { it.date }, key = { it.id }) { checkIn ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(Modifier.alpha(if (checkIn.verified) 1f else 0.5f)) {
                                    RootedPhoto(
                                        filename = checkIn.imageFilename, placeholderEmoji = current.speciesEmoji, placeholderTint = p.faintFill,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.size(82.dp).clip(RoundedCornerShape(14.dp)),
                                    )
                                    Box(
                                        Modifier.align(Alignment.BottomEnd).padding(4.dp).size(18.dp)
                                            .background(if (checkIn.verified) p.green else p.alert, CircleShape),
                                        contentAlignment = Alignment.Center,
                                    ) { Text(if (checkIn.verified) "✓" else "✕", color = androidx.compose.ui.graphics.Color.White, fontSize = 10.sp) }
                                }
                                Spacer(Modifier.height(6.dp))
                                Text(dateFormat.format(Date(checkIn.date)), color = p.secondary, fontSize = 11.sp)
                                if (checkIn.daysAwarded > 0) {
                                    Text("+${checkIn.daysAwarded}d", color = p.green, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                                }
                            }
                        }
                    }

                    if (checkIns.size >= 2) {
                        Spacer(Modifier.height(12.dp))
                        GreenTrendChart(checkIns.sortedBy { it.date }, p.green, modifier = Modifier.fillMaxWidth().height(62.dp))
                    }
                }
            }
        }
    }

    if (showDeleteConfirm) {
        plant?.let { current ->
            AlertDialog(
                onDismissRequest = { showDeleteConfirm = false },
                confirmButton = {
                    TextButton(onClick = {
                        showDeleteConfirm = false
                        scope.launch { viewModel.garden.deletePlant(current); onClose() }
                    }) { Text("Remove") }
                },
                dismissButton = { TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") } },
                title = { Text("Remove ${current.name}?") },
                text = { Text("This deletes the plant, its photos and its check-in history from this device. Its Verified Plant-Days will no longer be counted.") },
            )
        }
    }

    if (showNotesEditor) {
        plant?.let { current ->
            AlertDialog(
                onDismissRequest = { showNotesEditor = false },
                confirmButton = {
                    TextButton(onClick = {
                        showNotesEditor = false
                        scope.launch { viewModel.garden.updatePlantNotes(current, noteDraft) }
                    }) { Text("Save") }
                },
                dismissButton = { TextButton(onClick = { showNotesEditor = false }) { Text("Cancel") } },
                title = { Text("Notes") },
                text = {
                    OutlinedTextField(value = noteDraft, onValueChange = { noteDraft = it }, modifier = Modifier.fillMaxWidth())
                },
            )
        }
    }
}

@Composable
private fun HealthJourneyCard(score: Int, rescueBaseline: Int?, sessions: List<DiagnosisSession>) {
    val p = LocalRootedAppearance.current.canvas
    val animated by animateFloatAsState(score.coerceIn(0, 100) / 100f, tween(700), label = "healthJourney")
    val latest = sessions.firstOrNull()
    val activeRescue = latest?.status == DiagnosisStatus.TREATMENT || latest?.status == DiagnosisStatus.RECHECK
    Column(Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(RootedMetrics.cardRadius.dp)).padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("RECOVERY JOURNEY", color = p.green, fontSize = 9.5.sp, letterSpacing = 1.6.sp, fontWeight = FontWeight.Bold)
                Text(healthJourneyLabel(score), color = p.text, fontSize = 21.sp, fontWeight = FontWeight.Light)
            }
            Text("❤ $score", color = if (score >= 80) p.green else if (score >= 60) p.warm else p.alert, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth().height(8.dp).background(p.rule, RoundedCornerShape(99.dp))) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(animated).background(if (score >= 80) p.green else if (score >= 60) p.warm else p.alert, RoundedCornerShape(99.dp)))
        }
        Spacer(Modifier.height(12.dp))
        val rungs = listOf("CRITICAL" to 20, "STRUGGLING" to 45, "RECOVERING" to 65, "HEALTHY" to 80, "THRIVING" to 90)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            rungs.forEach { (label, threshold) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(56.dp)) {
                    Box(Modifier.size(8.dp).background(if (score >= threshold) p.green else p.rule, CircleShape))
                    Spacer(Modifier.height(4.dp))
                    Text(label, color = if (score >= threshold) p.text else p.secondary, fontSize = 6.8.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center, maxLines = 1)
                }
            }
        }
        if (rescueBaseline != null) {
            Spacer(Modifier.height(12.dp))
            Text("Rescue started at $rescueBaseline → now $score (${if (score >= rescueBaseline) "+" else ""}${score - rescueBaseline})", color = if (score > rescueBaseline) p.green else p.secondary, fontSize = 11.5.sp, fontWeight = FontWeight.Medium)
        } else if (latest?.baselineHealthScore != null && latest.recheckHealthScore != null) {
            Spacer(Modifier.height(12.dp))
            Text("Last rescue: ${latest.baselineHealthScore} → ${latest.recheckHealthScore} · verified recovery", color = p.green, fontSize = 11.5.sp, fontWeight = FontWeight.Medium)
        } else if (activeRescue) {
            Spacer(Modifier.height(12.dp))
            Text("A rescue mission is active. Complete treatment objectives, then recheck with a fresh photo.", color = p.warm, fontSize = 11.5.sp)
        }
    }
}

private fun healthJourneyLabel(score: Int): String = when {
    score >= 90 -> "Thriving 🌟"
    score >= 80 -> "Healthy 🟢"
    score >= 65 -> "Recovering 🟡"
    score >= 45 -> "Struggling 🟠"
    else -> "Critical 🔴"
}

@Composable
private fun healthTint(health: HealthStatus, p: sg.rooted.android.ui.theme.RootedPalette) = when (health) {
    HealthStatus.HEALTHY -> p.green
    HealthStatus.RECOVERING -> p.green
    HealthStatus.STRUGGLING, HealthStatus.AT_RISK -> p.alert
    HealthStatus.DECEASED -> p.secondary
}

@Composable
private fun StatFigure(value: String, label: String, tint: androidx.compose.ui.graphics.Color, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = tint, fontSize = 24.sp, fontWeight = FontWeight.Light)
        Text(label.uppercase(), color = LocalRootedAppearance.current.canvas.secondary, fontSize = 9.sp, letterSpacing = 0.8.sp)
    }
}

@Composable
private fun GreenTrendChart(checkIns: List<CheckIn>, tint: androidx.compose.ui.graphics.Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val values = checkIns.map { it.greenRatio }
        if (values.isEmpty()) return@Canvas
        val maxV = (values.maxOrNull() ?: 0.01).coerceAtLeast(0.01)
        val stepX = if (values.size > 1) size.width / (values.size - 1) else size.width

        val area = Path().apply {
            moveTo(0f, size.height)
            values.forEachIndexed { i, v ->
                val y = size.height - (v / maxV).toFloat() * size.height * 0.85f
                lineTo(i * stepX, y)
            }
            lineTo((values.size - 1) * stepX, size.height)
            close()
        }
        drawPath(area, color = tint.copy(alpha = 0.18f))

        val line = Path().apply {
            values.forEachIndexed { i, v ->
                val y = size.height - (v / maxV).toFloat() * size.height * 0.85f
                val x = i * stepX
                if (i == 0) moveTo(x, y) else lineTo(x, y)
            }
        }
        drawPath(line, color = tint, style = Stroke(width = 2.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round))
    }
}
