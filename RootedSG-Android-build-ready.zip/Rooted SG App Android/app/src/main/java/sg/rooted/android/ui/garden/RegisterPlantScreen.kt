package sg.rooted.android.ui.garden

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import sg.rooted.android.RootedViewModel
import sg.rooted.android.engine.GameEngine
import sg.rooted.android.engine.SpeciesCatalog
import sg.rooted.android.engine.SpeciesEntry
import sg.rooted.android.engine.VisionService
import sg.rooted.android.model.ConfidenceLevel
import sg.rooted.android.model.Plant
import sg.rooted.android.ui.common.CelebrationKind
import sg.rooted.android.ui.common.CelebrationOverlay
import sg.rooted.android.ui.common.CelebrationPayload
import sg.rooted.android.ui.common.SheetHeader
import sg.rooted.android.ui.common.noRippleClickable
import sg.rooted.android.ui.common.rememberPhotoCapturePicker
import sg.rooted.android.ui.common.rootedPressable
import sg.rooted.android.ui.theme.LocalRootedAppearance
import sg.rooted.android.ui.theme.RootedBackground
import sg.rooted.android.ui.theme.RootedCard
import sg.rooted.android.ui.theme.RootedMetrics

@Composable
fun RegisterPlantScreen(viewModel: RootedViewModel, onClose: () -> Unit) {
    val appearance = LocalRootedAppearance.current
    val p = appearance.canvas
    val user by viewModel.user.collectAsState()
    val photo = rememberPhotoCapturePicker()
    val scope = rememberCoroutineScope()

    var name by remember { mutableStateOf("") }
    var species by remember { mutableStateOf<SpeciesEntry?>(null) }
    var showSpeciesPicker by remember { mutableStateOf(false) }
    var isSaving by remember { mutableStateOf(false) }
    var analysing by remember { mutableStateOf(false) }
    var verification by remember { mutableStateOf<VisionService.VerificationResult?>(null) }
    var duplicateName by remember { mutableStateOf<String?>(null) }
    var registered by remember { mutableStateOf<Plant?>(null) }
    val notificationPermission = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission(),
    ) { }

    val canSubmit = photo.bitmap != null && species != null && duplicateName == null && name.isNotBlank()

    fun analyse(bitmap: android.graphics.Bitmap) {
        analysing = true
        species = null
        verification = null
        duplicateName = null
        scope.launch {
            val currentUser = user
            val duplicate = if (currentUser != null) viewModel.garden.duplicatePlant(currentUser, bitmap) else null
            verification = VisionService.verifyVegetation(bitmap)
            duplicateName = duplicate?.name
            analysing = false
            // No on-device species classifier and no cloud opt-in surfaced yet on this
            // platform — land in the same "couldn't confidently identify" manual state
            // iOS shows by default until a user opts into cloud analysis.
        }
    }

    Column(Modifier.fillMaxSize().background(appearance.ground).safeDrawingPadding()) {
        SheetHeader(title = "Enter a specimen", onClose = onClose)

        Box(Modifier.weight(1f)) {
            LazyColumn(
                Modifier.fillMaxSize().padding(horizontal = (RootedMetrics.pagePadding + 8).dp),
                contentPadding = PaddingValues(bottom = 110.dp),
            ) {
                item {
                    Text("STEP 01 · REGISTER", color = p.warm, fontSize = 10.sp, letterSpacing = 1.8.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("A real plant, a real character.", color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Light)
                    Spacer(Modifier.height(4.dp))
                    Text("From today its digital twin only levels up when the real plant does.", color = p.secondary, fontSize = 13.sp)
                    Spacer(Modifier.height(20.dp))

                    CapturePane(
                        bitmap = photo.bitmap,
                        title = "Photograph your plant",
                        subtitle = "Fill the frame with the plant in good light. ROOTED will suggest a species for you to confirm.",
                        onCamera = { photo.launchCamera() }, onGallery = { photo.launchGallery() },
                        onCleared = { photo.clear() },
                    )

                    LaunchedEffect(photo.bitmap) {
                        photo.bitmap?.let { analyse(it) }
                    }

                    if (analysing) {
                        Spacer(Modifier.height(14.dp))
                        AnalysingCard()
                    } else if (photo.bitmap != null) {
                        verification?.let {
                            Spacer(Modifier.height(14.dp))
                            VerificationCard(it)
                        }
                        duplicateName?.let {
                            Spacer(Modifier.height(14.dp))
                            DuplicateCard(it)
                        }
                        Spacer(Modifier.height(14.dp))
                        SpeciesCard(species, onPick = { showSpeciesPicker = true })
                        Spacer(Modifier.height(14.dp))
                        NamingCard(name, onNameChange = { name = it })
                    }
                }
            }

            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(appearance.ground).padding(horizontal = (RootedMetrics.pagePadding + 8).dp, vertical = 14.dp)) {
                Button(
                    onClick = {
                        val currentUser = user ?: return@Button
                        val bitmap = photo.bitmap ?: return@Button
                        val chosen = species ?: return@Button
                        if (isSaving || !canSubmit) return@Button
                        isSaving = true
                        scope.launch {
                            val plant = viewModel.garden.registerPlant(currentUser, name.trim(), chosen.name, chosen.emoji, bitmap)
                            isSaving = false
                            registered = plant
                            // Ask for notification permission right when it obviously
                            // matters — the first plant that could ever need a reminder —
                            // rather than on cold launch before there's anything to remind about.
                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                                notificationPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                            }
                        }
                    },
                    enabled = canSubmit && !isSaving,
                    colors = ButtonDefaults.buttonColors(containerColor = p.green, contentColor = p.onAccent),
                    shape = RoundedCornerShape(RootedMetrics.buttonRadius.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                ) { Text(if (isSaving) "Adding…" else "Add to my garden", fontWeight = FontWeight.Medium) }
            }
        }

        if (showSpeciesPicker) {
            SpeciesPickerSheet(selected = species, onSelect = { species = it; showSpeciesPicker = false }, onDismiss = { showSpeciesPicker = false })
        }
    }

    registered?.let { plant ->
        CelebrationOverlay(
            payload = CelebrationPayload(
                kind = CelebrationKind.REGISTERED,
                title = "${plant.name} is in your garden",
                subtitle = "Day 1 · 0 Verified Plant-Days · ${plant.stage.displayName}",
                stage = plant.stage,
                xp = GameEngine.REGISTRATION_XP,
                potSkin = user?.equippedPotSkin,
            ),
            onDismiss = { registered = null; onClose() },
        )
    }
}

@Composable
internal fun CapturePane(
    bitmap: android.graphics.Bitmap?, title: String, subtitle: String,
    onCamera: () -> Unit, onGallery: () -> Unit, onCleared: () -> Unit,
) {
    val p = LocalRootedAppearance.current.canvas
    Column {
        Box(
            Modifier
                .fillMaxWidth()
                .height(260.dp)
                .background(p.green.copy(alpha = 0.08f), RoundedCornerShape(RootedMetrics.cardRadius.dp))
                .border(1.5.dp, p.green.copy(alpha = 0.35f), RoundedCornerShape(RootedMetrics.cardRadius.dp)),
            contentAlignment = Alignment.Center,
        ) {
            if (bitmap != null) {
                Image(
                    bitmap = bitmap.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(RootedMetrics.cardRadius.dp)),
                )
                Box(Modifier.align(Alignment.TopEnd).padding(10.dp)) {
                    Box(
                        Modifier.size(30.dp).background(androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.45f), androidx.compose.foundation.shape.CircleShape)
                            .noRippleClickable { onCleared() },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Filled.Close, contentDescription = "Remove photo", tint = androidx.compose.ui.graphics.Color.White, modifier = Modifier.size(14.dp)) }
                }
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("📷", fontSize = 34.sp)
                    Spacer(Modifier.height(10.dp))
                    Text(title, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text(subtitle, color = p.secondary, fontSize = 13.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.padding(horizontal = 30.dp))
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = onCamera, shape = RoundedCornerShape(RootedMetrics.smallRadius.dp), modifier = Modifier.weight(1f)) { Text("Camera", fontSize = 13.sp) }
            OutlinedButton(onClick = onGallery, shape = RoundedCornerShape(RootedMetrics.smallRadius.dp), modifier = Modifier.weight(1f)) { Text("Library", fontSize = 13.sp) }
        }
    }
}

@Composable
fun PhotoPickerBlock(bitmap: android.graphics.Bitmap?, onCamera: () -> Unit, onGallery: () -> Unit) {
    CapturePane(bitmap, "No photo yet", "Take a clear photo in good light.", onCamera, onGallery, onCleared = {})
}

@Composable
private fun AnalysingCard() {
    val p = LocalRootedAppearance.current.canvas
    Row(Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(RootedMetrics.cardRadius.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        sg.rooted.android.ui.common.PlantLoader(size = 40.dp)
        Spacer(Modifier.width(12.dp))
        Column {
            Text("Analysing photo…", color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text("Checking vegetation and readiness on-device.", color = p.secondary, fontSize = 12.sp)
        }
    }
}

@Composable
private fun VerificationCard(check: VisionService.VerificationResult) {
    val p = LocalRootedAppearance.current.canvas
    Column(Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(RootedMetrics.cardRadius.dp)).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Vegetation check", color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            ConfidenceChip(check.confidence)
        }
        Spacer(Modifier.height(8.dp))
        Text(check.summary, color = p.secondary, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        sg.rooted.android.ui.theme.GreenBar(fraction = (check.greenRatio / 0.4).coerceIn(0.0, 1.0), surface = sg.rooted.android.ui.theme.RootedSurface.CANVAS)
        Spacer(Modifier.height(6.dp))
        Text("Green coverage ${(check.greenRatio * 100).toInt()}% of frame", color = p.secondary, fontSize = 11.sp)
    }
}

@Composable
private fun ConfidenceChip(level: ConfidenceLevel) {
    val p = LocalRootedAppearance.current.canvas
    val tint = when (level) {
        ConfidenceLevel.HIGH -> p.green
        ConfidenceLevel.MEDIUM -> p.warm
        ConfidenceLevel.LOW -> p.alert
    }
    Text(level.label.uppercase(), color = tint, fontSize = 9.5.sp, letterSpacing = 1.sp, fontWeight = FontWeight.Bold)
}

@Composable
private fun DuplicateCard(plantName: String) {
    val p = LocalRootedAppearance.current.canvas
    Row(Modifier.fillMaxWidth().background(p.warm.copy(alpha = 0.10f), RoundedCornerShape(RootedMetrics.cardRadius.dp)).padding(14.dp)) {
        Text("↻", color = p.warm, fontSize = 18.sp)
        Spacer(Modifier.width(10.dp))
        Column {
            Text("This looks like $plantName already in your garden.", color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text("Choose the existing plant for check-ins instead of registering a duplicate.", color = p.secondary, fontSize = 12.sp)
        }
    }
}

@Composable
private fun SpeciesCard(selected: SpeciesEntry?, onPick: () -> Unit) {
    val p = LocalRootedAppearance.current.canvas
    Column(Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(RootedMetrics.cardRadius.dp)).padding(14.dp)) {
        Text("Species", color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        if (selected != null) {
            Row(
                Modifier.fillMaxWidth().background(p.green.copy(alpha = 0.10f), RoundedCornerShape(RootedMetrics.chipRadius.dp))
                    .rootedPressable(haptic = false, onClick = onPick).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(selected.emoji, fontSize = 26.sp)
                Spacer(Modifier.width(10.dp))
                Text(selected.name, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("Change", color = p.green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        } else {
            Row(
                Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(RootedMetrics.chipRadius.dp))
                    .rootedPressable(haptic = false, onClick = onPick).padding(13.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Choose the species", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("›", color = p.text, fontSize = 16.sp)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "We couldn't confidently identify this one, that's normal. Pick it yourself and ROOTED won't overstate what it knows.",
                color = p.secondary, fontSize = 12.sp,
            )
        }
    }
}

@Composable
private fun NamingCard(name: String, onNameChange: (String) -> Unit) {
    val p = LocalRootedAppearance.current.canvas
    Column(Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(RootedMetrics.cardRadius.dp)).padding(14.dp)) {
        Text("Name your plant", color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = name, onValueChange = onNameChange, placeholder = { Text("e.g. Bob") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Text("Named plants get cared for. That's the point.", color = p.secondary, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Bob", "Sprout", "Kai", "Mochi", "Basil").forEach { suggestion ->
                Text(
                    suggestion, color = p.text, fontSize = 12.sp,
                    modifier = Modifier
                        .background(p.faintFill, RoundedCornerShape(6.dp))
                        .noRippleClickable { onNameChange(suggestion) }
                        .padding(horizontal = 11.dp, vertical = 6.dp),
                )
            }
        }
    }
}

@Composable
private fun SpeciesPickerSheet(selected: SpeciesEntry?, onSelect: (SpeciesEntry) -> Unit, onDismiss: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val results = remember(query) {
        if (query.isBlank()) SpeciesCatalog.all else SpeciesCatalog.all.filter { it.name.contains(query, ignoreCase = true) }
    }
    ModalBottomSheetCompat(onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 12.dp)) {
            Text("Determination", fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = query, onValueChange = { query = it }, placeholder = { Text("Search species") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        LazyColumn(Modifier.fillMaxWidth().padding(horizontal = 16.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            items(results) { entry ->
                Row(
                    Modifier.fillMaxWidth().rootedPressable(haptic = false) { onSelect(entry) }.padding(vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(entry.emoji, fontSize = 20.sp)
                    Spacer(Modifier.width(12.dp))
                    Text(entry.name, fontSize = 15.sp, modifier = Modifier.weight(1f))
                    if (selected?.name == entry.name) Icon(Icons.Filled.Check, contentDescription = null)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ModalBottomSheetCompat(onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column { content() }
    }
}
