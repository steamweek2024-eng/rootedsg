package sg.rooted.android.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import sg.rooted.android.RootedViewModel
import sg.rooted.android.engine.WeatherService
import sg.rooted.android.model.HealthStatus
import sg.rooted.android.model.Plant
import sg.rooted.android.model.QuestStatus
import sg.rooted.android.ui.common.PlantAvatarCharacter
import sg.rooted.android.ui.common.PlantCharacterView
import sg.rooted.android.ui.common.rootedPressable
import sg.rooted.android.ui.pet.MojoCompanion
import sg.rooted.android.ui.pet.WalkTarget
import sg.rooted.android.ui.pet.walkAnchor
import sg.rooted.android.ui.root.RootedTab
import sg.rooted.android.ui.theme.CountingNumber
import sg.rooted.android.ui.theme.GreenBar
import sg.rooted.android.ui.theme.GreenTag
import sg.rooted.android.ui.theme.LocalRootedAppearance
import sg.rooted.android.ui.theme.PaperRule
import sg.rooted.android.ui.theme.RisesIn
import sg.rooted.android.ui.theme.RootedMetrics
import sg.rooted.android.ui.theme.RootedSurface
import sg.rooted.android.ui.theme.WhiteSheet
import sg.rooted.android.ui.theme.rootedPalette

@Composable
fun HomeScreen(
    viewModel: RootedViewModel,
    onOpenPlant: (String) -> Unit,
    onCheckIn: (String) -> Unit,
    onOpenTab: (RootedTab) -> Unit,
    onOpenPet: () -> Unit = {},
) {
    val appearance = LocalRootedAppearance.current
    val canvas = appearance.canvas
    val plants by viewModel.plants.collectAsState()
    val quests by viewModel.quests.collectAsState()
    val user by viewModel.user.collectAsState()

    val active = plants.filter { it.health != HealthStatus.DECEASED }
    val due = active.filter { it.isCheckInDue() }
    val struggling = active.filter { it.health == HealthStatus.STRUGGLING || it.health == HealthStatus.AT_RISK }
    val activeQuests = quests.filter { it.status == QuestStatus.ACTIVE }.sortedByDescending { it.progressFraction }
    val featured = active.maxByOrNull { it.verifiedPlantDays }
    val totalDays = plants.sumOf { it.verifiedPlantDays }

    // Defaults to a plausible sample forecast so the card is on screen and tappable
    // from the very first frame, then swaps to the real live reading once it lands.
    var advisory by remember { mutableStateOf(WeatherService.CareAdvisory.placeholder) }
    LaunchedEffect(user?.neighbourhood) {
        WeatherService.todaysAdvisory(user?.neighbourhood)?.let { advisory = it }
    }
    var showWeatherDetail by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = (RootedMetrics.pagePadding + 8).dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 120.dp),
        ) {
            item {
                RisesIn(index = 1) { m ->
                    Box(m.walkAnchor(WalkTarget.HOME_HERO)) { HeroSection(active.size, totalDays, featured, user) }
                }
            }
            item {
                RisesIn(index = 2) { m ->
                    Box(m.padding(bottom = 14.dp)) { MojoCompanion(viewModel = viewModel, onOpenPet = onOpenPet) }
                }
            }
            item {
                RisesIn(index = 3) { m ->
                    Box(m.padding(bottom = 14.dp).walkAnchor(WalkTarget.HOME_DUE)) {
                        if (active.isEmpty()) EmptyBlock(onRegister = { onOpenTab(RootedTab.GARDEN) })
                        else DueBlock(due, struggling, onCheckIn, onOpenTab)
                    }
                }
            }
            item {
                RisesIn(index = 3) { m ->
                    Box(m.padding(bottom = 14.dp)) { WeatherBlock(advisory, onClick = { showWeatherDetail = true }) }
                }
            }
            if (activeQuests.isNotEmpty()) {
                item {
                    RisesIn(index = 4) { m -> Box(m.padding(bottom = 14.dp)) { QuestBlock(activeQuests.take(3)) } }
                }
            }
            item {
                RisesIn(index = 5) { m -> Box(m) { CommunityBlock(onClick = { onOpenTab(RootedTab.MARKET) }) } }
            }
        }

        if (showWeatherDetail) {
            WeatherDetailOverlay(advisory = advisory, onDismiss = { showWeatherDetail = false })
        }
    }
}

@Composable
private fun HeroSection(alive: Int, totalDays: Int, featured: Plant?, user: sg.rooted.android.model.UserProfile?) {
    val p = LocalRootedAppearance.current.canvas
    val potSkin = user?.equippedPotSkin
    val level = user?.level ?: 1
    val xpFraction = if (user != null && user.xpForNextLevel > 0) user.xpIntoCurrentLevel.toFloat() / user.xpForNextLevel.toFloat() else 0f
    Column(Modifier.padding(bottom = 30.dp)) {
        Text(
            "AT YOUR SERVICE", color = p.text.copy(alpha = 0.92f), fontSize = 9.5.sp, letterSpacing = 1.6.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.background(p.faintFill, RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 6.dp),
        )
        Spacer(Modifier.height(18.dp))
        Text("Count what we keep alive.", color = p.text, fontSize = 36.sp, fontWeight = FontWeight.Light, lineHeight = 40.sp)
        Spacer(Modifier.height(14.dp))
        Text("Not what we plant.\nVerified, day by day.", color = p.secondary, fontSize = 15.sp, lineHeight = 20.sp)

        Box(Modifier.fillMaxWidth().padding(top = 26.dp), contentAlignment = Alignment.Center) {
            val plant = featured
            if (plant != null) {
                PlantCharacterView(
                    stage = plant.stage, health = plant.health, growth = plant.progressToNextStage,
                    streak = plant.careStreak, glossy = true, potSkin = potSkin,
                    modifier = Modifier.height(220.dp).fillMaxWidth(),
                )
            } else {
                PlantCharacterView(
                    stage = sg.rooted.android.model.PlantStage.SPROUT, health = HealthStatus.HEALTHY, growth = 0.2,
                    streak = 0, glossy = true, potSkin = potSkin,
                    modifier = Modifier.height(220.dp).fillMaxWidth(),
                )
            }
        }

        Spacer(Modifier.height(26.dp))
        Box(Modifier.fillMaxWidth().height(1.dp).background(p.rule))
        Spacer(Modifier.height(20.dp))

        Row(verticalAlignment = Alignment.Bottom) {
            CountingNumber(value = totalDays, fontSize = 56.sp, color = p.green, fontWeight = FontWeight.Light)
            Spacer(Modifier.width(12.dp))
            Text(
                "VERIFIED\nPLANT-DAYS", color = p.secondary, fontSize = 9.sp, letterSpacing = 1.5.sp, lineHeight = 12.sp,
                modifier = Modifier.padding(bottom = 8.dp),
            )
        }

        Spacer(Modifier.height(22.dp))
        Row(Modifier.fillMaxWidth()) {
            HeroFigure("$alive", "Alive", p.text, p.secondary, Modifier.weight(1f))
            HeroFigure("${featured?.careStreak ?: 0}", "Streak", p.text, p.secondary, Modifier.weight(1f))
            HeroFigure("$level", "Level", p.text, p.secondary, Modifier.weight(1f))
        }
        Spacer(Modifier.height(20.dp))
        GreenBar(fraction = xpFraction.toDouble(), height = 3.dp, surface = RootedSurface.CANVAS)
    }
}

@Composable
private fun HeroFigure(value: String, caption: String, textColor: Color, secondaryColor: Color, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(value, color = textColor, fontSize = 24.sp, fontWeight = FontWeight.Light)
        Text(caption.uppercase(), color = secondaryColor.copy(alpha = 0.75f), fontSize = 9.sp, letterSpacing = 1.2.sp)
    }
}

@Composable
private fun EmptyBlock(onRegister: () -> Unit) {
    val p = rootedPalette(RootedSurface.PAPER)
    WhiteSheet {
        Column(horizontalAlignment = Alignment.Start) {
            Text("BEGIN", color = p.green, fontSize = 9.5.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Text("Register a real plant to start counting Verified Plant-Days.", color = p.secondary, fontSize = 15.sp)
            Spacer(Modifier.height(14.dp))
            Text(
                "REGISTER A PLANT", color = Color.White, fontSize = 10.sp, letterSpacing = 1.6.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .background(p.text, RoundedCornerShape(RootedMetrics.buttonRadius.dp))
                    .rootedPressable { onRegister() }
                    .padding(horizontal = 18.dp, vertical = 13.dp),
            )
        }
    }
}

@Composable
private fun DueBlock(
    due: List<Plant>, struggling: List<Plant>, onCheckIn: (String) -> Unit, onOpenTab: (RootedTab) -> Unit,
) {
    val p = rootedPalette(RootedSurface.PAPER)
    WhiteSheet {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (due.isEmpty()) "ALL VERIFIED" else "NEEDS YOU", color = p.green, fontSize = 9.5.sp,
                    letterSpacing = 2.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f),
                )
                if (due.isNotEmpty()) GreenTag(text = "${due.size} due")
            }
            Spacer(Modifier.height(if (due.isEmpty()) 10.dp else 14.dp))

            if (due.isEmpty()) {
                Text("Every plant has been verified recently.", color = p.secondary, fontSize = 15.sp)
            } else {
                due.take(3).forEachIndexed { index, plant ->
                    Row(
                        Modifier.fillMaxWidth().rootedPressable(haptic = false) { onCheckIn(plant.id) }.padding(vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        PlantAvatarCharacter(stage = plant.stage, health = plant.health, growth = plant.progressToNextStage, streak = plant.careStreak, sizeDp = 44)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(plant.name, color = p.text, fontSize = 19.sp, fontWeight = FontWeight.Light)
                            Text("${plant.daysSinceLastCheckIn()} DAYS SINCE CHECK-IN", color = p.secondary, fontSize = 9.sp, letterSpacing = 1.sp)
                        }
                        GreenTag(text = "Verify", filled = false)
                    }
                    if (index < minOf(3, due.size) - 1) PaperRule()
                }
                if (struggling.isNotEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "${struggling.size} PLANT${if (struggling.size == 1) "" else "S"} STRUGGLING",
                        color = p.alert, fontSize = 9.5.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Medium,
                        modifier = Modifier.rootedPressable(haptic = false) { onOpenTab(RootedTab.GARDEN) }.padding(top = 8.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun QuestBlock(quests: List<sg.rooted.android.model.Quest>) {
    val p = rootedPalette(RootedSurface.PAPER)
    WhiteSheet {
        Column {
            Text("QUESTS", color = p.green, fontSize = 9.5.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
            quests.forEachIndexed { index, quest ->
                val (icon, tint) = questVisuals(quest.type, p.green)
                Row(Modifier.padding(vertical = 12.dp), verticalAlignment = Alignment.Top) {
                    Box(Modifier.size(34.dp).background(tint.copy(alpha = 0.14f), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(15.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(quest.title, color = p.text, fontSize = 17.sp, fontWeight = FontWeight.Light, modifier = Modifier.weight(1f))
                            Text("${quest.progress}/${quest.target}", color = p.secondary, fontSize = 11.sp)
                        }
                        Spacer(Modifier.height(8.dp))
                        GreenBar(fraction = quest.progressFraction)
                    }
                }
                if (index < quests.size - 1) PaperRule()
            }
        }
    }
}

private fun questVisuals(type: sg.rooted.android.model.QuestType, defaultTint: Color): Pair<ImageVector, Color> =
    when (type) {
        sg.rooted.android.model.QuestType.CARE -> sg.rooted.android.ui.common.WeatherGlyphs.leaf to defaultTint
        sg.rooted.android.model.QuestType.RECOVERY -> Icons.Filled.MedicalServices to Color(0xFFB0563E)
        sg.rooted.android.model.QuestType.BIODIVERSITY -> Icons.Filled.BugReport to Color(0xFFCB8A3E)
        sg.rooted.android.model.QuestType.EXPLORATION -> Icons.Filled.Map to Color(0xFF4C8CB0)
        sg.rooted.android.model.QuestType.COMMUNITY -> Icons.Filled.Groups to Color(0xFFB05CA0)
        sg.rooted.android.model.QuestType.SCHOOL -> Icons.Filled.School to defaultTint
    }

@Composable
private fun WeatherBlock(advisory: WeatherService.CareAdvisory, onClick: () -> Unit) {
    val p = rootedPalette(RootedSurface.PAPER)
    val tint = when (advisory.tint) {
        WeatherService.Tint.RAIN -> Color(0xFF4C8CB0)
        WeatherService.Tint.HEAT -> Color(0xFFCB8A3E)
        WeatherService.Tint.UV -> Color(0xFFB0563E)
        WeatherService.Tint.NORMAL -> p.green
    }
    val icon: ImageVector = when (advisory.tint) {
        WeatherService.Tint.RAIN -> Icons.Filled.Cloud
        WeatherService.Tint.HEAT -> Icons.Filled.Whatshot
        WeatherService.Tint.UV -> Icons.Filled.WbSunny
        WeatherService.Tint.NORMAL -> Icons.Filled.Eco
    }

    WhiteSheet(modifier = Modifier.rootedPressable(haptic = true, onClick = onClick)) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "TODAY'S CONDITIONS", color = p.green, fontSize = 9.5.sp, letterSpacing = 2.sp,
                    fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f),
                )
                Text("NEA LIVE", color = p.secondary.copy(alpha = 0.6f), fontSize = 8.sp, letterSpacing = 1.2.sp)
                Spacer(Modifier.width(6.dp))
                Icon(
                    Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = null, tint = p.secondary.copy(alpha = 0.5f), modifier = Modifier.size(13.dp),
                )
            }
            Spacer(Modifier.height(14.dp))

            Row(verticalAlignment = Alignment.Top) {
                Box(Modifier.size(42.dp).background(tint.copy(alpha = 0.14f), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(19.dp))
                }
                Spacer(Modifier.width(13.dp))
                Column {
                    Text(advisory.headline, color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Light)
                    Spacer(Modifier.height(4.dp))
                    Text(advisory.detail, color = p.secondary, fontSize = 13.sp, lineHeight = 18.sp)
                    if (advisory.locationLabel.isNotBlank()) {
                        Spacer(Modifier.height(7.dp))
                        Text("NEAR ${advisory.locationLabel.uppercase()} · ${advisory.careContext}", color = p.green, fontSize = 9.sp, letterSpacing = 0.8.sp, maxLines = 2)
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            PaperRule()
            Spacer(Modifier.height(16.dp))

            Row(Modifier.fillMaxWidth()) {
                HeroFigure(
                    advisory.localTemperatureC?.let { "${it.toInt()}°" } ?: advisory.temperatureHigh?.let { "$it°" } ?: "-", "Nearby temp",
                    p.text, p.secondary, Modifier.weight(1f),
                )
                HeroFigure(advisory.localHumidityPercent?.let { "${it.toInt()}%" } ?: advisory.uvIndex?.toString() ?: "-", if (advisory.localHumidityPercent != null) "Humidity" else "UV index", p.text, p.secondary, Modifier.weight(1f))
                HeroFigure(if ((advisory.localRainfallMm ?: advisory.recentRainfallMm) > 0.05) "Wet" else "Dry", "Nearby rain", p.text, p.secondary, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun CommunityBlock(onClick: () -> Unit) {
    val p = rootedPalette(RootedSurface.PAPER)
    val islandWideTotal = remember { sg.rooted.android.engine.MockData.neighbourhoods.sumOf { it.verifiedPlantDays } }
    WhiteSheet(modifier = Modifier.rootedPressable(haptic = false, onClick = onClick)) {
        Column {
            Text("ISLAND-WIDE", color = p.green, fontSize = 9.5.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Column(Modifier.weight(1f)) {
                    Text("$islandWideTotal", color = p.green, fontSize = 34.sp, fontWeight = FontWeight.Light)
                    Text("PLANT-DAYS ACROSS SINGAPORE", color = p.secondary, fontSize = 9.sp, letterSpacing = 1.2.sp)
                }
                Box(
                    Modifier.size(22.dp).background(Color.Transparent, RoundedCornerShape(RootedMetrics.chipRadius.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("→", color = p.text.copy(alpha = 0.7f), fontSize = 14.sp)
                }
            }
        }
    }
}
