package sg.rooted.android.ui.home

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import sg.rooted.android.engine.WeatherService
import sg.rooted.android.ui.common.noRippleClickable
import sg.rooted.android.ui.theme.LocalRootedAppearance
import sg.rooted.android.ui.theme.PaperRule
import sg.rooted.android.ui.theme.RootedSurface
import sg.rooted.android.ui.theme.rootedPalette
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * The Today's Conditions card's own detail screen — a Compose port of
 * WeatherDetailOverlay (iOS): everything NEA actually gave us, presented as a
 * spring-driven overlay that feels like the card itself opening up rather than
 * an unrelated new screen arriving.
 */
@Composable
fun WeatherDetailOverlay(advisory: WeatherService.CareAdvisory, onDismiss: () -> Unit) {
    var show by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { show = true }

    fun dismiss() {
        show = false
    }
    LaunchedEffect(show) {
        if (!show) { delay(260); onDismiss() }
    }

    val scrimAlpha by animateFloatAsState(if (show) 0.5f else 0f, animationSpec = tween(280), label = "scrim")
    val cardScale by animateFloatAsState(
        if (show) 1f else 0.82f,
        animationSpec = spring(dampingRatio = 0.78f, stiffness = 260f), label = "cardScale",
    )
    val cardAlpha by animateFloatAsState(if (show) 1f else 0f, animationSpec = tween(240), label = "cardAlpha")

    val tint = when (advisory.tint) {
        WeatherService.Tint.RAIN -> Color(0xFF4C8CB0)
        WeatherService.Tint.HEAT -> Color(0xFFCB8A3E)
        WeatherService.Tint.UV -> Color(0xFFB0563E)
        WeatherService.Tint.NORMAL -> Color(0xFF2F6B4F)
    }

    Box(
        Modifier.fillMaxSize()
            .background(Color.Black.copy(alpha = scrimAlpha))
            .noRippleClickable { dismiss() },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .padding(horizontal = 18.dp)
                .scale(cardScale)
                .alpha(cardAlpha)
                .fillMaxWidth()
                .heightIn(max = 620.dp)
                .background(Color(0xFFF8F6F1), RoundedCornerShape(32.dp))
                .noRippleClickable(enabled = false) {},
        ) {
            DetailContent(advisory = advisory, tint = tint, onClose = { dismiss() })
        }
    }
}

@Composable
private fun DetailContent(advisory: WeatherService.CareAdvisory, tint: Color, onClose: () -> Unit) {
    val p = rootedPalette(RootedSurface.PAPER)
    Column(Modifier.verticalScroll(rememberScrollState()).padding(22.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "TODAY'S CONDITIONS", color = p.green, fontSize = 9.5.sp, letterSpacing = 2.sp,
                fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f),
            )
            Box(
                Modifier.size(30.dp).background(p.text.copy(alpha = 0.07f), CircleShape).noRippleClickable(onClick = onClose),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Filled.Close, contentDescription = "Close", tint = p.text, modifier = Modifier.size(14.dp)) }
        }
        Spacer(Modifier.height(6.dp))

        Box(Modifier.fillMaxWidth().padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
            AnimatedWeatherIcon(tint = advisory.tint, color = tint, size = 108.dp)
        }

        Spacer(Modifier.height(16.dp))
        Text(advisory.headline, color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Light)
        Spacer(Modifier.height(6.dp))
        Text(advisory.detail, color = p.secondary, fontSize = 14.sp, lineHeight = 19.sp)
        if (advisory.locationLabel.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text("NEAREST CONTEXT · ${advisory.locationLabel.uppercase()}", color = p.green, fontSize = 9.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
            Text(advisory.careContext, color = p.text, fontSize = 12.sp, lineHeight = 17.sp)
        }

        if (advisory.uvIndex != null) {
            Spacer(Modifier.height(20.dp))
            Row(
                Modifier.fillMaxWidth().background(p.text.copy(alpha = 0.04f), RoundedCornerShape(20.dp)).padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                UvGauge(uvIndex = advisory.uvIndex, modifier = Modifier.size(100.dp))
                Spacer(Modifier.width(18.dp))
                Column {
                    Text("UV INDEX", color = p.secondary, fontSize = 9.sp, letterSpacing = 1.4.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(uvGuidance(advisory.uvIndex), color = p.text, fontSize = 13.sp, lineHeight = 17.sp)
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth()) {
            DetailFigure(advisory.temperatureHigh?.let { "$it°" } ?: "—", "High", Modifier.weight(1f))
            Box(Modifier.width(1.dp).height(32.dp).background(p.rule))
            DetailFigure(advisory.temperatureLow?.let { "$it°" } ?: "—", "Low", Modifier.weight(1f))
            Box(Modifier.width(1.dp).height(32.dp).background(p.rule))
            DetailFigure(
                "${advisory.stationsReportingRain}/${maxOf(advisory.totalStations, 1)}", "Wet stations",
                Modifier.weight(1f),
            )
        }

        if (advisory.localTemperatureC != null || advisory.localHumidityPercent != null || advisory.localWindKmh != null) {
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth()) {
                DetailFigure(advisory.localTemperatureC?.let { "${it.toInt()}°" } ?: "—", "Nearby temp", Modifier.weight(1f))
                Box(Modifier.width(1.dp).height(32.dp).background(p.rule))
                DetailFigure(advisory.localHumidityPercent?.let { "${it.toInt()}%" } ?: "—", "Humidity", Modifier.weight(1f))
                Box(Modifier.width(1.dp).height(32.dp).background(p.rule))
                DetailFigure(advisory.localWindKmh?.let { "${it.toInt()}" } ?: "—", "Wind reading", Modifier.weight(1f))
            }
        }

        if (advisory.fourDayOutlook.isNotEmpty()) {
            Spacer(Modifier.height(22.dp))
            Text("4-DAY OUTLOOK", color = p.secondary, fontSize = 9.sp, letterSpacing = 1.6.sp)
            Spacer(Modifier.height(8.dp))
            advisory.fourDayOutlook.forEachIndexed { index, day ->
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(day.date.ifBlank { "Day ${index + 1}" }, color = p.green, fontSize = 10.sp, modifier = Modifier.width(84.dp))
                    Text(day.forecast.ifBlank { "Forecast unavailable" }, color = p.text, fontSize = 11.5.sp, modifier = Modifier.weight(1f), maxLines = 2)
                    Spacer(Modifier.width(8.dp))
                    Text(listOfNotNull(day.low, day.high).joinToString("–") { "$it°" }, color = p.secondary, fontSize = 10.sp)
                }
                if (index < advisory.fourDayOutlook.size - 1) PaperRule()
            }
        }

        if (advisory.periods.isNotEmpty()) {
            Spacer(Modifier.height(22.dp))
            Text("EXTENDED FORECAST", color = p.secondary, fontSize = 9.sp, letterSpacing = 1.6.sp)
            Spacer(Modifier.height(12.dp))
            advisory.periods.forEachIndexed { index, period ->
                Column(Modifier.padding(vertical = 10.dp)) {
                    Text(period.label.uppercase(), color = p.green, fontSize = 9.sp, letterSpacing = 1.1.sp)
                    Spacer(Modifier.height(5.dp))
                    Text("West ${period.west} · East ${period.east} · Central ${period.central}", color = p.text, fontSize = 12.sp)
                    Text("South ${period.south} · North ${period.north}", color = p.text, fontSize = 12.sp)
                }
                if (index < advisory.periods.size - 1) PaperRule()
            }
        }

        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.Top) {
            Icon(Icons.Filled.Info, contentDescription = null, tint = Color(0xFF4C8CB0), modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                "Live from public data.gov.sg / NEA feeds. Sensor feeds update at their published cadences; ROOTED caches readings briefly to avoid unnecessary requests.",
                color = p.secondary, fontSize = 11.sp,
            )
        }
        Spacer(Modifier.height(6.dp))
    }
}

@Composable
private fun DetailFigure(value: String, caption: String, modifier: Modifier = Modifier) {
    val p = rootedPalette(RootedSurface.PAPER)
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = p.text, fontSize = 19.sp, fontWeight = FontWeight.Light)
        Text(caption.uppercase(), color = p.secondary, fontSize = 8.sp, letterSpacing = 1.1.sp)
    }
}

private fun uvGuidance(uv: Int): String = when (WeatherService.UvCategory.of(uv)) {
    WeatherService.UvCategory.LOW -> "Safe for most plants in direct sun most of the day."
    WeatherService.UvCategory.MODERATE -> "Fine for sun-lovers; give shade-preferring plants some cover."
    WeatherService.UvCategory.HIGH -> "Sun-sensitive leaves can scorch. Filtered light past midday helps."
    WeatherService.UvCategory.VERY_HIGH -> "Move delicate pots to filtered light through the early afternoon."
    WeatherService.UvCategory.EXTREME -> "Direct afternoon sun is harsh today, even for sun-loving plants."
}

// MARK: Animated icon — a small, condition-specific loop, driven by an infinite
// transition so it can never get stuck mid-animation.

@Composable
private fun AnimatedWeatherIcon(tint: WeatherService.Tint, color: Color, size: androidx.compose.ui.unit.Dp) {
    val infinite = rememberInfiniteTransition(label = "weatherIcon")
    val t by infinite.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3000, easing = LinearEasing), RepeatMode.Restart),
        label = "t",
    )
    val pulse by infinite.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Reverse),
        label = "pulse",
    )

    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Box(Modifier.size(size).background(color.copy(alpha = 0.12f), CircleShape))
        when (tint) {
            WeatherService.Tint.RAIN -> RainIcon(color, size, t)
            WeatherService.Tint.UV -> SunIcon(color, size, t, pulse)
            WeatherService.Tint.HEAT -> HeatIcon(color, size, pulse)
            WeatherService.Tint.NORMAL -> LeafIcon(color, size, pulse)
        }
    }
}

@Composable
private fun RainIcon(color: Color, size: androidx.compose.ui.unit.Dp, t: Float) {
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Icon(sg.rooted.android.ui.common.WeatherGlyphs.cloud, contentDescription = null, tint = color, modifier = Modifier.size(size * 0.44f))
        Canvas(Modifier.size(size)) {
            val center = this.size.width / 2f
            for (i in 0..3) {
                val cycle = (t + i * 0.25f) % 1f
                val x = center + (i - 2) * (this.size.width * 0.12f) + this.size.width * 0.05f
                val y = this.size.height * 0.55f + cycle * this.size.height * 0.35f
                drawLine(
                    color = color.copy(alpha = (1f - cycle) * 0.9f),
                    start = Offset(x, y), end = Offset(x + 2f, y + 9f),
                    strokeWidth = 3f, cap = StrokeCap.Round,
                )
            }
        }
    }
}

@Composable
private fun SunIcon(color: Color, size: androidx.compose.ui.unit.Dp, t: Float, pulse: Float) {
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size).rotate(t * 360f)) {
            val radius = this.size.minDimension / 2f * 0.82f
            for (i in 0 until 8) {
                val angle = i * (2 * PI / 8)
                val sx = this.size.width / 2f + (radius * 0.72f * cos(angle)).toFloat()
                val sy = this.size.height / 2f + (radius * 0.72f * sin(angle)).toFloat()
                val ex = this.size.width / 2f + (radius * cos(angle)).toFloat()
                val ey = this.size.height / 2f + (radius * sin(angle)).toFloat()
                drawLine(color.copy(alpha = 0.55f), Offset(sx, sy), Offset(ex, ey), strokeWidth = 3f, cap = StrokeCap.Round)
            }
        }
        Icon(
            sg.rooted.android.ui.common.WeatherGlyphs.sun, contentDescription = null, tint = color,
            modifier = Modifier.size(size * 0.38f).scale(1f + 0.06f * (pulse - 0.5f)),
        )
    }
}

@Composable
private fun HeatIcon(color: Color, size: androidx.compose.ui.unit.Dp, pulse: Float) {
    Icon(
        sg.rooted.android.ui.common.WeatherGlyphs.heat, contentDescription = null, tint = color,
        modifier = Modifier.size(size * 0.42f)
            .scale(1f + 0.05f * (pulse - 0.5f))
            .rotate(5f * (pulse - 0.5f)),
    )
}

@Composable
private fun LeafIcon(color: Color, size: androidx.compose.ui.unit.Dp, pulse: Float) {
    Icon(
        sg.rooted.android.ui.common.WeatherGlyphs.leaf, contentDescription = null, tint = color,
        modifier = Modifier.size(size * 0.42f).rotate(9f * (pulse - 0.5f)),
    )
}

// MARK: UV gauge

@Composable
private fun UvGauge(uvIndex: Int, modifier: Modifier = Modifier) {
    val scaleMax = 12f
    val fraction = (uvIndex / scaleMax).coerceIn(0f, 1f)
    var animated by remember { mutableStateOf(0f) }
    LaunchedEffect(fraction) { animated = fraction }
    val animatedValue by animateFloatAsState(animated, animationSpec = spring(dampingRatio = 0.8f, stiffness = 60f), label = "uvGauge")

    val bandColors = listOf(Color(0xFF4CAF50), Color(0xFFFFEB3B), Color(0xFFFF9800), Color(0xFFF44336), Color(0xFF9C27B0))
    val p = rootedPalette(RootedSurface.PAPER)

    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = Stroke(width = 11.dp.toPx(), cap = StrokeCap.Round)
            val brush = Brush.sweepGradient(bandColors)
            drawArc(brush = brush, startAngle = -90f, sweepAngle = 360f, useCenter = false, style = stroke, alpha = 0.2f)
            drawArc(brush = brush, startAngle = -90f, sweepAngle = 360f * animatedValue, useCenter = false, style = stroke)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$uvIndex", color = p.text, fontSize = 28.sp, fontWeight = FontWeight.Light)
            Text(WeatherService.UvCategory.of(uvIndex).label.uppercase(), color = p.secondary, fontSize = 7.5.sp, letterSpacing = 1.sp)
        }
    }
}
