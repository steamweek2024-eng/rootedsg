package sg.rooted.android.ui.onboarding

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import sg.rooted.android.RootedViewModel
import sg.rooted.android.model.HealthStatus
import sg.rooted.android.model.PlantStage
import sg.rooted.android.ui.common.PlantCharacterView
import sg.rooted.android.ui.common.RootedAmbientField
import sg.rooted.android.ui.common.noRippleClickable
import sg.rooted.android.ui.common.rootedBreathe
import sg.rooted.android.ui.theme.LocalRootedAppearance
import sg.rooted.android.ui.theme.RootedMetrics

private val avatarOptions = listOf("🌱", "🌿", "🌳", "🌻", "🪴", "🍀", "🌺", "🦋")
private val neighbourhoodOptions = listOf(
    "Ang Mo Kio", "Bedok", "Bishan", "Bukit Batok", "Bukit Merah", "Bukit Panjang",
    "Bukit Timah", "Choa Chu Kang", "Clementi", "Geylang", "Hougang", "Jurong East",
    "Jurong West", "Kallang", "Marine Parade", "Pasir Ris", "Punggol", "Queenstown",
    "Sembawang", "Sengkang", "Serangoon", "Tampines", "Toa Payoh", "Woodlands", "Yishun",
)

private const val pageCount = 5

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun OnboardingScreen(viewModel: RootedViewModel, onDone: () -> Unit) {
    val appearance = LocalRootedAppearance.current
    val p = appearance.canvas
    val pagerState = rememberPagerState(pageCount = { pageCount })
    val scope = rememberCoroutineScope()

    var name by remember { mutableStateOf("") }
    var school by remember { mutableStateOf("") }
    var avatar by remember { mutableStateOf(avatarOptions.first()) }
    var neighbourhood by remember { mutableStateOf("Tampines") }
    var isStarting by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(appearance.ground)) {
        RootedAmbientField(Modifier.fillMaxSize(), color = if (pagerState.currentPage % 2 == 0) p.green else p.warm) { }

        Column(Modifier.fillMaxSize()) {
            HorizontalPager(state = pagerState, modifier = Modifier.weight(1f)) { page ->
                when (page) {
                    0 -> GuardianIntroPage()
                    1 -> MysteryLoopPage()
                    2 -> GreenhouseWorldPage()
                    3 -> SingaporeTrustPage()
                    else -> ProfilePage(
                        name = name, onNameChange = { name = it },
                        school = school, onSchoolChange = { school = it },
                        avatar = avatar, onAvatarChange = { avatar = it },
                        neighbourhood = neighbourhood, onNeighbourhoodChange = { neighbourhood = it },
                    )
                }
            }

            Surface(color = appearance.ground.copy(alpha = 0.96f)) {
                Column(Modifier.fillMaxWidth().padding(horizontal = 28.dp).padding(bottom = 28.dp, top = 10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.padding(bottom = 16.dp)) {
                        repeat(pageCount) { i ->
                            val isCurrent = i == pagerState.currentPage
                            val dotWidth by animateDpAsState(if (isCurrent) 28.dp else 8.dp, tween(260), label = "onboardDot")
                            Box(
                                Modifier.height(8.dp).width(dotWidth).background(
                                    if (isCurrent) Brush.linearGradient(listOf(p.warm, p.green))
                                    else Brush.linearGradient(listOf(p.secondary.copy(alpha = 0.25f), p.secondary.copy(alpha = 0.25f))),
                                    RoundedCornerShape(99.dp),
                                ),
                            )
                        }
                    }

                    if (pagerState.currentPage < pageCount - 1) {
                        Button(
                            onClick = { scope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) } },
                            colors = ButtonDefaults.buttonColors(containerColor = p.green, contentColor = p.onAccent),
                            shape = RoundedCornerShape(RootedMetrics.buttonRadius.dp),
                            modifier = Modifier.fillMaxWidth().height(54.dp),
                        ) {
                            Text(
                                when (pagerState.currentPage) {
                                    0 -> "Enter the greenhouse"
                                    1 -> "See your plant world"
                                    2 -> "How ROOTED stays trustworthy"
                                    else -> "Create my Guardian"
                                },
                                fontSize = 15.sp, fontWeight = FontWeight.Medium,
                            )
                        }
                    } else {
                        Button(
                            onClick = {
                                if (name.isBlank() || isStarting) return@Button
                                isStarting = true
                                scope.launch {
                                    viewModel.garden.ensureUser(
                                        name = name.trim(), school = school.trim(), avatarEmoji = avatar,
                                        neighbourhood = neighbourhood,
                                    )
                                    onDone()
                                }
                            },
                            enabled = name.isNotBlank() && !isStarting,
                            colors = ButtonDefaults.buttonColors(containerColor = p.green, contentColor = p.onAccent),
                            shape = RoundedCornerShape(RootedMetrics.buttonRadius.dp),
                            modifier = Modifier.fillMaxWidth().height(54.dp),
                        ) {
                            Text(if (isStarting) "Planting your first sprout…" else "START AS PLANT GUARDIAN 🌱", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GuardianIntroPage() {
    val p = LocalRootedAppearance.current.canvas
    val infinite = rememberInfiniteTransition(label = "introOrbit")
    val orbit by infinite.animateFloat(0f, 360f, infiniteRepeatable(tween(8000, easing = FastOutSlowInEasing)), label = "orbit")

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(42.dp))
        Text("ROOTED SG", color = p.green, fontSize = 12.sp, letterSpacing = 4.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        Box(Modifier.size(288.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize().graphicsLayer(rotationZ = orbit)) {
                drawCircle(p.green.copy(alpha = 0.12f), radius = size.minDimension * 0.48f)
                drawCircle(p.warm.copy(alpha = 0.25f), radius = 5.dp.toPx(), center = androidx.compose.ui.geometry.Offset(size.width * 0.50f, 8.dp.toPx()))
                drawCircle(p.green.copy(alpha = 0.35f), radius = 4.dp.toPx(), center = androidx.compose.ui.geometry.Offset(18.dp.toPx(), size.height * 0.60f))
            }
            PlantCharacterView(
                stage = PlantStage.GROWING, health = HealthStatus.HEALTHY, growth = 0.68, streak = 6,
                onDark = true, modifier = Modifier.size(218.dp, 246.dp).rootedBreathe(9f),
            )
        }
        Spacer(Modifier.height(14.dp))
        Text("Your real plant becomes the game.", color = p.text, fontSize = 29.sp, lineHeight = 34.sp, fontWeight = FontWeight.Light, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(
            "Care for it in real life. Investigate problems. Complete rescue quests. Watch its character, greenhouse and your Guardian level evolve.",
            color = p.secondary, fontSize = 14.sp, lineHeight = 20.sp, textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MiniPill("REAL CARE", p.green)
            MiniPill("REAL PROGRESS", p.warm)
            MiniPill("REAL PLANTS", p.green)
        }
        Spacer(Modifier.height(34.dp))
    }
}

@Composable
private fun MysteryLoopPage() {
    val p = LocalRootedAppearance.current.canvas
    var reveal by remember { mutableIntStateOf(0) }
    val transition = rememberInfiniteTransition(label = "demoScan")
    val scanY by transition.animateFloat(0.12f, 0.88f, infiniteRepeatable(tween(1200), RepeatMode.Reverse), label = "demoScanY")

    LaunchedEffect(Unit) {
        repeat(3) { i -> delay(620); reveal = i + 1 }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp)) {
        Spacer(Modifier.height(44.dp))
        SectionHeader("Save your plant", "Every check is", "a mission.")
        Spacer(Modifier.height(18.dp))
        Box(Modifier.fillMaxWidth().height(192.dp).clip(RoundedCornerShape(26.dp)).background(p.faintFill), contentAlignment = Alignment.Center) {
            Text("🌿", fontSize = 92.sp, modifier = Modifier.rootedBreathe(7f))
            Canvas(Modifier.fillMaxSize()) {
                val y = size.height * scanY
                drawLine(p.green, androidx.compose.ui.geometry.Offset(0f, y), androidx.compose.ui.geometry.Offset(size.width, y), strokeWidth = 2.dp.toPx())
                drawRect(p.green.copy(alpha = 0.06f), androidx.compose.ui.geometry.Offset(0f, (y - 24.dp.toPx()).coerceAtLeast(0f)), androidx.compose.ui.geometry.Size(size.width, 48.dp.toPx()))
            }
            Text("SCANNING FOR CLUES", color = p.green, fontSize = 9.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.TopStart).padding(16.dp))
        }
        Spacer(Modifier.height(14.dp))
        listOf(
            Triple("🍃", "CLUE #1", "Leaf colour changed"),
            Triple("💧", "CLUE #2", "Moisture pattern looks unusual"),
            Triple("☀️", "CLUE #3", "Singapore conditions add context"),
        ).forEachIndexed { index, clue ->
            AnimatedVisibility(
                visible = reveal > index,
                enter = fadeIn(tween(320)) + slideInVertically(tween(420)) { it / 3 },
            ) {
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(p.faintFill, RoundedCornerShape(16.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(clue.first, fontSize = 22.sp)
                    Spacer(Modifier.width(10.dp))
                    Column { Text(clue.second, color = p.warm, fontSize = 8.5.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp); Text(clue.third, color = p.text, fontSize = 13.sp) }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("SCAN → DISCOVER → YOUR READ → TREAT → RECHECK → LEVEL UP", color = p.green, fontSize = 9.sp, letterSpacing = 1.1.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(30.dp))
    }
}

@Composable
private fun GreenhouseWorldPage() {
    val p = LocalRootedAppearance.current.canvas
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp)) {
        Spacer(Modifier.height(44.dp))
        SectionHeader("Your plant world", "Build a", "living greenhouse.")
        Spacer(Modifier.height(8.dp))
        Text("Every registered plant occupies a real place in your greenhouse. Better care unlocks stages, zones, pots, rewards and achievements.", color = p.secondary, fontSize = 13.5.sp, lineHeight = 19.sp)
        Spacer(Modifier.height(18.dp))
        Column(Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(26.dp)).padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("PLANT GUARDIAN", color = p.green, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp); Text("Level 18", color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Light) }
                Text("🔥 14 day streak", color = p.warm, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(16.dp))
            DemoShelf(listOf("Luna" to 92, "Bob" to 74, "Spike" to 86))
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(5.dp).background(p.rule, RoundedCornerShape(99.dp))) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(0.72f).background(p.green, RoundedCornerShape(99.dp)))
            }
            Spacer(Modifier.height(12.dp))
            Text("🔓 RAINFOREST CORNER UNLOCKED", color = p.green, fontSize = 9.sp, letterSpacing = 1.1.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            RewardTile("🏆", "Achievements", "Useful behaviour")
            RewardTile("🎁", "Surprises", "Seeds + décor")
        }
        Spacer(Modifier.height(30.dp))
    }
}

@Composable
private fun DemoShelf(plants: List<Pair<String, Int>>) {
    val p = LocalRootedAppearance.current.canvas
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.Bottom) {
            plants.forEachIndexed { index, (name, score) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(listOf("🌿", "🌱", "🌵")[index], fontSize = 45.sp, modifier = Modifier.rootedBreathe(4f + index))
                    Text(name, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("❤ $score", color = if (score >= 85) p.green else p.warm, fontSize = 9.5.sp)
                }
            }
        }
        Spacer(Modifier.height(5.dp))
        Box(Modifier.fillMaxWidth().height(7.dp).background(p.secondary.copy(alpha = 0.25f), RoundedCornerShape(99.dp)))
    }
}

@Composable
private fun RowScope.RewardTile(icon: String, title: String, detail: String) {
    val p = LocalRootedAppearance.current.canvas
    Row(Modifier.weight(1f).background(p.faintFill, RoundedCornerShape(18.dp)).padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 23.sp)
        Spacer(Modifier.width(8.dp))
        Column { Text(title, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.Bold); Text(detail, color = p.secondary, fontSize = 9.5.sp) }
    }
}

@Composable
private fun SingaporeTrustPage() {
    val p = LocalRootedAppearance.current.canvas
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp)) {
        Spacer(Modifier.height(44.dp))
        SectionHeader("Built for Singapore", "More context,", "less guessing.")
        Spacer(Modifier.height(16.dp))
        DataCard(Icons.Filled.Cloud, "Live local conditions", "ROOTED can combine nearby public rainfall, temperature, humidity, wind, UV and forecasts with what the camera actually sees.", p.green)
        Spacer(Modifier.height(10.dp))
        DataCard(Icons.Filled.VerifiedUser, "AI stays a guide", "You collect clues and make a read for learning. ROOTED still identifies the likely cause and never turns a risky care decision into a guessing game.", p.warm)
        Spacer(Modifier.height(10.dp))
        DataCard(Icons.Filled.Lock, "Local-first by design", "Your garden, quests and progress work on-device. Cloud analysis and account sync enhance the experience when a ROOTED backend is configured.", p.secondary)
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth().background(p.green.copy(alpha = 0.08f), RoundedCornerShape(18.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.WaterDrop, contentDescription = null, tint = p.green, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Text("Example: recent rain + high humidity → soil may dry more slowly → ROOTED can suggest delaying watering and rechecking moisture first.", color = p.text, fontSize = 11.5.sp, lineHeight = 16.sp)
        }
        Spacer(Modifier.height(30.dp))
    }
}

@Composable
private fun DataCard(icon: ImageVector, title: String, body: String, tint: Color) {
    val p = LocalRootedAppearance.current.canvas
    Row(Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(18.dp)).border(1.dp, p.rule, RoundedCornerShape(18.dp)).padding(14.dp), verticalAlignment = Alignment.Top) {
        Box(Modifier.size(38.dp).background(tint.copy(alpha = 0.14f), CircleShape), contentAlignment = Alignment.Center) { Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp)) }
        Spacer(Modifier.width(12.dp))
        Column { Text(title, color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(3.dp)); Text(body, color = p.secondary, fontSize = 11.5.sp, lineHeight = 16.sp) }
    }
}

@Composable
private fun ProfilePage(
    name: String, onNameChange: (String) -> Unit,
    school: String, onSchoolChange: (String) -> Unit,
    avatar: String, onAvatarChange: (String) -> Unit,
    neighbourhood: String, onNeighbourhoodChange: (String) -> Unit,
) {
    val p = LocalRootedAppearance.current.canvas
    val sproutScale by animateFloatAsState((0.72f + name.length.coerceAtMost(12) * 0.022f).coerceAtMost(1f), tween(500), label = "sproutGrow")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 28.dp)) {
        Spacer(Modifier.height(36.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { SectionHeader("Your Guardian", "Plant your", "first identity.") }
            Text(if (name.isBlank()) "🌱" else avatar, fontSize = 54.sp, modifier = Modifier.graphicsLayer(scaleX = sproutScale, scaleY = sproutScale).rootedBreathe(4f))
        }
        Spacer(Modifier.height(16.dp))

        FieldLabel("Choose an avatar")
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(avatarOptions) { emoji ->
                val selected = emoji == avatar
                Box(
                    Modifier.size(44.dp).background(if (selected) p.warm.copy(alpha = 0.30f) else p.faintFill, CircleShape)
                        .border(if (selected) 2.dp else 1.dp, if (selected) p.warm else p.rule, CircleShape)
                        .then(if (selected) Modifier.shadow(8.dp, CircleShape, spotColor = p.warm) else Modifier)
                        .noRippleClickable { onAvatarChange(emoji) },
                    contentAlignment = Alignment.Center,
                ) { Text(emoji, fontSize = 22.sp) }
            }
        }

        Spacer(Modifier.height(16.dp)); FieldLabel("Your name"); Spacer(Modifier.height(7.dp))
        OutlinedTextField(value = name, onValueChange = onNameChange, placeholder = { Text("e.g. Maya") }, singleLine = true, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next), modifier = Modifier.fillMaxWidth(), colors = fieldColors(p.text, p.rule))

        Spacer(Modifier.height(14.dp)); FieldLabel("School or community (optional)"); Spacer(Modifier.height(7.dp))
        OutlinedTextField(value = school, onValueChange = onSchoolChange, placeholder = { Text("e.g. Green Secondary School") }, singleLine = true, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done), modifier = Modifier.fillMaxWidth(), colors = fieldColors(p.text, p.rule))

        Spacer(Modifier.height(14.dp)); FieldLabel("Neighbourhood"); Spacer(Modifier.height(7.dp))
        Text("This helps ROOTED choose nearby public weather stations. It is not a home address.", color = p.secondary, fontSize = 10.5.sp)
        Spacer(Modifier.height(7.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(neighbourhoodOptions) { n ->
                val selected = n == neighbourhood
                Text(
                    n, color = if (selected) p.onAccent else p.text, fontSize = 12.5.sp,
                    modifier = Modifier.background(if (selected) p.green else Color.Transparent, RoundedCornerShape(99.dp))
                        .border(if (selected) 0.dp else 1.dp, p.rule, RoundedCornerShape(99.dp))
                        .noRippleClickable { onNeighbourhoodChange(n) }.padding(horizontal = 13.dp, vertical = 8.dp),
                )
            }
        }
        Spacer(Modifier.height(28.dp))
    }
}

@Composable
private fun SectionHeader(eyebrow: String, title: String, italicTail: String) {
    val p = LocalRootedAppearance.current.canvas
    Column {
        Text(eyebrow.uppercase(), color = p.warm, fontSize = 9.5.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(title, color = p.text, fontSize = 26.sp, fontWeight = FontWeight.Light)
        Text(italicTail, color = p.green, fontSize = 26.sp, fontWeight = FontWeight.Light, fontStyle = FontStyle.Italic)
    }
}

@Composable
private fun MiniPill(text: String, tint: Color) {
    Text(text, color = tint, fontSize = 8.sp, letterSpacing = 1.1.sp, fontWeight = FontWeight.Bold, modifier = Modifier.background(tint.copy(alpha = 0.10f), RoundedCornerShape(99.dp)).padding(horizontal = 10.dp, vertical = 6.dp))
}

@Composable
private fun FieldLabel(text: String) {
    val p = LocalRootedAppearance.current.canvas
    Text(text.uppercase(), color = p.warm, fontSize = 9.5.sp, letterSpacing = 1.4.sp, fontWeight = FontWeight.Bold)
}

@Composable
private fun fieldColors(text: Color, rule: Color) = OutlinedTextFieldDefaults.colors(
    focusedTextColor = text, unfocusedTextColor = text,
    focusedBorderColor = rule, unfocusedBorderColor = rule,
    cursorColor = text,
)
