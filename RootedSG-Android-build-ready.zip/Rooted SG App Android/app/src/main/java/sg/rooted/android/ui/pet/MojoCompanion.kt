package sg.rooted.android.ui.pet

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import sg.rooted.android.RootedViewModel
import sg.rooted.android.engine.MojoAnim
import sg.rooted.android.engine.MojoEngine
import sg.rooted.android.engine.MojoMood
import sg.rooted.android.ui.common.rootedPressable
import sg.rooted.android.ui.theme.LocalRootedAppearance
import sg.rooted.android.ui.theme.RootedMetrics
import sg.rooted.android.ui.theme.RootedSurface
import sg.rooted.android.ui.theme.WhiteSheet
import sg.rooted.android.ui.theme.rootedPalette

/**
 * Mojo's spot on the Home screen — a resident companion card. He idles, waves
 * when you arrive, hops when XP lands, and looks glum when the garden slips.
 * Tapping opens his full screen ([sg.rooted.android.ui.pet.PetScreen]).
 */
@Composable
fun MojoCompanion(viewModel: RootedViewModel, onOpenPet: () -> Unit, modifier: Modifier = Modifier) {
    val p = rootedPalette(RootedSurface.PAPER)
    val vitals by viewModel.petVitals.collectAsState()
    val plants by viewModel.plants.collectAsState()
    val quests by viewModel.quests.collectAsState()
    val petName by viewModel.petName.collectAsState()
    val recent by viewModel.recentXPEvents.collectAsState()

    // Wave once whenever Home is (re)entered.
    var greeting by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { delay(2200); greeting = false }

    // Hop when the newest XP event changes (something was just earned).
    val latestXpId = recent.firstOrNull()?.id
    var hopping by remember { mutableStateOf(false) }
    var seenXpId by remember { mutableStateOf(latestXpId) }
    LaunchedEffect(latestXpId) {
        if (latestXpId != null && latestXpId != seenXpId) {
            seenXpId = latestXpId
            hopping = true
            delay(1500)
            hopping = false
        }
    }

    val anim = when {
        hopping -> MojoAnim.JUMPING
        greeting -> MojoAnim.WAVING
        vitals.mood == MojoMood.SAD -> MojoAnim.FAILED
        vitals.mood == MojoMood.WORRIED -> MojoAnim.REVIEW
        else -> MojoAnim.IDLE
    }

    val line = remember(vitals, plants, quests, petName) {
        MojoEngine.encouragement(vitals, plants, quests, petName).firstOrNull()
            ?: "$petName is settling in."
    }
    val daySeed = remember { java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR) }
    val tip = remember(vitals, plants, quests, petName, daySeed) {
        MojoEngine.dailyTip(plants, quests, vitals, petName, daySeed)
    }

    WhiteSheet(modifier = modifier.walkAnchor(WalkTarget.MOJO_CARD).rootedPressable(haptic = false, onClick = onOpenPet)) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                MojoSprite(anim = anim, modifier = Modifier.size(80.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(petName.uppercase(), color = p.green, fontSize = 9.5.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(8.dp))
                        HealthChip(vitals.health, p.green, p.faintFill)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(line, color = p.text, fontSize = 14.sp, lineHeight = 18.sp)
                }
                Spacer(Modifier.width(6.dp))
                Text("→", color = p.secondary, fontSize = 15.sp)
            }
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.background(p.faintFill, RoundedCornerShape(RootedMetrics.smallRadius.dp)).padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.Top,
            ) {
                Text("💡", fontSize = 12.sp)
                Spacer(Modifier.width(8.dp))
                Text(tip, color = p.secondary, fontSize = 12.5.sp, lineHeight = 16.sp)
            }
        }
    }
}

@Composable
private fun HealthChip(health: Int, green: androidx.compose.ui.graphics.Color, fill: androidx.compose.ui.graphics.Color) {
    val p = LocalRootedAppearance.current.onPaper
    Box(
        Modifier.background(fill, RoundedCornerShape(RootedMetrics.buttonRadius.dp)).padding(horizontal = 8.dp, vertical = 3.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("HEALTH", color = p.secondary, fontSize = 8.sp, letterSpacing = 1.sp)
            Text("$health", color = green, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}
