package sg.rooted.android.ui.pet

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import sg.rooted.android.engine.MojoAnim
import sg.rooted.android.engine.MojoEngine
import sg.rooted.android.engine.MojoReactionBus
import sg.rooted.android.ui.common.rootedPressable
import sg.rooted.android.ui.theme.LocalRootedAppearance
import sg.rooted.android.ui.theme.RootedMetrics

/** Mounted once in the shell. Shows the latest reaction for a couple of seconds. */
@Composable
fun MojoReactionHost(petName: String, onOpenPet: () -> Unit, modifier: Modifier = Modifier) {
    val appearance = LocalRootedAppearance.current
    val p = appearance.canvas
    var shown by remember { mutableStateOf<Pair<MojoAnim, String>?>(null) }

    LaunchedEffect(Unit) {
        MojoReactionBus.events.collect { event ->
            val r = MojoEngine.reaction(event, petName) ?: return@collect
            shown = r
            delay(2600)
            shown = null
        }
    }

    Box(modifier.fillMaxSize().safeDrawingPadding(), contentAlignment = Alignment.BottomEnd) {
        AnimatedVisibility(
            visible = shown != null,
            enter = slideInVertically(spring(stiffness = Spring.StiffnessMediumLow)) { it } + fadeIn() + scaleIn(initialScale = 0.9f),
            exit = slideOutVertically { it } + fadeOut() + scaleOut(targetScale = 0.9f),
        ) {
            val (anim, text) = shown ?: (MojoAnim.IDLE to "")
            Row(
                Modifier
                    .padding(16.dp)
                    .widthIn(max = 300.dp)
                    .background(appearance.paper, RoundedCornerShape(RootedMetrics.cardRadius.dp))
                    .rootedPressable(haptic = false, onClick = onOpenPet)
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                MojoSprite(anim = anim, modifier = Modifier.size(44.dp))
                Text(
                    text, color = appearance.onPaper.text, fontSize = 12.5.sp, lineHeight = 16.sp,
                    fontWeight = FontWeight.Medium,
                )
            }
        }
    }
}
