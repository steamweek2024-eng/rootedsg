package sg.rooted.android.ui.pet

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage
import coil.request.ImageRequest
import sg.rooted.android.R
import sg.rooted.android.engine.MojoAnim

/**
 * Mojo the carrot, rendered from one of the pixel-art GIFs in `res/raw/`.
 * The app's process-wide Coil [coil.ImageLoader] (see RootedApplication) has an
 * animated-image decoder registered, so these actually play and loop.
 *
 * Pixel art: [FilterQuality.None] keeps the edges crisp at any size. [flipX]
 * mirrors him horizontally — used so a single "running" pose can face either way
 * when a dedicated left/right asset isn't the one being shown.
 */
@Composable
fun MojoSprite(
    anim: MojoAnim,
    modifier: Modifier = Modifier,
    flipX: Boolean = false,
) {
    val context = LocalContext.current
    val res = rawResFor(anim)
    AsyncImage(
        model = ImageRequest.Builder(context)
            .data(res)
            .crossfade(false)
            .build(),
        contentDescription = "Mojo the carrot, ${anim.name.lowercase().replace('_', ' ')}",
        modifier = modifier.graphicsLayer { scaleX = if (flipX) -1f else 1f },
        contentScale = ContentScale.Fit,
        filterQuality = FilterQuality.None,
    )
}

private fun rawResFor(anim: MojoAnim): Int = when (anim) {
    MojoAnim.IDLE -> R.raw.mojo_idle
    MojoAnim.WAITING -> R.raw.mojo_waiting
    MojoAnim.WAVING -> R.raw.mojo_waving
    MojoAnim.RUNNING -> R.raw.mojo_running
    MojoAnim.RUNNING_LEFT -> R.raw.mojo_running_left
    MojoAnim.RUNNING_RIGHT -> R.raw.mojo_running_right
    MojoAnim.JUMPING -> R.raw.mojo_jumping
    MojoAnim.REVIEW -> R.raw.mojo_review
    MojoAnim.FAILED -> R.raw.mojo_failed
}

/** A monotonic seconds clock driven by the frame loop — for callers that want a
 * gentle sine bob or hop on top of the GIF (the GIF's own animation is separate). */
@Composable
fun rememberMojoClock(running: Boolean = true): Float {
    var seconds by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(running) {
        if (!running) return@LaunchedEffect
        val start = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            seconds = (now - start) / 1_000_000_000f
        }
    }
    return seconds
}
