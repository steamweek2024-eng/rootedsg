package sg.rooted.android.ui.pet

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import sg.rooted.android.RootedViewModel
import sg.rooted.android.engine.MojoEngine
import sg.rooted.android.engine.MojoMood
import sg.rooted.android.ui.common.SheetHeader
import sg.rooted.android.ui.common.noRippleClickable
import sg.rooted.android.ui.common.rootedPressable
import sg.rooted.android.ui.theme.CountingNumber
import sg.rooted.android.ui.theme.GreenBar
import sg.rooted.android.ui.theme.LocalRootedAppearance
import sg.rooted.android.ui.theme.ProgressRing
import sg.rooted.android.ui.theme.RootedMetrics

/**
 * Mojo's own screen — reached from the Home card and from Profile. Shows what
 * his health is actually made of (garden / badges / momentum), what he's
 * thinking right now, and the switches for his reminders and re-running the tour.
 */
@Composable
fun PetScreen(viewModel: RootedViewModel, onClose: () -> Unit) {
    val appearance = LocalRootedAppearance.current
    val p = appearance.canvas
    val scope = rememberCoroutineScope()

    val vitals by viewModel.petVitals.collectAsState()
    val plants by viewModel.plants.collectAsState()
    val quests by viewModel.quests.collectAsState()
    val petName by viewModel.petName.collectAsState()
    val nudgesOn by viewModel.petNudgesEnabled.collectAsState()

    var editing by remember { mutableStateOf(false) }
    var draft by remember(petName) { mutableStateOf(petName) }

    val thoughts = MojoEngine.encouragement(vitals, plants, quests, petName)

    Column(Modifier.fillMaxSize().background(appearance.ground).safeDrawingPadding()) {
        SheetHeader(title = petName, onClose = onClose)

        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = (RootedMetrics.pagePadding + 8).dp),
            contentPadding = PaddingValues(top = 6.dp, bottom = 40.dp),
        ) {
            item {
                Column(
                    Modifier.fillMaxWidth()
                        .background(p.faintFill, RoundedCornerShape(RootedMetrics.cardRadius.dp))
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    MojoSprite(anim = MojoEngine.restingAnim(vitals.mood), modifier = Modifier.size(168.dp))
                    Spacer(Modifier.height(6.dp))
                    if (editing) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = draft, onValueChange = { draft = it.take(20) }, singleLine = true,
                                modifier = Modifier.width(200.dp),
                            )
                            Spacer(Modifier.width(8.dp))
                            Box(
                                Modifier.size(36.dp).background(p.green, RoundedCornerShape(50))
                                    .noRippleClickable {
                                        scope.launch { viewModel.setPetName(draft) }
                                        editing = false
                                    },
                                contentAlignment = Alignment.Center,
                            ) { Icon(Icons.Filled.Check, contentDescription = "Save name", tint = p.onAccent, modifier = Modifier.size(18.dp)) }
                        }
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.noRippleClickable { draft = petName; editing = true },
                        ) {
                            Text(petName, color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Light)
                            Spacer(Modifier.width(6.dp))
                            Icon(Icons.Filled.Edit, contentDescription = "Rename", tint = p.secondary, modifier = Modifier.size(14.dp))
                        }
                    }
                }
            }

            item {
                Spacer(Modifier.height(18.dp))
                Box(
                    Modifier.fillMaxWidth()
                        .background(p.faintFill, RoundedCornerShape(RootedMetrics.cardRadius.dp))
                        .padding(vertical = 22.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Box(Modifier.size(148.dp), contentAlignment = Alignment.Center) {
                        ProgressRing(
                            progress = vitals.health / 100.0,
                            modifier = Modifier.fillMaxSize(),
                            lineWidth = 10.dp,
                            tint = ringTint(vitals.mood, p.green, p.warm, p.alert),
                            track = p.faintFill,
                        )
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("HEALTH", color = p.secondary, fontSize = 9.sp, letterSpacing = 1.6.sp)
                            CountingNumber(value = vitals.health, fontSize = 44.sp, color = p.text)
                            Text(moodLabel(vitals.mood), color = p.secondary, fontSize = 11.sp)
                        }
                    }
                }
            }

            item {
                Spacer(Modifier.height(18.dp))
                Column(
                    Modifier.fillMaxWidth()
                        .background(p.faintFill, RoundedCornerShape(RootedMetrics.cardRadius.dp))
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    Text("WHAT KEEPS ME GREEN", color = p.green, fontSize = 9.5.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                    SourceBar("Garden", "Average health of your living plants", vitals.gardenScore)
                    SourceBar("Badges", "Level, completed quests and survival milestones", vitals.badgeScore)
                    SourceBar("Momentum", "This week's XP and your best care streak", vitals.momentumScore)
                }
            }

            if (thoughts.isNotEmpty()) {
                item {
                    Spacer(Modifier.height(20.dp))
                    Text("WHAT ${petName.uppercase()} IS THINKING", color = p.green, fontSize = 9.5.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                }
                items(thoughts) { t ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
                        Text("•", color = p.green, fontSize = 14.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(t, color = p.text, fontSize = 13.sp, lineHeight = 18.sp)
                    }
                }
            }

            item {
                Spacer(Modifier.height(22.dp))
                Row(
                    Modifier.fillMaxWidth()
                        .background(p.faintFill, RoundedCornerShape(RootedMetrics.cardRadius.dp))
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Mojo reminders", color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        Text("A gentle nudge when the garden needs you", color = p.secondary, fontSize = 11.sp)
                    }
                    Switch(
                        checked = nudgesOn,
                        onCheckedChange = { scope.launch { viewModel.setPetNudges(it) } },
                        colors = SwitchDefaults.colors(checkedTrackColor = p.green),
                    )
                }
            }

            item {
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier.fillMaxWidth()
                        .background(p.faintFill, RoundedCornerShape(RootedMetrics.cardRadius.dp))
                        .rootedPressable(haptic = false) {
                            scope.launch { viewModel.setWalkthroughSeen(false) }
                            onClose()
                        }
                        .padding(horizontal = 16.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.Replay, contentDescription = null, tint = p.green, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Replay the tour", color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        Text("Mojo walks you through the app again", color = p.secondary, fontSize = 11.sp)
                    }
                    Text("→", color = p.secondary, fontSize = 15.sp)
                }
            }
        }
    }
}

@Composable
private fun SourceBar(label: String, caption: String, value: Double) {
    val p = LocalRootedAppearance.current.canvas
    Column {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(label, color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Text("${(value * 100).toInt()}%", color = p.secondary, fontSize = 11.sp)
        }
        Spacer(Modifier.height(6.dp))
        GreenBar(fraction = value, surface = sg.rooted.android.ui.theme.RootedSurface.CANVAS)
        Spacer(Modifier.height(4.dp))
        Text(caption, color = p.secondary, fontSize = 10.sp, lineHeight = 13.sp)
    }
}

private fun moodLabel(mood: MojoMood): String = when (mood) {
    MojoMood.THRIVING -> "Thriving"
    MojoMood.HAPPY -> "Happy"
    MojoMood.OKAY -> "Doing okay"
    MojoMood.WORRIED -> "Worried"
    MojoMood.SAD -> "Wilting"
}

private fun ringTint(
    mood: MojoMood,
    green: androidx.compose.ui.graphics.Color,
    warm: androidx.compose.ui.graphics.Color,
    alert: androidx.compose.ui.graphics.Color,
): androidx.compose.ui.graphics.Color = when (mood) {
    MojoMood.THRIVING, MojoMood.HAPPY, MojoMood.OKAY -> green
    MojoMood.WORRIED -> warm
    MojoMood.SAD -> alert
}
