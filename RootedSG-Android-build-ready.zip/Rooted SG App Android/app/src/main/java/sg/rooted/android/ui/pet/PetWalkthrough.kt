package sg.rooted.android.ui.pet

import android.provider.Settings
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.animateRectAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import sg.rooted.android.engine.MojoAnim
import sg.rooted.android.engine.MojoEngine
import sg.rooted.android.ui.common.noRippleClickable
import sg.rooted.android.ui.common.rootedPressable
import sg.rooted.android.ui.root.RootedTab
import sg.rooted.android.ui.theme.LocalRootedAppearance
import kotlin.math.roundToInt
import kotlin.math.sin

private data class Step(
    val target: WalkTarget?,
    val tab: RootedTab?,
    val arriveAnim: MojoAnim,
    val eyebrow: String,
    val title: String,
    val body: String,
)

private fun script(petName: String): List<Step> = listOf(
    Step(null, RootedTab.HOME, MojoAnim.WAVING,
        "MEET MOJO", "Hi — I'm $petName.",
        "Your carrot. I grow when your garden does, and wilt when it doesn't. Hop on."),
    Step(WalkTarget.HOME_HERO, RootedTab.HOME, MojoAnim.JUMPING,
        "THE ONLY SCORE", "Verified Plant-Days.",
        "Days you kept a plant alive and proved it with a photo. That's the whole game."),
    Step(WalkTarget.HOME_DUE, RootedTab.HOME, MojoAnim.REVIEW,
        "YOUR TO-DO LIST", "A plant that needs you",
        "lands on your Today list. One tap, one photo, done for the week."),
    Step(WalkTarget.TOP_LEVEL_PILL, RootedTab.HOME, MojoAnim.WAVING,
        "YOU", "Your level and Seeds.",
        "Every verified day earns XP and a Seed. Tap for the breakdown."),
    Step(WalkTarget.ADD_BUTTON, RootedTab.HOME, MojoAnim.JUMPING,
        "GROW THE GARDEN", "Add a real plant.",
        "Point your camera at something growing. $petName suggests the species."),
    Step(WalkTarget.MENU_BUTTON, RootedTab.HOME, MojoAnim.WAITING,
        "EVERYTHING ELSE", "Behind this button:",
        "Profile, the Singapore-wide picture, the Shop, and five themes."),
    Step(WalkTarget.SCREEN_HERO, RootedTab.GARDEN, MojoAnim.IDLE,
        "GARDEN", "Every plant you tend,",
        "day by day, with its health and how close it is to its next stage."),
    Step(WalkTarget.SCREEN_HERO, RootedTab.MARKET, MojoAnim.IDLE,
        "MARKET", "Grew too much basil?",
        "Give it away or swap it with a neighbour. $petName never touches the money."),
    Step(WalkTarget.SCREEN_HERO, RootedTab.QUESTS, MojoAnim.REVIEW,
        "QUESTS", "Small goals",
        "that keep the garden moving — streaks, rescues, pollinator hunts."),
    Step(WalkTarget.SCREEN_HERO, RootedTab.BIODEX, MojoAnim.IDLE,
        "BIODEX", "Log the visitors.",
        "Bees, butterflies, birds. Singapore counts its biodiversity, and so do you."),
    Step(WalkTarget.MOJO_CARD, RootedTab.HOME, MojoAnim.WAVING,
        "AND THIS IS ME", "$petName lives here.",
        "My health is your plants, your badges and your momentum. Keep me green."),
)

/**
 * The guided first-run tour, redrawn as a cloud Mojo rides. The cloud carries
 * the tip text and drifts to park beside or below whichever element the
 * spotlight is on — never over it — while Mojo emotes on the crest. A soft
 * vapour trail fades behind each drift. Hosted by [sg.rooted.android.ui.root.RootShell].
 */
@Composable
fun PetWalkthrough(
    petName: String,
    currentTab: RootedTab,
    onSetTab: (RootedTab) -> Unit,
    onFinish: () -> Unit,
) {
    val steps = remember(petName) { script(petName) }
    val anchors = LocalWalkthroughAnchors.current
    val appearance = LocalRootedAppearance.current
    val p = appearance.canvas
    val density = LocalDensity.current
    val context = LocalContext.current
    val reduceMotion = remember {
        Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val screenW = with(density) { maxWidth.toPx() }
        val screenH = with(density) { maxHeight.toPx() }
        val safeTop = WindowInsets.safeDrawing.getTop(density).toFloat() + with(density) { 8.dp.toPx() }
        val safeBottom = WindowInsets.safeDrawing.getBottom(density).toFloat() + with(density) { 8.dp.toPx() }
        val ready = screenW > 1f

        val small = maxWidth < 360.dp
        val cloudWDp = if (small) 308.dp else 344.dp
        val cloudW = with(density) { minOf(cloudWDp.toPx(), screenW - 20.dp.toPx()) }
        val cloudHDp = if (small) 232.dp else 250.dp
        val cloudH = with(density) { cloudHDp.toPx() }
        val mojoDp = if (small) 64.dp else 78.dp
        val mojoPx = with(density) { mojoDp.toPx() }
        val overhang = mojoPx * 0.58f
        val unitW = cloudW
        val unitH = cloudH + overhang
        val gap = with(density) { 12.dp.toPx() }

        var stepIndex by remember { mutableIntStateOf(0) }
        var arrived by remember { mutableStateOf(false) }
        var started by remember { mutableStateOf(false) }
        var emote by remember { mutableStateOf(MojoAnim.WAVING) }
        var hasHole by remember { mutableStateOf(false) }
        var holeTarget by remember { mutableStateOf(Rect.Zero) }
        val wisps = remember { WispField() }
        val cloudPos = remember {
            Animatable(Offset((screenW - cloudW) / 2f, -unitH - 40f), Offset.VectorConverter)
        }
        // Drives the silhouette morph — a different cloud shape per step.
        val cloudPhase = remember { Animatable(0f) }
        // Tip text fades out the instant a step changes and back in only once the
        // cloud has parked, so the words never appear to move ahead of the cloud.
        val contentAlpha = remember { Animatable(1f) }

        var clock by remember { mutableFloatStateOf(0f) }
        LaunchedEffect(reduceMotion) {
            if (reduceMotion) return@LaunchedEffect
            val start = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                clock = (now - start) / 1_000_000_000f
            }
        }
        val bobPx = if (reduceMotion) 0f else sin(clock * 1.7f) * with(density) { 3.dp.toPx() }

        suspend fun awaitAnchor(target: WalkTarget, timeoutMs: Long): Rect? {
            var waited = 0L
            while (waited < timeoutMs) {
                anchors.rects[target]?.let { return it }
                withFrameNanos { }
                waited += 16
            }
            return anchors.rects[target]
        }

        /** Clamp a tall target (a whole tab screen) down to its top strip so the
         * cloud has somewhere to sit and the spotlight lands on the header. */
        fun effectiveTarget(raw: Rect): Rect {
            if (raw.height <= screenH * 0.5f) return raw
            val top = raw.top.coerceAtLeast(safeTop)
            val bottom = minOf(raw.top + screenH * 0.28f, raw.bottom)
            return Rect(raw.left, top, raw.right, bottom)
        }

        fun clampX(x: Float) = x.coerceIn(10f, screenW - unitW - 10f)
        fun clampY(y: Float) = y.coerceIn(safeTop, screenH - safeBottom - unitH)

        /** Returns the cloud unit's top-left for this step's target — the first
         * slot (below/above/right/left) where the cloud fits on screen and does
         * not overlap the (inflated) target; otherwise pinned to the bottom. */
        fun placeCloud(raw: Rect?): Offset {
            if (raw == null) {
                return Offset((screenW - unitW) / 2f, screenH * 0.46f - unitH / 2f)
            }
            val t = effectiveTarget(raw)
            val infl = Rect(t.left - gap, t.top - gap, t.right + gap, t.bottom + gap)
            fun rectAt(o: Offset) = Rect(o.x, o.y, o.x + unitW, o.y + unitH)
            fun ok(o: Offset): Boolean {
                val r = rectAt(o)
                val onScreen = r.left >= 8f && r.right <= screenW - 8f &&
                    r.top >= safeTop - 1f && r.bottom <= screenH - safeBottom + 1f
                return onScreen && !r.overlaps(infl)
            }
            val below = Offset(clampX(t.center.x - unitW / 2f), t.bottom + gap)
            val above = Offset(clampX(t.center.x - unitW / 2f), t.top - gap - unitH)
            val right = Offset(t.right + gap, clampY(t.center.y - unitH / 2f))
            val left = Offset(t.left - gap - unitW, clampY(t.center.y - unitH / 2f))
            val order = if (raw.height > screenH * 0.5f) listOf(below, above, right, left) else listOf(below, above, right, left)
            order.firstOrNull { ok(it) }?.let { return it }
            // Fallback: bottom, clamped — the least-covering spot for a big target.
            return Offset(clampX(t.center.x - unitW / 2f), screenH - safeBottom - unitH)
        }

        // Per-step: switch tab, resolve the anchor, drift the cloud, start the emote loop.
        LaunchedEffect(stepIndex, ready) {
            if (!ready) return@LaunchedEffect
            val step = steps[stepIndex]
            val firstRun = !started
            started = true
            arrived = false

            // Text leaves first (fast) so the content swap happens while it's hidden.
            if (!reduceMotion && !firstRun) {
                launch { contentAlpha.animateTo(0f, tween(120)) }
            }

            val switching = step.tab != null && step.tab != currentTab
            step.tab?.let { if (it != currentTab) onSetTab(it) }
            val raw = step.target?.let { awaitAnchor(it, if (switching) 1400 else 700) }

            hasHole = raw != null
            if (raw != null) holeTarget = effectiveTarget(raw)

            val dest = placeCloud(raw)
            val from = Offset(cloudPos.value.x + unitW / 2f, cloudPos.value.y + unitH / 2f)
            val to = Offset(dest.x + unitW / 2f, dest.y + unitH / 2f)
            if (!reduceMotion) {
                wisps.emitAlong(from, to, count = 6, baseRadiusPx = mojoPx * 0.22f, nowMs = System.currentTimeMillis())
            }
            // Position + shape morph ride the same spring, in lock-step.
            launch {
                cloudPhase.animateTo(
                    stepIndex.toFloat(),
                    if (reduceMotion) snap() else spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessLow),
                )
            }
            cloudPos.animateTo(
                dest,
                if (reduceMotion) snap() else spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessLow),
            )
            arrived = true

            // Text returns once the cloud has arrived.
            if (reduceMotion) contentAlpha.snapTo(1f) else contentAlpha.animateTo(1f, tween(220))

            // Emote: the step's arrival pose, then a gentle rotation of poses.
            emote = step.arriveAnim
            delay(1500)
            var i = 0
            while (true) {
                emote = MojoEngine.EMOTE_CYCLE[i % MojoEngine.EMOTE_CYCLE.size]
                i++
                delay(2500)
            }
        }

        if (!ready) return@BoxWithConstraints

        val holeRadius = with(density) { 18.dp.toPx() }
        val holePad = with(density) { 8.dp.toPx() }
        val ringStroke = with(density) { 2.dp.toPx() }
        val animedHole by animateRectAsState(
            targetValue = holeTarget,
            animationSpec = if (reduceMotion) snap() else spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessLow),
            label = "hole",
        )
        val ringPulse = if (reduceMotion) 0.9f else 0.7f + 0.25f * (0.5f + 0.5f * sin(clock * 3f))

        // 1) Dim + spotlight punch-out (glides between elements).
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
                .drawWithCache {
                    onDrawWithContent {
                        drawRect(Color.Black.copy(alpha = 0.6f))
                        if (hasHole) {
                            drawRoundRect(
                                color = Color.Black,
                                topLeft = Offset(animedHole.left - holePad, animedHole.top - holePad),
                                size = Size(animedHole.width + holePad * 2, animedHole.height + holePad * 2),
                                cornerRadius = CornerRadius(holeRadius, holeRadius),
                                blendMode = BlendMode.Clear,
                            )
                        }
                    }
                }
                .pointerInput(Unit) { detectTapGestures { } },
        )

        // 2) Spotlight ring.
        if (hasHole) {
            Canvas(Modifier.fillMaxSize()) {
                drawRoundRect(
                    color = p.green.copy(alpha = ringPulse),
                    topLeft = Offset(animedHole.left - holePad, animedHole.top - holePad),
                    size = Size(animedHole.width + holePad * 2, animedHole.height + holePad * 2),
                    cornerRadius = CornerRadius(holeRadius, holeRadius),
                    style = Stroke(width = ringStroke, cap = StrokeCap.Round),
                )
            }
        }

        // 3) Vapour trail.
        WispLayer(wisps, Modifier.fillMaxSize())

        // 4) The cloud unit — Mojo on the crest, tip text in the belly.
        val faceLeft = holeTarget.center.x < (cloudPos.targetValue.x + unitW / 2f)
        Box(
            Modifier
                .size(with(density) { unitW.toDp() }, with(density) { unitH.toDp() })
                .offset { IntOffset(cloudPos.value.x.roundToInt(), (cloudPos.value.y + bobPx).roundToInt()) },
        ) {
            Box(Modifier.align(Alignment.BottomCenter).size(with(density) { cloudW.toDp() }, cloudHDp)) {
                CloudArt(phase = cloudPhase.value, modifier = Modifier.fillMaxSize())
                CloudTip(
                    step = steps[stepIndex],
                    index = stepIndex,
                    count = steps.size,
                    small = small,
                    contentAlpha = contentAlpha.value,
                    onSkip = onFinish,
                    onNext = { if (stepIndex >= steps.lastIndex) onFinish() else stepIndex++ },
                    modifier = Modifier.fillMaxSize(),
                )
            }
            // Mojo rides the centre crown — his feet track the crest as it morphs.
            val crestY = cloudParamsFor(cloudPhase.value).mY
            MojoSprite(
                anim = if (arrived) emote else MojoAnim.WAITING,
                flipX = faceLeft,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .offset {
                        IntOffset(
                            (-unitW * 0.08f).roundToInt(),
                            (-((1f - crestY) * cloudH) - cloudH * 0.12f + bobPx).roundToInt(),
                        )
                    }
                    .size(mojoDp),
            )
        }
    }
}

/** The degrees of freedom the cloud silhouette morphs across. Same topology every
 * step — nine cubic segments over a broad soft base — only these shift, so the
 * outline glides from one shape to the next as one continuous cloud. */
private data class CloudParams(
    val lY: Float, val mY: Float, val rY: Float, val mX: Float,
    val shoulderY: Float, val side: Float, val baseY: Float,
)

/** One distinct silhouette per tour step, cycled. Consecutive entries are close
 * enough that the spring morph between them reads as the same cloud breathing. */
private val CLOUD_VARIANTS = listOf(
    CloudParams(0.36f, 0.24f, 0.28f, 0.45f, 0.44f, 1.010f, 0.93f), // balanced
    CloudParams(0.24f, 0.31f, 0.34f, 0.40f, 0.46f, 1.000f, 0.93f), // left-heavy
    CloudParams(0.34f, 0.30f, 0.22f, 0.52f, 0.40f, 1.022f, 0.93f), // right-heavy
    CloudParams(0.33f, 0.16f, 0.31f, 0.47f, 0.44f, 1.006f, 0.93f), // tall centre
    CloudParams(0.30f, 0.27f, 0.27f, 0.44f, 0.48f, 1.030f, 0.91f), // wide + low
    CloudParams(0.28f, 0.22f, 0.33f, 0.43f, 0.42f, 1.014f, 0.93f), // rolling
)

private fun lerpF(a: Float, b: Float, t: Float) = a + (b - a) * t

private fun cloudParamsFor(phase: Float): CloudParams {
    val n = CLOUD_VARIANTS.size
    val ph = phase.coerceAtLeast(0f)
    val i = ph.toInt() % n
    val j = (i + 1) % n
    val f = ph - kotlin.math.floor(ph)
    val a = CLOUD_VARIANTS[i]
    val b = CLOUD_VARIANTS[j]
    return CloudParams(
        lerpF(a.lY, b.lY, f), lerpF(a.mY, b.mY, f), lerpF(a.rY, b.rY, f),
        lerpF(a.mX, b.mX, f), lerpF(a.shoulderY, b.shoulderY, f),
        lerpF(a.side, b.side, f), lerpF(a.baseY, b.baseY, f),
    )
}

/** One cloud, one continuous curve — three soft crowns over a broad base, its
 * shape driven by `phase` (the tour step as a continuous value). */
private fun cloudPath(size: Size, phase: Float): Path {
    val pr = cloudParamsFor(phase)
    val w = size.width
    val h = size.height
    val base = pr.baseY
    return Path().apply {
        moveTo(w * 0.04f, h * 0.66f)
        cubicTo(w * -0.03f, h * 0.42f, w * 0.04f, h * (pr.lY - 0.04f), w * 0.20f, h * pr.lY)
        cubicTo(w * 0.30f, h * (pr.lY - 0.02f), w * (pr.mX - 0.13f), h * (pr.mY - 0.06f), w * pr.mX, h * pr.mY)
        cubicTo(w * (pr.mX + 0.11f), h * (pr.mY - 0.06f), w * 0.64f, h * (pr.rY - 0.16f), w * 0.72f, h * pr.rY)
        cubicTo(w * 0.79f, h * (pr.rY - 0.12f), w * 0.93f, h * (pr.shoulderY - 0.18f), w * 0.92f, h * pr.shoulderY)
        cubicTo(w * pr.side, h * (pr.shoulderY + 0.08f), w * (pr.side + 0.005f), h * 0.58f, w * 0.955f, h * 0.66f)
        cubicTo(w * (pr.side - 0.02f), h * (base - 0.10f), w * 0.92f, h * base, w * 0.80f, h * base)
        cubicTo(w * 0.62f, h * (base + 0.045f), w * 0.38f, h * (base + 0.045f), w * 0.20f, h * base)
        cubicTo(w * 0.08f, h * base, w * -0.01f, h * 0.80f, w * 0.04f, h * 0.66f)
        close()
    }
}

/** The soft cumulus the tour text sits in: a feathered white halo, a top-to-
 * bottom gradient for volume, an upper sheen, a cool underside, and a faint
 * contact shadow — one puffy cloud, not a pile of circles. */
@Composable
private fun CloudArt(phase: Float, modifier: Modifier = Modifier) {
    Box(modifier) {
        // Feathered white halo.
        Canvas(Modifier.fillMaxSize().blur(11.dp, androidx.compose.ui.draw.BlurredEdgeTreatment.Unbounded)) {
            drawPath(cloudPath(size, phase), Color.White.copy(alpha = 0.9f))
        }
        // Contact shadow.
        Canvas(Modifier.fillMaxSize()) {
            drawOval(
                brush = androidx.compose.ui.graphics.Brush.radialGradient(
                    listOf(Color.Black.copy(alpha = 0.08f), Color.Transparent),
                    center = Offset(size.width * 0.5f, size.height * 0.99f), radius = size.width * 0.44f,
                ),
                topLeft = Offset(size.width * 0.06f, size.height * 0.9f),
                size = Size(size.width * 0.88f, size.height * 0.16f),
            )
        }
        // Body — gradient + sheen + underside, all clipped to the one curve.
        Canvas(Modifier.fillMaxSize()) {
            val path = cloudPath(size, phase)
            clipPath(path) {
                drawRect(
                    brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                        0f to Color.White, 0.6f to Color.White, 1f to Color(0.91f, 0.94f, 0.98f),
                    ),
                )
                drawOval(
                    brush = androidx.compose.ui.graphics.Brush.radialGradient(
                        listOf(Color.White, Color.Transparent),
                        center = Offset(size.width * 0.44f, size.height * 0.30f), radius = size.width * 0.34f,
                    ),
                    topLeft = Offset(size.width * 0.13f, size.height * 0.06f),
                    size = Size(size.width * 0.62f, size.height * 0.34f),
                )
                drawRect(
                    brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                        0.6f to Color.Transparent, 1f to Color(0.74f, 0.79f, 0.9f).copy(alpha = 0.32f),
                    ),
                )
            }
        }
    }
}

@Composable
private fun CloudTip(
    step: Step,
    index: Int,
    count: Int,
    small: Boolean,
    contentAlpha: Float,
    onSkip: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val appearance = LocalRootedAppearance.current
    val p = appearance.canvas
    val ink = Color(0.10f, 0.16f, 0.11f)
    Column(
        modifier
            .graphicsLayer { alpha = contentAlpha }
            .padding(
                start = 30.dp, end = 30.dp,
                top = if (small) 74.dp else 82.dp,
                bottom = 26.dp,
            ),
    ) {
        Text(step.eyebrow, color = p.green, fontSize = 9.5.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(step.title, color = ink, fontSize = if (small) 18.sp else 20.sp, fontWeight = FontWeight.Light)
        Spacer(Modifier.height(5.dp))
        Text(
            step.body, color = ink.copy(alpha = 0.74f), fontSize = 12.sp, lineHeight = 16.sp,
            maxLines = 3, overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.weight(1f))
        // Slim progress bar.
        Box(
            Modifier.fillMaxWidth().height(3.dp)
                .background(ink.copy(alpha = 0.10f), RoundedCornerShape(2.dp)),
        ) {
            Box(
                Modifier.fillMaxWidth((index + 1) / count.toFloat()).height(3.dp)
                    .background(p.green, RoundedCornerShape(2.dp)),
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "SKIP", color = ink.copy(alpha = 0.5f), fontSize = 9.5.sp, letterSpacing = 1.4.sp,
                modifier = Modifier.noRippleClickable(onClick = onSkip).padding(vertical = 6.dp, horizontal = 2.dp),
            )
            Spacer(Modifier.weight(1f))
            Text(
                if (index >= count - 1) "LET'S GROW" else "NEXT",
                color = p.onAccent, fontSize = 10.sp, letterSpacing = 1.4.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .background(p.green, RoundedCornerShape(100.dp))
                    .rootedPressable(onClick = onNext)
                    .padding(horizontal = 20.dp, vertical = 10.dp),
            )
        }
    }
}
