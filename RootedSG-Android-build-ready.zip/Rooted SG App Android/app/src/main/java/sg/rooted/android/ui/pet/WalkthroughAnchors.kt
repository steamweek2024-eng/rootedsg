package sg.rooted.android.ui.pet

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned

/** Places in the shell the walkthrough can walk Mojo to and spotlight. */
enum class WalkTarget {
    TOP_LEVEL_PILL,
    ADD_BUTTON,
    MENU_BUTTON,
    HOME_HERO,
    HOME_DUE,
    SCREEN_HERO,   // the first title on whichever tab is showing — reused per tab
    MOJO_CARD,
}

/**
 * A tiny registry: composables tag themselves with [Modifier.walkAnchor] and
 * their on-screen bounds land here; [PetWalkthrough] reads them to position
 * Mojo and punch the spotlight. Cheap because [walkAnchor] is inert unless a
 * tour is actually running ([LocalWalkthroughActive]).
 */
class WalkthroughAnchors {
    val rects = mutableStateMapOf<WalkTarget, Rect>()
    fun report(target: WalkTarget, rect: Rect) {
        val existing = rects[target]
        if (existing == null || existing != rect) rects[target] = rect
    }
    fun clear(target: WalkTarget) { rects.remove(target) }
}

val LocalWalkthroughAnchors = compositionLocalOf { WalkthroughAnchors() }
val LocalWalkthroughActive = compositionLocalOf { false }

fun Modifier.walkAnchor(target: WalkTarget): Modifier = composed {
    val active = LocalWalkthroughActive.current
    val anchors = LocalWalkthroughAnchors.current
    if (!active) this
    else this.onGloballyPositioned { coords ->
        if (coords.isAttached) anchors.report(target, coords.boundsInRoot())
    }
}
