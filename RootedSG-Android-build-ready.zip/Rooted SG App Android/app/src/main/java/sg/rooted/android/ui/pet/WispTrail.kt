package sg.rooted.android.ui.pet

import androidx.compose.animation.core.EaseOutCubic
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color

/** One puff of vapour the drifting tour cloud leaves behind, in root-window pixels. */
data class Wisp(val x: Float, val y: Float, val radius: Float, val bornMs: Long)

/**
 * The fading trail the tour cloud draws as it drifts between elements — the
 * cloud-metaphor replacement for footprints. Soft white puffs that swell a
 * little and fade over ~1.5s.
 */
class WispField {
    val wisps = mutableStateListOf<Wisp>()

    /** Drop [count] puffs evenly along the segment, staggered so they appear in order. */
    fun emitAlong(from: Offset, to: Offset, count: Int, baseRadiusPx: Float, nowMs: Long) {
        if (count <= 0) return
        for (i in 0 until count) {
            val f = if (count == 1) 0.5f else i / (count - 1f)
            val jitter = ((i * 53) % 17 - 8).toFloat()
            wisps += Wisp(
                x = from.x + (to.x - from.x) * f + jitter,
                y = from.y + (to.y - from.y) * f + jitter * 0.6f,
                radius = baseRadiusPx * (0.8f + (i % 3) * 0.14f),
                bornMs = nowMs + (f * 220f).toLong(),
            )
        }
        if (wisps.size > MAX) while (wisps.size > MAX) wisps.removeAt(0)
    }

    fun prune(nowMs: Long) {
        wisps.removeAll { nowMs - it.bornMs > LIFE_MS }
    }

    companion object {
        const val LIFE_MS = 1500L
        private const val MAX = 60
    }
}

@Composable
fun WispLayer(field: WispField, modifier: Modifier = Modifier) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(field) {
        while (true) {
            withFrameNanos { }
            now = System.currentTimeMillis()
            field.prune(now)
        }
    }
    Canvas(modifier) {
        val life = WispField.LIFE_MS.toFloat()
        field.wisps.forEach { w ->
            val age = (now - w.bornMs).toFloat().coerceAtLeast(0f)
            val lifeFrac = (age / life).coerceIn(0f, 1f)
            val fade = 1f - EaseOutCubic.transform(lifeFrac)
            val alpha = 0.5f * fade * fade
            if (alpha <= 0.004f) return@forEach
            drawCircle(
                color = Color.White.copy(alpha = alpha),
                radius = w.radius * (1f + lifeFrac * 0.7f),
                center = Offset(w.x, w.y - lifeFrac * w.radius * 0.6f),
            )
        }
    }
}
