package sg.rooted.android.ui.profile

import android.app.Activity
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import sg.rooted.android.BuildConfig
import sg.rooted.android.RootedViewModel
import sg.rooted.android.account.AccountError
import sg.rooted.android.network.BackendClient
import sg.rooted.android.ui.common.GoogleSignInButton
import sg.rooted.android.ui.common.SheetHeader
import sg.rooted.android.ui.common.noRippleClickable
import sg.rooted.android.ui.theme.LocalRootedAppearance
import sg.rooted.android.ui.theme.RootedBackground
import sg.rooted.android.ui.theme.RootedMetrics

@Composable
fun ProfileScreen(
    viewModel: RootedViewModel,
    onClose: () -> Unit,
    onOpenTheme: () -> Unit,
    onOpenShop: () -> Unit,
    onOpenPet: () -> Unit = {},
) {
    val appearance = LocalRootedAppearance.current
    val p = appearance.canvas
    val user by viewModel.user.collectAsState()
    val account by viewModel.accountState.collectAsState()
    val plants by viewModel.plants.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var isSigningIn by remember { mutableStateOf(false) }
    var alertMessage by remember { mutableStateOf<String?>(null) }

    val totalDays = plants.sumOf { it.verifiedPlantDays }
    val bestStreak = plants.maxOfOrNull { it.careStreak } ?: 0
    val accountLinkConfigured = BackendClient.isConfigured && BuildConfig.GOOGLE_WEB_CLIENT_ID.isNotBlank()

    Column(Modifier.fillMaxSize().background(appearance.ground).safeDrawingPadding()) {
        SheetHeader(title = "Profile", onClose = onClose)

        LazyColumn(Modifier.fillMaxSize().padding(horizontal = (RootedMetrics.pagePadding + 8).dp)) {
            item {
                Row(Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(RootedMetrics.cardRadius.dp)).padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    val frame = user?.equippedFrame
                    Box(contentAlignment = Alignment.Center) {
                        if (frame != null) {
                            Box(
                                Modifier.size(52.dp).background(
                                    if (frame.colors.size > 1)
                                        androidx.compose.ui.graphics.Brush.sweepGradient(frame.colors + frame.colors[0])
                                    else androidx.compose.ui.graphics.SolidColor(frame.colors.firstOrNull() ?: frame.rarity.tint),
                                    CircleShape,
                                ),
                            )
                            Box(Modifier.size(46.dp).background(appearance.ground, CircleShape))
                        }
                        Text(user?.avatarEmoji ?: "🌱", fontSize = 36.sp)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(user?.name ?: "", color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                        user?.equippedTitle?.let { title ->
                            Text(
                                title.name.uppercase(), color = title.rarity.tint, fontSize = 9.5.sp, letterSpacing = 1.2.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.background(title.rarity.tint.copy(alpha = 0.14f), RoundedCornerShape(50.dp))
                                    .padding(horizontal = 8.dp, vertical = 2.dp),
                            )
                        }
                        Text("Level ${user?.level ?: 1} · ${user?.xp ?: 0} XP", color = p.secondary, fontSize = 13.sp)
                        if (!user?.school.isNullOrBlank()) Text(user?.school.orEmpty(), color = p.secondary, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(16.dp))

                // MARK: Account sync
                fun startSignIn() {
                    val activity = context as? Activity
                    if (activity == null) {
                        alertMessage = "Sign-in isn't available here."
                        return
                    }
                    isSigningIn = true
                    scope.launch {
                        try {
                            val newState = viewModel.account.signIn(activity)
                            val u = user
                            if (u != null) {
                                viewModel.garden.saveUser(u.copy(googleAccountId = newState.accountId ?: "", email = newState.email ?: ""))
                            }
                        } catch (e: AccountError.Cancelled) {
                            // User backed out — no message needed.
                        } catch (e: Exception) {
                            alertMessage = e.message ?: "Sign-in failed."
                        } finally {
                            isSigningIn = false
                        }
                    }
                }

                if (!accountLinkConfigured) {
                    Row(
                        Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(RootedMetrics.chipRadius.dp)).padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.size(36.dp).background(p.green.copy(alpha = 0.12f), CircleShape), contentAlignment = Alignment.Center) {
                            Text("🌱", fontSize = 18.sp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("Local-first mode", color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                            Text("Garden, quests, XP and local diagnosis work without an account. Cloud sync appears automatically when your backend + OAuth client are configured.", color = p.secondary, fontSize = 10.5.sp, lineHeight = 14.sp)
                        }
                    }
                } else AnimatedContent(
                    targetState = account.isSignedIn, label = "accountSync",
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                ) { signedIn ->
                    if (signedIn) {
                        Row(
                            Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(RootedMetrics.chipRadius.dp)).padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(Modifier.size(36.dp).background(p.green.copy(alpha = 0.16f), CircleShape), contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = p.green, modifier = Modifier.size(20.dp))
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(account.email ?: "Signed in", color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                Text("Syncing across devices", color = p.secondary, fontSize = 11.sp)
                            }
                            Text(
                                "SIGN OUT", color = p.alert, fontSize = 11.sp, letterSpacing = 1.sp, fontWeight = FontWeight.Medium,
                                modifier = Modifier.noRippleClickable { scope.launch { viewModel.account.signOut() } }.padding(8.dp),
                            )
                        }
                    } else {
                        Column {
                            GoogleSignInButton(
                                text = if (isSigningIn) "Signing in…" else "Sign in with Google",
                                isLoading = isSigningIn,
                                onClick = { if (!isSigningIn) startSignIn() },
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "Sync your listings, requests and chat across devices", color = p.secondary, fontSize = 11.sp,
                            )
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))

                Row(
                    Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(RootedMetrics.cardRadius.dp)).padding(18.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("$totalDays", color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Light)
                        Text(
                            "Verified Plant-Days", color = p.secondary, fontSize = 10.sp, lineHeight = 13.sp,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    Column(Modifier.weight(1f)) {
                        Text("${plants.size}", color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Light)
                        Text(
                            "Plants registered", color = p.secondary, fontSize = 10.sp, lineHeight = 13.sp,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    Column(Modifier.weight(1f)) {
                        Text("$bestStreak", color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Light)
                        Text(
                            "Best streak", color = p.secondary, fontSize = 10.sp, lineHeight = 13.sp,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))

                Text(
                    "MOJO", color = p.secondary, fontSize = 10.sp, letterSpacing = 1.6.sp,
                    modifier = Modifier.noRippleClickable(onClick = onOpenPet).padding(vertical = 8.dp),
                )
                Text(
                    "Your carrot's health, and replay the tour →", color = p.text, fontSize = 14.sp,
                    modifier = Modifier.noRippleClickable(onClick = onOpenPet).padding(vertical = 4.dp),
                )
                Spacer(Modifier.height(16.dp))

                Text(
                    "SHOP", color = p.secondary, fontSize = 10.sp, letterSpacing = 1.6.sp,
                    modifier = Modifier.noRippleClickable(onClick = onOpenShop).padding(vertical = 8.dp),
                )
                Text(
                    "🌱 ${user?.seeds ?: 0} seeds · ${user?.ownedItemIds?.size ?: 0} owned →", color = p.text, fontSize = 14.sp,
                    modifier = Modifier.noRippleClickable(onClick = onOpenShop).padding(vertical = 4.dp),
                )
                Spacer(Modifier.height(16.dp))

                Text(
                    "THEME", color = p.secondary, fontSize = 10.sp, letterSpacing = 1.6.sp,
                    modifier = Modifier.noRippleClickable(onClick = onOpenTheme).padding(vertical = 8.dp),
                )
                Text(
                    "Choose your theme →", color = p.text, fontSize = 14.sp,
                    modifier = Modifier.noRippleClickable(onClick = onOpenTheme).padding(vertical = 4.dp),
                )
                Spacer(Modifier.height(24.dp))
            }
        }
    }

    alertMessage?.let { message ->
        AlertDialog(
            onDismissRequest = { alertMessage = null },
            confirmButton = { TextButton(onClick = { alertMessage = null }) { Text("OK") } },
            title = { Text("Google Sign-In") },
            text = { Text(message) },
        )
    }
}
