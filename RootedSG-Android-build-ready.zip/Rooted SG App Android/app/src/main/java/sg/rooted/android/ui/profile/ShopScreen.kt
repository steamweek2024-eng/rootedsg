package sg.rooted.android.ui.profile

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import sg.rooted.android.RootedViewModel
import sg.rooted.android.engine.ShopCatalog
import sg.rooted.android.engine.ShopCategory
import sg.rooted.android.engine.ShopItem
import sg.rooted.android.model.UserProfile
import sg.rooted.android.ui.common.SheetHeader
import sg.rooted.android.ui.common.rootedPressable
import sg.rooted.android.ui.theme.LocalRootedAppearance
import sg.rooted.android.ui.theme.RootedBackground
import sg.rooted.android.ui.theme.RootedMetrics

/**
 * Cosmetics, bought with Seeds — a Compose port of ShopView.swift. Seeds are
 * earned exclusively by the same real, verified actions that pay XP; there's
 * no way to buy them with money. Nothing purchasable here ever touches a
 * plant's real stage, health or Verified Plant-Days — only how the profile
 * carrying that real progress looks.
 */
@Composable
fun ShopScreen(viewModel: RootedViewModel, onClose: () -> Unit) {
    val user by viewModel.user.collectAsState()
    val scope = rememberCoroutineScope()

    var category by remember { mutableStateOf(ShopCategory.TITLE) }
    var justPurchasedId by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().background(LocalRootedAppearance.current.ground).safeDrawingPadding()) {
        SheetHeader(title = "Shop", onClose = onClose)

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize().padding(horizontal = (RootedMetrics.pagePadding + 8).dp),
            contentPadding = PaddingValues(bottom = 40.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) { WalletCard(seeds = user?.seeds ?: 0) }
            item(span = { GridItemSpan(maxLineSpan) }) {
                CategoryPicker(selected = category, onSelect = { category = it })
            }
            items(ShopCatalog.items(category), key = { it.id }) { shopItem ->
                ShopItemCard(
                    item = shopItem, user = user, justPurchased = justPurchasedId == shopItem.id,
                    onBuy = {
                        val u = user ?: return@ShopItemCard
                        scope.launch {
                            val updated = viewModel.garden.purchase(u, shopItem)
                            if (updated != null) {
                                justPurchasedId = shopItem.id
                                delay(700)
                                if (justPurchasedId == shopItem.id) justPurchasedId = null
                            }
                        }
                    },
                    onEquip = {
                        val u = user ?: return@ShopItemCard
                        scope.launch { viewModel.garden.equip(u, shopItem) }
                    },
                )
            }
        }
    }
}

@Composable
private fun WalletCard(seeds: Int) {
    val p = LocalRootedAppearance.current.canvas
    Row(
        Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(RootedMetrics.cardRadius.dp)).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(52.dp).background(p.green.copy(alpha = 0.14f), CircleShape), contentAlignment = Alignment.Center) {
            Text("🌱", fontSize = 24.sp)
        }
        Spacer(Modifier.width(14.dp))
        Column {
            Text("$seeds", color = p.text, fontSize = 26.sp, fontWeight = FontWeight.Light)
            Text("SEEDS", color = p.secondary, fontSize = 10.sp, letterSpacing = 1.6.sp)
        }
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.End) {
            Text("Earned, never bought", color = p.green, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(
                "Every seed comes from real, verified care.", color = p.secondary, fontSize = 10.sp,
                textAlign = TextAlign.End, modifier = Modifier.widthIn(max = 130.dp),
            )
        }
    }
}

@Composable
private fun CategoryPicker(selected: ShopCategory, onSelect: (ShopCategory) -> Unit) {
    val p = LocalRootedAppearance.current.canvas
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ShopCategory.values().forEach { cat ->
            val active = cat == selected
            Row(
                Modifier.weight(1f)
                    .background(if (active) p.green else p.text.copy(alpha = 0.10f), RoundedCornerShape(RootedMetrics.buttonRadius.dp))
                    .rootedPressable(haptic = false) { onSelect(cat) }
                    .padding(vertical = 9.dp),
                horizontalArrangement = Arrangement.Center,
            ) {
                Text(cat.label, color = if (active) Color.White else p.text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ShopItemCard(
    item: ShopItem, user: UserProfile?, justPurchased: Boolean,
    onBuy: () -> Unit, onEquip: () -> Unit,
) {
    val p = LocalRootedAppearance.current.canvas
    val owned = user?.owns(item) == true
    val equipped = when (item.category) {
        ShopCategory.TITLE -> user?.equippedTitleId == item.id
        ShopCategory.FRAME -> user?.equippedFrameId == item.id
        ShopCategory.POT_SKIN -> user?.equippedPotSkinId == item.id
    }
    val affordable = (user?.seeds ?: 0) >= item.price
    val scale by androidx.compose.animation.core.animateFloatAsState(if (justPurchased) 1.06f else 1f, label = "purchaseScale")

    Column(
        Modifier
            .scale(scale)
            .background(p.faintFill, RoundedCornerShape(RootedMetrics.chipRadius.dp))
            .border(
                if (equipped) 1.75.dp else 1.dp,
                if (equipped) item.rarity.tint else p.rule,
                RoundedCornerShape(RootedMetrics.chipRadius.dp),
            )
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        ShopItemPreview(item = item, avatarEmoji = user?.avatarEmoji ?: "🌱")
        Spacer(Modifier.height(10.dp))
        Text(
            item.rarity.label.uppercase(), color = if (equipped) Color.White else item.rarity.tint, fontSize = 9.sp,
            fontWeight = FontWeight.Bold, letterSpacing = 1.sp,
            modifier = Modifier.background(if (equipped) item.rarity.tint else item.rarity.tint.copy(alpha = 0.14f), RoundedCornerShape(50.dp))
                .padding(horizontal = 10.dp, vertical = 3.dp),
        )
        Spacer(Modifier.height(6.dp))
        Text(item.name, color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(
            item.detail, color = p.secondary, fontSize = 10.sp, textAlign = TextAlign.Center, maxLines = 2,
            modifier = Modifier.height(26.dp),
        )
        Spacer(Modifier.height(8.dp))
        when {
            equipped -> Row(
                Modifier.background(item.rarity.tint.copy(alpha = 0.14f), RoundedCornerShape(50.dp)).padding(horizontal = 12.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("✓ EQUIPPED", color = item.rarity.tint, fontSize = 9.5.sp, letterSpacing = 1.sp, fontWeight = FontWeight.Bold)
            }
            owned -> Text(
                "Equip", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.background(p.text, RoundedCornerShape(50.dp))
                    .rootedPressable(haptic = false, onClick = onEquip)
                    .padding(horizontal = 16.dp, vertical = 7.dp),
            )
            affordable -> Row(
                Modifier.background(item.rarity.tint, RoundedCornerShape(50.dp))
                    .rootedPressable(haptic = false, onClick = onBuy)
                    .padding(horizontal = 14.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("🌱 ${item.price}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            else -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "🔒 ${item.price - (user?.seeds ?: 0)} more", color = p.secondary, fontSize = 10.sp, fontWeight = FontWeight.Medium,
                )
                Spacer(Modifier.height(4.dp))
                val fraction = ((user?.seeds ?: 0).toFloat() / item.price.toFloat()).coerceIn(0f, 1f)
                Box(Modifier.width(70.dp).height(4.dp).background(p.rule, RoundedCornerShape(2.dp))) {
                    Box(Modifier.fillMaxHeight().fillMaxWidth(fraction).background(item.rarity.tint, RoundedCornerShape(2.dp)))
                }
            }
        }
    }
}

@Composable
private fun ShopItemPreview(item: ShopItem, avatarEmoji: String) {
    val appearance = LocalRootedAppearance.current
    Box(Modifier.height(64.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
        when (item.category) {
            ShopCategory.TITLE -> Text(
                item.name, color = item.rarity.tint, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                modifier = Modifier.fillMaxWidth()
                    .background(item.rarity.tint.copy(alpha = 0.10f), RoundedCornerShape(RootedMetrics.chipRadius.dp))
                    .padding(horizontal = 10.dp, vertical = 22.dp),
                textAlign = TextAlign.Center,
            )
            ShopCategory.FRAME -> Box(contentAlignment = Alignment.Center) {
                Box(
                    Modifier.size(56.dp).background(
                        if (item.colors.size > 1) Brush.sweepGradient(item.colors + item.colors[0])
                        else SolidColor(item.colors.firstOrNull() ?: item.rarity.tint),
                        CircleShape,
                    ),
                )
                Box(Modifier.size(48.dp).background(appearance.ground, CircleShape))
                Text(avatarEmoji, fontSize = 22.sp)
            }
            ShopCategory.POT_SKIN -> {
                val colors = item.colors
                Box(Modifier.size(62.dp, 46.dp)) {
                    Canvas(Modifier.size(58.dp, 40.dp).align(Alignment.BottomCenter)) {
                        val topWidth = size.width
                        val bottomWidth = size.width * 0.74f
                        val path = Path().apply {
                            moveTo(size.width / 2 - topWidth / 2, 0f)
                            lineTo(size.width / 2 + topWidth / 2, 0f)
                            lineTo(size.width / 2 + bottomWidth / 2, size.height)
                            quadraticBezierTo(size.width / 2, size.height + 6f, size.width / 2 - bottomWidth / 2, size.height)
                            close()
                        }
                        drawPath(
                            path,
                            brush = Brush.verticalGradient(
                                listOf(colors.getOrElse(0) { item.rarity.tint }, colors.getOrElse(1) { item.rarity.tint }),
                            ),
                        )
                    }
                    Box(
                        Modifier.align(Alignment.TopCenter).width(62.dp).height(7.dp)
                            .background(colors.getOrElse(2) { item.rarity.tint }, RoundedCornerShape(3.dp)),
                    )
                }
            }
        }
    }
}
