package sg.rooted.android.ui.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import sg.rooted.android.ui.common.SheetHeader
import sg.rooted.android.ui.common.noRippleClickable
import sg.rooted.android.ui.theme.LocalRootedAppearance
import sg.rooted.android.ui.theme.RootedAppearanceMode
import sg.rooted.android.ui.theme.RootedBackground
import sg.rooted.android.ui.theme.RootedMetrics
import sg.rooted.android.ui.theme.RootedThemes
import sg.rooted.android.ui.theme.ThemeStore

@Composable
fun ThemePickerScreen(themeStore: ThemeStore, onClose: () -> Unit) {
    val appearance = LocalRootedAppearance.current
    val p = appearance.canvas

    Column(Modifier.fillMaxSize().background(appearance.ground).safeDrawingPadding()) {
        SheetHeader(title = "Theme", onClose = onClose)

        Column(Modifier.fillMaxSize().padding(horizontal = (RootedMetrics.pagePadding + 8).dp)) {
            Text("APPEARANCE", color = p.secondary, fontSize = 10.sp, letterSpacing = 1.6.sp)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RootedAppearanceMode.entries.forEach { mode ->
                    val selected = mode == themeStore.appearanceMode
                    Text(
                        mode.label, fontSize = 13.sp, color = if (selected) p.onAccent else p.text,
                        modifier = Modifier
                            .background(if (selected) p.green else p.faintFill, RoundedCornerShape(RootedMetrics.buttonRadius.dp))
                            .noRippleClickable { themeStore.setAppearance(mode) }
                            .padding(horizontal = 16.dp, vertical = 9.dp),
                    )
                }
            }

            Spacer(Modifier.height(28.dp))
            Text("THEME", color = p.secondary, fontSize = 10.sp, letterSpacing = 1.6.sp)
            Spacer(Modifier.height(10.dp))

            RootedThemes.all.forEach { theme ->
                val selected = theme.id == themeStore.themeId
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(if (selected) p.faintFill else androidx.compose.ui.graphics.Color.Transparent, RoundedCornerShape(RootedMetrics.chipRadius.dp))
                        .noRippleClickable { themeStore.select(theme.id) }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Row {
                        theme.swatch.forEach { color ->
                            Box(Modifier.size(20.dp).background(color, CircleShape).padding(2.dp))
                            Spacer(Modifier.width(4.dp))
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(theme.themeName, color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        Text(theme.blurb, color = p.secondary, fontSize = 11.sp)
                    }
                    if (selected) Text("✓", color = p.green, fontSize = 16.sp)
                }
                Spacer(Modifier.height(4.dp))
            }
        }
    }
}
