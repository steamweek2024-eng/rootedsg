package sg.rooted.android.ui.progress

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import sg.rooted.android.RootedViewModel
import sg.rooted.android.engine.Achievement
import sg.rooted.android.engine.AchievementEngine
import sg.rooted.android.engine.MojoEngine
import sg.rooted.android.engine.MojoMood
import sg.rooted.android.engine.PetVitals
import sg.rooted.android.model.UserProfile
import sg.rooted.android.model.XPEvent
import sg.rooted.android.ui.common.SheetHeader
import sg.rooted.android.ui.pet.MojoSprite
import sg.rooted.android.ui.common.rootedPressable
import sg.rooted.android.ui.theme.CountingNumber
import sg.rooted.android.ui.theme.LocalRootedAppearance
import sg.rooted.android.ui.theme.RootedBackground
import sg.rooted.android.ui.theme.RootedMetrics
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.max

/**
 * The Level pill's own destination — a Compose port of PlayerProgressView.swift.
 * Deliberately dense rather than a bare ring-and-list: a source breakdown, a
 * best-day callout and day-grouped history all read straight off the same
 * XPEvent ledger already on device — nothing here is invented, and nothing
 * adds a new tap. Scroll is still the only gesture this screen asks for.
 */
@Composable
fun ProgressScreen(viewModel: RootedViewModel, onClose: () -> Unit, onOpenShop: () -> Unit) {
    val user by viewModel.user.collectAsState()
    val events by viewModel.recentXPEvents.collectAsState()
    val allEvents by viewModel.allXPEvents.collectAsState()
    val xpThisWeek by viewModel.xpThisWeek.collectAsState()
    val vitals by viewModel.petVitals.collectAsState()
    val petName by viewModel.petName.collectAsState()
    val plants by viewModel.plants.collectAsState()
    val quests by viewModel.quests.collectAsState()
    val diagnosisSessions by viewModel.diagnosisSessions.collectAsState()
    val p = LocalRootedAppearance.current.canvas

    val achievements = AchievementEngine.evaluate(user, plants, quests, diagnosisSessions)
    val bestDay = bestDayOf(allEvents)
    val groups = groupByWhen(events)

    Column(Modifier.fillMaxSize().background(LocalRootedAppearance.current.ground).safeDrawingPadding()) {
        SheetHeader(title = "Progress", onClose = onClose)

        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = (RootedMetrics.pagePadding + 8).dp),
            contentPadding = PaddingValues(bottom = 40.dp),
        ) {
            item { Spacer(Modifier.height(4.dp)); MojoProgressHeader(vitals, petName, user?.level ?: 1) }
            item { Spacer(Modifier.height(12.dp)); LevelCard(user) }
            item { Spacer(Modifier.height(16.dp)); StatsRow(user, xpThisWeek) }
            if (bestDay != null) {
                item { Spacer(Modifier.height(16.dp)); BestDayCallout(bestDay) }
            }
            item { Spacer(Modifier.height(20.dp)); AchievementSection(achievements) }
            item { Spacer(Modifier.height(16.dp)); ShopTeaser(onClick = onOpenShop) }
            item { Spacer(Modifier.height(20.dp)); SourceBreakdown(allEvents) }
            item {
                Spacer(Modifier.height(24.dp))
                Text("RECENT ACTIVITY", color = p.green, fontSize = 9.5.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
            }
            if (events.isEmpty()) {
                item {
                    Text(
                        "Register a plant or check in to start earning XP.",
                        color = p.secondary, fontSize = 14.sp,
                    )
                }
            } else {
                groups.forEach { group ->
                    item {
                        Spacer(Modifier.height(14.dp))
                        Text(group.label.uppercase(), color = p.secondary, fontSize = 9.sp, letterSpacing = 1.4.sp)
                        Spacer(Modifier.height(2.dp))
                    }
                    itemsIndexed(group.events) { index, event ->
                        ActivityRow(event)
                        if (index < group.events.size - 1) {
                            Box(Modifier.fillMaxWidth().height(1.dp).background(p.rule))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AchievementSection(achievements: List<Achievement>) {
    val p = LocalRootedAppearance.current.canvas
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("ACHIEVEMENTS", color = p.green, fontSize = 9.5.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("${achievements.count { it.unlocked }}/${achievements.size} UNLOCKED", color = p.secondary, fontSize = 9.sp, letterSpacing = 1.sp)
        }
        Spacer(Modifier.height(10.dp))
        achievements.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { achievement ->
                    AchievementCard(achievement, Modifier.weight(1f))
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun AchievementCard(achievement: Achievement, modifier: Modifier = Modifier) {
    val p = LocalRootedAppearance.current.canvas
    val tint = if (achievement.unlocked) p.green else p.secondary
    Column(
        modifier.background(
            if (achievement.unlocked) p.green.copy(alpha = 0.10f) else p.faintFill,
            RoundedCornerShape(RootedMetrics.cardRadius.dp),
        ).padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(achievement.emoji, fontSize = 22.sp)
            Spacer(Modifier.weight(1f))
            if (achievement.unlocked) {
                Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = p.green, modifier = Modifier.size(16.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(achievement.title, color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(2.dp))
        Text(achievement.detail, color = p.secondary, fontSize = 10.5.sp, lineHeight = 14.sp, maxLines = 3)
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth().height(5.dp).background(p.rule, RoundedCornerShape(99.dp))) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(achievement.fraction).background(tint, RoundedCornerShape(99.dp)))
        }
        Spacer(Modifier.height(5.dp))
        Text(
            if (achievement.unlocked) "UNLOCKED" else "${achievement.progress.coerceAtMost(achievement.target)}/${achievement.target}",
            color = tint, fontSize = 8.5.sp, letterSpacing = 1.sp, fontWeight = FontWeight.Bold,
        )
    }
}

@Composable
private fun LevelCard(user: UserProfile?) {
    val p = LocalRootedAppearance.current.canvas
    val level = user?.level ?: 1
    val xpInto = user?.xpIntoCurrentLevel ?: 0
    val xpSpan = (user?.xpForNextLevel ?: 1).coerceAtLeast(1)
    val fraction = (xpInto.toFloat() / xpSpan.toFloat()).coerceIn(0.02f, 1f)
    val title = user?.equippedTitle

    Column(
        Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(RootedMetrics.cardRadius.dp)).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(136.dp), contentAlignment = Alignment.Center) {
            androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                val stroke = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
                // Quarter tick marks — an instrument-panel touch that costs nothing to read.
                val radius = size.minDimension / 2
                for (i in 0 until 4) {
                    val angle = Math.toRadians((i * 90 - 90).toDouble())
                    val inner = radius - 2.dp.toPx()
                    val outer = radius + 2.dp.toPx()
                    drawLine(
                        color = p.secondary.copy(alpha = 0.4f),
                        start = center + androidx.compose.ui.geometry.Offset(
                            (inner * Math.cos(angle)).toFloat(), (inner * Math.sin(angle)).toFloat(),
                        ),
                        end = center + androidx.compose.ui.geometry.Offset(
                            (outer * Math.cos(angle)).toFloat(), (outer * Math.sin(angle)).toFloat(),
                        ),
                        strokeWidth = 2.dp.toPx(),
                    )
                }
                drawArc(
                    color = p.secondary.copy(alpha = 0.18f), startAngle = -90f, sweepAngle = 360f,
                    useCenter = false, style = stroke,
                )
                drawArc(
                    color = p.green, startAngle = -90f, sweepAngle = 360f * fraction,
                    useCenter = false, style = stroke,
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("LEVEL", color = p.secondary, fontSize = 9.sp, letterSpacing = 1.6.sp)
                CountingNumber(value = level, fontSize = 44.sp, color = p.text, fontWeight = FontWeight.Light)
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            CountingNumber(value = xpInto, fontSize = 14.sp, color = p.text, fontWeight = FontWeight.Bold)
            Text(" / $xpSpan XP", color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        Text(
            "${max(0, xpSpan - xpInto)} XP to Level ${level + 1}",
            color = p.secondary, fontSize = 12.sp,
        )
        if (title != null) {
            Spacer(Modifier.height(10.dp))
            Text(
                title.name.uppercase(), color = title.rarity.tint, fontSize = 9.5.sp, letterSpacing = 1.2.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.background(title.rarity.tint.copy(alpha = 0.14f), RoundedCornerShape(50.dp))
                    .padding(horizontal = 12.dp, vertical = 5.dp),
            )
        }
    }
}

@Composable
private fun StatsRow(user: UserProfile?, xpThisWeek: Int) {
    val p = LocalRootedAppearance.current.canvas
    Row(
        Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(RootedMetrics.cardRadius.dp)).padding(18.dp),
    ) {
        StatFigure(Modifier.weight(1f), user?.xp ?: 0, "Total XP", p.text)
        Box(Modifier.width(1.dp).height(34.dp).background(p.rule).align(Alignment.CenterVertically))
        StatFigure(Modifier.weight(1f), xpThisWeek, "This week", p.green)
        Box(Modifier.width(1.dp).height(34.dp).background(p.rule).align(Alignment.CenterVertically))
        StatFigure(Modifier.weight(1f), user?.seeds ?: 0, "Seeds", p.text)
    }
}

@Composable
private fun StatFigure(modifier: Modifier, value: Int, caption: String, tint: Color) {
    val p = LocalRootedAppearance.current.canvas
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        CountingNumber(value = value, fontSize = 22.sp, color = tint, fontWeight = FontWeight.Light)
        Text(caption.uppercase(), color = p.secondary, fontSize = 9.sp, letterSpacing = 1.2.sp)
    }
}

// MARK: Best day — real, computed from the ledger, never invented.

private data class BestDay(val date: Date, val total: Int)

private fun bestDayOf(events: List<XPEvent>): BestDay? {
    if (events.isEmpty()) return null
    val byDay = events.groupBy { startOfDay(it.date) }
    if (byDay.size <= 1) return null // not interesting with only one day of history
    val (day, dayEvents) = byDay.maxByOrNull { (_, v) -> v.sumOf { it.amount } } ?: return null
    return BestDay(Date(day), dayEvents.sumOf { it.amount })
}

private fun startOfDay(epochMs: Long): Long {
    val cal = Calendar.getInstance().apply {
        timeInMillis = epochMs
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }
    return cal.timeInMillis
}

@Composable
private fun BestDayCallout(best: BestDay) {
    val p = LocalRootedAppearance.current.canvas
    Row(
        Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(RootedMetrics.cardRadius.dp)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(38.dp).background(Color(0xFFE0A94A).copy(alpha = 0.18f), CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.EmojiEvents, contentDescription = null, tint = Color(0xFFB8860B), modifier = Modifier.size(16.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text("Best day: ${best.total} XP", color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(
                SimpleDateFormat("d MMMM", Locale.getDefault()).format(best.date),
                color = p.secondary, fontSize = 11.sp,
            )
        }
    }
}

@Composable
private fun ShopTeaser(onClick: () -> Unit) {
    val p = LocalRootedAppearance.current.canvas
    Row(
        Modifier.fillMaxWidth()
            .background(p.faintFill, RoundedCornerShape(RootedMetrics.cardRadius.dp))
            .rootedPressable(haptic = false, onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(44.dp).background(p.green.copy(alpha = 0.14f), CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.ShoppingBag, contentDescription = null, tint = p.green, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("Spend your Seeds", color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text("Titles, frames and pot skins in the Shop", color = p.secondary, fontSize = 11.sp)
        }
        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = p.secondary, modifier = Modifier.size(16.dp))
    }
}

// MARK: Source breakdown — every XP event ever logged, bucketed by what earned it.

private enum class XPCategory(val label: String) {
    CARE("Check-ins"), MILESTONE("Milestones"), QUEST("Quests"), BIODEX("BioDex"), OTHER("Other");

    val tint: Color
        @Composable get() {
            val p = LocalRootedAppearance.current.canvas
            return when (this) {
                CARE -> p.green
                MILESTONE -> Color(0xFFCB8A3E)
                QUEST -> Color(0xFF4C8CB0)
                BIODEX -> Color(0xFF9B6FB0)
                OTHER -> p.text
            }
        }

    companion object {
        fun classify(icon: String): XPCategory = when (icon) {
            "checkmark.seal.fill" -> CARE
            "star.fill" -> MILESTONE
            "drop.fill", "cross.case.fill", "person.3.fill" -> QUEST
            "binoculars.fill" -> BIODEX
            else -> OTHER
        }
    }
}

@Composable
private fun SourceBreakdown(allEvents: List<XPEvent>) {
    val p = LocalRootedAppearance.current.canvas
    val totals = XPCategory.values().mapNotNull { cat ->
        val sum = allEvents.filter { XPCategory.classify(it.icon) == cat }.sumOf { it.amount }
        if (sum > 0) cat to sum else null
    }.sortedByDescending { it.second }
    val grandTotal = max(1, totals.sumOf { it.second })

    Column(
        Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(RootedMetrics.cardRadius.dp)).padding(18.dp),
    ) {
        Text("XP BY SOURCE", color = p.green, fontSize = 9.5.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        if (totals.isEmpty()) {
            Text("Nothing earned yet.", color = p.secondary, fontSize = 13.sp)
        } else {
            Row(Modifier.fillMaxWidth().height(10.dp)) {
                totals.forEach { (cat, total) ->
                    Box(
                        Modifier.fillMaxHeight().weight(total.toFloat() / grandTotal.toFloat())
                            .padding(end = 2.dp)
                            .background(cat.tint, RoundedCornerShape(4.dp)),
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                totals.forEach { (cat, total) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(7.dp).background(cat.tint, CircleShape))
                        Spacer(Modifier.width(8.dp))
                        Text(cat.label, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.weight(1f))
                        Text("$total XP", color = p.secondary, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

// MARK: Activity — grouped by when, not just a flat list.

private data class EventGroup(val label: String, val events: List<XPEvent>)

private fun groupByWhen(events: List<XPEvent>): List<EventGroup> {
    val now = Calendar.getInstance()
    val todayStart = startOfDay(now.timeInMillis)
    val yesterdayStart = todayStart - TimeUnit.DAYS.toMillis(1)
    val weekStart = todayStart - TimeUnit.DAYS.toMillis(7)

    val groups = mutableListOf<EventGroup>()
    for (event in events) {
        val label = when {
            event.date >= todayStart -> "Today"
            event.date >= yesterdayStart -> "Yesterday"
            event.date >= weekStart -> "This week"
            else -> "Earlier"
        }
        if (groups.isNotEmpty() && groups.last().label == label) {
            val last = groups.removeAt(groups.size - 1)
            groups.add(EventGroup(label, last.events + event))
        } else {
            groups.add(EventGroup(label, listOf(event)))
        }
    }
    return groups
}

@Composable
private fun ActivityRow(event: XPEvent) {
    val p = LocalRootedAppearance.current.canvas
    val tint = XPCategory.classify(event.icon).tint
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(32.dp).background(tint.copy(alpha = 0.14f), CircleShape), contentAlignment = Alignment.Center) {
            Icon(xpEventIcon(event.icon), contentDescription = null, tint = tint, modifier = Modifier.size(15.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(event.reason, color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            Text(relativeTime(event.date), color = p.secondary, fontSize = 11.sp)
        }
        Text("+${event.amount}", color = p.green, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

/** Maps iOS's SF-Symbol-style icon names to the closest Material icon, so both
 * platforms' XPEvent rows read from the same `icon` string. */
private fun xpEventIcon(name: String): ImageVector = when (name) {
    "leaf.fill" -> Icons.Filled.Eco
    "checkmark.seal.fill" -> Icons.Filled.VerifiedUser
    "star.fill" -> Icons.Filled.Star
    "drop.fill" -> Icons.Filled.WaterDrop
    "cross.case.fill" -> Icons.Filled.MedicalServices
    "person.3.fill" -> Icons.Filled.Groups
    "binoculars.fill" -> Icons.Filled.Visibility
    "sparkles" -> Icons.Filled.AutoAwesome
    "map.fill" -> Icons.Filled.Map
    "ladybug.fill" -> Icons.Filled.BugReport
    "graduationcap.fill" -> Icons.Filled.School
    else -> Icons.Filled.EmojiEvents
}

private fun relativeTime(epochMs: Long): String {
    val diff = System.currentTimeMillis() - epochMs
    val minutes = TimeUnit.MILLISECONDS.toMinutes(diff)
    val hours = TimeUnit.MILLISECONDS.toHours(diff)
    val days = TimeUnit.MILLISECONDS.toDays(diff)
    return when {
        minutes < 1 -> "Just now"
        minutes < 60 -> "$minutes min ago"
        hours < 24 -> "$hours hr${if (hours == 1L) "" else "s"} ago"
        days < 7 -> "$days day${if (days == 1L) "" else "s"} ago"
        else -> "${days / 7} week${if (days / 7 == 1L) "" else "s"} ago"
    }
}

@Composable
private fun MojoProgressHeader(vitals: PetVitals, petName: String, level: Int) {
    val p = LocalRootedAppearance.current.canvas
    val line = when (vitals.mood) {
        MojoMood.THRIVING -> "Level $level and thriving. I'm proud of you."
        MojoMood.HAPPY -> "Level $level, garden's happy. Keep it rolling."
        MojoMood.OKAY -> "Level $level. A check-in or two and we're flying."
        MojoMood.WORRIED -> "Level $level — but the garden needs a look."
        MojoMood.SAD -> "Level $level. Let's get a plant back on its feet."
    }
    Row(
        Modifier.fillMaxWidth().background(p.faintFill, RoundedCornerShape(RootedMetrics.cardRadius.dp)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        MojoSprite(anim = MojoEngine.restingAnim(vitals.mood), modifier = Modifier.size(52.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(petName.uppercase(), color = p.green, fontSize = 9.sp, letterSpacing = 1.6.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(3.dp))
            Text(line, color = p.text, fontSize = 13.sp, lineHeight = 17.sp)
        }
    }
}
