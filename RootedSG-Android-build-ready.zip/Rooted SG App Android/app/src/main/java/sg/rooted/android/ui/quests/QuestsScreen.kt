package sg.rooted.android.ui.quests

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import sg.rooted.android.RootedViewModel
import sg.rooted.android.model.Quest
import sg.rooted.android.model.QuestStatus
import sg.rooted.android.model.QuestType
import sg.rooted.android.ui.common.WeatherGlyphs
import sg.rooted.android.ui.common.rootedPressable
import sg.rooted.android.ui.pet.WalkTarget
import sg.rooted.android.ui.pet.walkAnchor
import sg.rooted.android.ui.theme.GreenBar
import sg.rooted.android.ui.theme.LocalRootedAppearance
import sg.rooted.android.ui.theme.PaperRule
import sg.rooted.android.ui.theme.RisesIn
import sg.rooted.android.ui.theme.RootedMetrics
import sg.rooted.android.ui.theme.RootedSurface
import sg.rooted.android.ui.theme.WhiteSheet
import sg.rooted.android.ui.theme.rootedPalette

@Composable
fun QuestsScreen(viewModel: RootedViewModel, onCheckIn: (String) -> Unit) {
    val canvas = LocalRootedAppearance.current.canvas
    val quests by viewModel.quests.collectAsState()
    val active = quests.filter { it.status == QuestStatus.ACTIVE }
    val completed = quests.filter { it.status == QuestStatus.COMPLETED }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = (RootedMetrics.pagePadding + 8).dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 120.dp),
    ) {
        item {
            RisesIn(index = 1) { m ->
                Column(m.walkAnchor(WalkTarget.SCREEN_HERO)) {
                    Text("ACTIVE", color = canvas.secondary, fontSize = 10.sp, letterSpacing = 1.6.sp)
                    Spacer(Modifier.height(10.dp))
                    if (active.isEmpty()) {
                        Text("No active quests.", color = canvas.secondary, fontSize = 13.sp)
                    } else {
                        WhiteSheet {
                            Column {
                                active.forEachIndexed { index, quest ->
                                    QuestRow(quest, onCheckIn)
                                    if (index < active.size - 1) PaperRule(Modifier.padding(vertical = 2.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        if (completed.isNotEmpty()) {
            item {
                Spacer(Modifier.height(18.dp))
                RisesIn(index = 2) { m ->
                    Column(m) {
                        Text("COMPLETED", color = canvas.secondary, fontSize = 10.sp, letterSpacing = 1.6.sp)
                        Spacer(Modifier.height(10.dp))
                        WhiteSheet {
                            Column {
                                completed.forEachIndexed { index, quest ->
                                    QuestRow(quest, onCheckIn)
                                    if (index < completed.size - 1) PaperRule(Modifier.padding(vertical = 2.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun questVisuals(type: QuestType, defaultTint: Color): Pair<ImageVector, Color> = when (type) {
    QuestType.CARE -> WeatherGlyphs.leaf to defaultTint
    QuestType.RECOVERY -> Icons.Filled.MedicalServices to Color(0xFFB0563E)
    QuestType.BIODIVERSITY -> Icons.Filled.BugReport to Color(0xFFCB8A3E)
    QuestType.EXPLORATION -> Icons.Filled.Map to Color(0xFF4C8CB0)
    QuestType.COMMUNITY -> Icons.Filled.Groups to Color(0xFFB05CA0)
    QuestType.SCHOOL -> Icons.Filled.School to defaultTint
}

@Composable
private fun QuestRow(quest: Quest, onCheckIn: (String) -> Unit) {
    val p = rootedPalette(RootedSurface.PAPER)
    val clickable = quest.status == QuestStatus.ACTIVE && quest.relatedPlantID != null
    val (icon, tint) = questVisuals(quest.type, p.green)
    Row(
        Modifier
            .fillMaxWidth()
            .let { if (clickable) it.rootedPressable(haptic = false) { onCheckIn(quest.relatedPlantID!!) } else it }
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Box(Modifier.size(32.dp).background(tint.copy(alpha = 0.14f), CircleShape), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(14.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(quest.title, color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Light, modifier = Modifier.weight(1f))
                Text("+${quest.rewardXP} XP", color = p.green, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }
            Spacer(Modifier.height(4.dp))
            if (quest.bossName.isNotBlank() && quest.status == QuestStatus.ACTIVE) {
                Text("🚨 BOSS EVENT · ${quest.bossName.uppercase()}", color = tint, fontSize = 9.sp, letterSpacing = 1.0.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
            }
            Text(quest.detail, color = p.secondary, fontSize = 12.sp)
            if (quest.objectives.isNotEmpty()) {
                Spacer(Modifier.height(9.dp))
                quest.objectives.take(3).forEach { objective ->
                    Row(Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (objective.isComplete) "✓" else "○", color = if (objective.isComplete) p.green else p.secondary, fontSize = 11.sp)
                        Spacer(Modifier.width(7.dp))
                        Text(objective.title, color = if (objective.isComplete) p.secondary else p.text, fontSize = 10.5.sp, maxLines = 1)
                    }
                }
                if (quest.requiresRecheck && quest.objectivesComplete && quest.status == QuestStatus.ACTIVE) {
                    Text("📸 Recovery recheck ready", color = p.green, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                GreenBar(fraction = quest.progressFraction, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(10.dp))
                Text("${quest.progress}/${quest.target}", color = p.secondary, fontSize = 11.sp)
            }
        }
    }
}
