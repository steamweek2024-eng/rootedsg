package sg.rooted.android.ui.root

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import kotlinx.coroutines.launch
import sg.rooted.android.RootedViewModel
import sg.rooted.android.model.QuestStatus
import sg.rooted.android.ui.Routes
import sg.rooted.android.ui.biodex.BioDexScreen
import sg.rooted.android.ui.common.noRippleClickable
import sg.rooted.android.ui.common.rootedPressable
import sg.rooted.android.ui.exchange.MarketScreen
import sg.rooted.android.ui.garden.GardenScreen
import sg.rooted.android.ui.home.HomeScreen
import sg.rooted.android.ui.pet.LocalWalkthroughActive
import sg.rooted.android.ui.pet.LocalWalkthroughAnchors
import sg.rooted.android.ui.pet.MojoReactionHost
import sg.rooted.android.ui.pet.PetWalkthrough
import sg.rooted.android.ui.pet.WalkTarget
import sg.rooted.android.ui.pet.WalkthroughAnchors
import sg.rooted.android.ui.pet.walkAnchor
import sg.rooted.android.ui.quests.QuestsScreen
import sg.rooted.android.ui.theme.LocalRootedAppearance
import sg.rooted.android.ui.theme.RootedBackground
import sg.rooted.android.ui.theme.RootedMetrics

enum class RootedTab(val title: String) {
    HOME("Today"), GARDEN("Garden"), MARKET("Market"), QUESTS("Quests"), BIODEX("BioDex"),
}

@Composable
fun RootShell(navController: NavHostController, viewModel: RootedViewModel, onOpenPet: () -> Unit = {}) {
    var tab by remember { mutableStateOf(RootedTab.HOME) }
    var showMenu by remember { mutableStateOf(false) }
    val plants by viewModel.plants.collectAsState()
    val quests by viewModel.quests.collectAsState()
    val sightings by viewModel.sightings.collectAsState()
    val user by viewModel.user.collectAsState()
    val hasSeenTutorial by viewModel.hasSeenTutorial.collectAsState()
    val petName by viewModel.petName.collectAsState()
    val scope = rememberCoroutineScope()

    val showWalkthrough = user != null && !hasSeenTutorial
    val anchors = remember { WalkthroughAnchors() }

    CompositionLocalProvider(
        LocalWalkthroughAnchors provides anchors,
        LocalWalkthroughActive provides showWalkthrough,
    ) {
    Box(Modifier.fillMaxSize()) {
        RootedBackground()
        Column(Modifier.fillMaxSize().safeDrawingPadding()) {
            RootedTopBar(
                tab = tab, viewModel = viewModel,
                onMenu = { showMenu = true }, onAdd = { navController.navigate(Routes.REGISTER) },
                onProgress = { navController.navigate(Routes.PROGRESS) },
            )
            Box(Modifier.weight(1f)) {
                Crossfade(targetState = tab, label = "tab") { current ->
                    when (current) {
                        RootedTab.HOME -> HomeScreen(
                            viewModel = viewModel,
                            onOpenPlant = { navController.navigate(Routes.plantDetail(it)) },
                            onCheckIn = { navController.navigate(Routes.checkIn(it)) },
                            onOpenTab = { tab = it },
                            onOpenPet = onOpenPet,
                        )
                        RootedTab.GARDEN -> GardenScreen(
                            viewModel = viewModel,
                            onOpenPlant = { navController.navigate(Routes.plantDetail(it)) },
                            onRegister = { navController.navigate(Routes.REGISTER) },
                        )
                        RootedTab.MARKET -> MarketScreen(
                            viewModel = viewModel,
                            onOpenListing = { navController.navigate(Routes.listingDetail(it)) },
                        )
                        RootedTab.QUESTS -> QuestsScreen(
                            viewModel = viewModel,
                            onCheckIn = { navController.navigate(Routes.checkIn(it)) },
                        )
                        RootedTab.BIODEX -> BioDexScreen(
                            viewModel = viewModel,
                            onLog = { navController.navigate(Routes.LOG_OBSERVATION) },
                        )
                    }
                }
            }
        }
        if (showMenu) {
            RootedMenuOverlay(
                selection = tab,
                plantsCount = plants.count { it.health != sg.rooted.android.model.HealthStatus.DECEASED },
                questsOpenCount = quests.count { it.status == QuestStatus.ACTIVE },
                sightingsCount = sightings.size,
                onSelectTab = { tab = it; showMenu = false },
                onClose = { showMenu = false },
                onProfile = { showMenu = false; navController.navigate(Routes.PROFILE) },
                onCommunity = { showMenu = false; navController.navigate(Routes.COMMUNITY) },
                onTheme = { showMenu = false; navController.navigate(Routes.THEME_PICKER) },
                onShop = { showMenu = false; navController.navigate(Routes.SHOP) },
            )
        }
        if (!showWalkthrough) {
            MojoReactionHost(petName = petName, onOpenPet = onOpenPet)
        }
        if (showWalkthrough) {
            PetWalkthrough(
                petName = petName,
                currentTab = tab,
                onSetTab = { tab = it },
                onFinish = { scope.launch { viewModel.setWalkthroughSeen(true) } },
            )
        }
    }
    }
}

@Composable
private fun RootedTopBar(tab: RootedTab, viewModel: RootedViewModel, onMenu: () -> Unit, onAdd: () -> Unit, onProgress: () -> Unit) {
    val appearance = LocalRootedAppearance.current
    val p = appearance.canvas
    val user by viewModel.user.collectAsState()
    // A Box, not one Row with a single weighted Spacer — that pattern only
    // centres the pill in whatever room is left after the label and the icon
    // buttons, which drifts it toward the side with less content. Centering
    // it in the bar's own full width (via Box's default centre alignment)
    // keeps it in the same place regardless of the tab name's length.
    Box(
        Modifier
            .fillMaxWidth()
            .background(appearance.ground)
            .padding(horizontal = (RootedMetrics.pagePadding + 8).dp)
            .padding(top = 14.dp, bottom = 12.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            // The wordmark made way for the Level/Seeds pill below — the tab name
            // alone is enough orientation once past onboarding.
            Text(tab.title.uppercase(), color = p.secondary, fontSize = 11.sp, letterSpacing = 2.sp, maxLines = 1)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onAdd, modifier = Modifier.walkAnchor(WalkTarget.ADD_BUTTON)) {
                Icon(Icons.Filled.Add, contentDescription = "Register a plant", tint = p.text)
            }
            IconButton(onClick = onMenu, modifier = Modifier.walkAnchor(WalkTarget.MENU_BUTTON)) {
                Icon(Icons.Filled.Menu, contentDescription = "Menu", tint = p.text)
            }
        }
        if (user != null) {
            LevelSeedsPill(
                user = user!!, onClick = onProgress,
                modifier = Modifier.align(Alignment.Center).walkAnchor(WalkTarget.TOP_LEVEL_PILL),
            )
        }
    }
}

/** The top bar's Level + Seeds readout — a Compose port of RootedTopBar's LevelPill,
 * small on purpose but always tappable straight into the player's own Progress
 * screen (not the Shop — that's one tap further, reached from there). */
@Composable
private fun LevelSeedsPill(user: sg.rooted.android.model.UserProfile, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val appearance = LocalRootedAppearance.current
    val p = appearance.canvas
    Row(
        modifier
            .border(1.dp, p.rule, RoundedCornerShape(RootedMetrics.buttonRadius.dp))
            .background(p.text.copy(alpha = 0.045f), RoundedCornerShape(RootedMetrics.buttonRadius.dp))
            .rootedPressable(haptic = false, onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("LV ${user.level}", color = p.text, fontSize = 9.5.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Box(Modifier.padding(horizontal = 7.dp).width(1.dp).height(10.dp).background(p.rule))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("🌱", fontSize = 11.sp)
            Spacer(Modifier.width(3.dp))
            Text("${user.seeds}", color = p.green, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

@Composable
private fun RootedMenuOverlay(
    selection: RootedTab, plantsCount: Int, questsOpenCount: Int, sightingsCount: Int,
    onSelectTab: (RootedTab) -> Unit, onClose: () -> Unit,
    onProfile: () -> Unit, onCommunity: () -> Unit, onTheme: () -> Unit, onShop: () -> Unit,
) {
    val appearance = LocalRootedAppearance.current
    val p = appearance.canvas

    fun detail(tab: RootedTab): String = when (tab) {
        RootedTab.HOME -> "Today's check-ins and your running count"
        RootedTab.GARDEN -> "$plantsCount plant${if (plantsCount == 1) "" else "s"} on the register"
        RootedTab.MARKET -> "Offer produce, or ask a neighbour to grow it"
        RootedTab.QUESTS -> "$questsOpenCount open"
        RootedTab.BIODEX -> "$sightingsCount species recorded"
    }

    Box(Modifier.fillMaxSize().background(appearance.ground)) {
        Column(Modifier.fillMaxSize().safeDrawingPadding().padding(horizontal = (RootedMetrics.pagePadding + 8).dp).padding(top = 20.dp, bottom = 26.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("INDEX", color = p.secondary, fontSize = 11.sp, letterSpacing = 2.4.sp)
                Spacer(Modifier.weight(1f))
                Text("✕", color = p.text, fontSize = 18.sp, modifier = Modifier.noRippleClickable(onClick = onClose).padding(8.dp))
            }
            Spacer(Modifier.height(20.dp))

            RootedTab.values().forEachIndexed { index, tab ->
                sg.rooted.android.ui.theme.RisesIn(index = index, delayStepMs = 45L) { m ->
                    Column(
                        m.fillMaxWidth().rootedPressable(haptic = false) { onSelectTab(tab) }.padding(vertical = 13.dp),
                    ) {
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text("%02d".format(index + 1), color = p.secondary.copy(alpha = 0.7f), fontSize = 10.sp)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(
                                    tab.title, color = if (selection == tab) p.green else p.text,
                                    fontSize = 32.sp, fontWeight = FontWeight.Light,
                                )
                                Text(detail(tab), color = p.secondary, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }

            Box(Modifier.fillMaxWidth().padding(vertical = 20.dp).height(1.dp).background(p.rule))

            sg.rooted.android.ui.theme.RisesIn(index = RootedTab.values().size, delayStepMs = 45L) { m ->
                Row(m, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MenuChip("Profile", p.text, p.rule, onProfile)
                    MenuChip("Singapore", p.text, p.rule, onCommunity)
                    MenuChip("Theme", p.text, p.rule, onTheme)
                }
            }
            sg.rooted.android.ui.theme.RisesIn(index = RootedTab.values().size + 1, delayStepMs = 45L) { m ->
                Row(m.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MenuChip("Shop", p.text, p.rule, onShop)
                }
            }

            Spacer(Modifier.weight(1f))
            Text(
                "Don't count what we plant. Count what we keep alive.",
                color = p.secondary, fontSize = 13.sp,
            )
        }
    }
}

@Composable
private fun MenuChip(label: String, textColor: Color, ruleColor: Color, onClick: () -> Unit) {
    Text(
        label.uppercase(), color = textColor.copy(alpha = 0.85f), fontSize = 9.5.sp, letterSpacing = 1.5.sp,
        modifier = Modifier
            .border(1.dp, ruleColor, RoundedCornerShape(RootedMetrics.buttonRadius.dp))
            .rootedPressable(haptic = false, onClick = onClick)
            .padding(horizontal = 13.dp, vertical = 9.dp),
    )
}
