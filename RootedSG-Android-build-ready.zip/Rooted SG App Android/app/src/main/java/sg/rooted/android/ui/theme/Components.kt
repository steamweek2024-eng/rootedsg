package sg.rooted.android.ui.theme

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** The tuned colour set for one ground — reads from the appearance the theme provider set up. */
@Composable
fun rootedPalette(surface: RootedSurface): RootedPalette {
    val appearance = LocalRootedAppearance.current
    return when (surface) {
        RootedSurface.CANVAS -> appearance.canvas
        RootedSurface.PAPER -> appearance.onPaper
    }
}

/**
 * The app never had a `MaterialTheme` wrapper anywhere, so every `Text()` call — none
 * of which pass their own `fontFamily` — was falling back to Compose's bare default
 * (plain system Roboto/One UI Sans), instead of anything resembling iOS's serif
 * headlines (Iowan Old Style there has no Android equivalent, so `FontFamily.Serif`,
 * the platform's own built-in literary serif, stands in for it here — no font file to
 * bundle, no licensing to sort out). Providing it once, here, at the root cascades to
 * every screen automatically, since none of them override it individually.
 */
private val RootedTextStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Serif)

@Composable
fun RootedThemeProvider(store: ThemeStore, content: @Composable () -> Unit) {
    CompositionLocalProvider(
        LocalRootedAppearance provides store.currentAppearance,
        LocalTextStyle provides RootedTextStyle,
    ) {
        content()
    }
}

/** Fills the ground colour behind a whole screen. */
@Composable
fun RootedBackground(modifier: Modifier = Modifier) {
    val appearance = LocalRootedAppearance.current
    Box(modifier.fillMaxSize().background(appearance.ground))
}

/** All-caps, widely tracked micro label — the app's signature small-text convention. */
@Composable
fun RootedLabel(text: String, color: Color, size: TextUnit = 10.sp, modifier: Modifier = Modifier) {
    Text(
        text = text.uppercase(), color = color, fontSize = size, letterSpacing = 1.6.sp,
        fontWeight = FontWeight.Medium, modifier = modifier,
    )
}

/** A white/paper card with a soft border — the default container on the canvas ground. */
@Composable
fun RootedCard(modifier: Modifier = Modifier, radius: Int = RootedMetrics.cardRadius, content: @Composable () -> Unit) {
    val appearance = LocalRootedAppearance.current
    Box(
        modifier
            .background(appearance.paper, RoundedCornerShape(radius.dp))
            .border(1.dp, appearance.canvas.rule, RoundedCornerShape(radius.dp))
            .padding(18.dp)
    ) { content() }
}

/**
 * The reading surface — a near-white sheet laid on the canvas ground, exactly
 * like iOS's WhiteSheet. Content inside takes dark "onPaper" ink; this is
 * where most data-dense reading happens (due-plants list, quests, community),
 * while the canvas ground stays for illustration and headline.
 */
@Composable
fun WhiteSheet(modifier: Modifier = Modifier, padding: Dp = 22.dp, radius: Dp = RootedMetrics.cardRadius.dp, content: @Composable () -> Unit) {
    val appearance = LocalRootedAppearance.current
    Box(
        modifier
            .fillMaxWidth()
            .background(appearance.paper.copy(alpha = 0.94f), RoundedCornerShape(radius))
            .then(if (appearance.sheetNeedsRule) Modifier.border(1.dp, appearance.onPaper.rule, RoundedCornerShape(radius)) else Modifier)
            .padding(padding),
    ) { content() }
}

/** A hairline for use on paper. */
@Composable
fun PaperRule(modifier: Modifier = Modifier) {
    val p = rootedPalette(RootedSurface.PAPER)
    Box(modifier.fillMaxWidth().height(1.dp).background(p.rule))
}

/**
 * A progress bar — defaults to the paper surface (iOS's GreenBar), pass
 * [surface] = CANVAS for the hero's thinner measure-bar use.
 */
@Composable
fun GreenBar(fraction: Double, modifier: Modifier = Modifier, height: Dp = 4.dp, surface: RootedSurface = RootedSurface.PAPER) {
    val p = rootedPalette(surface)
    val animated by animateFloatAsState(targetValue = fraction.toFloat().coerceIn(0f, 1f), animationSpec = tween(700), label = "greenBar")
    Box(modifier.fillMaxWidth().height(height).background(p.faintFill, CircleShape)) {
        Box(
            Modifier
                .fillMaxWidth(animated.coerceIn(0.02f, 1f))
                .height(height)
                .background(p.green, CircleShape)
        )
    }
}

/** A green pill tag used on paper surfaces — status, category, or count badges. */
@Composable
fun GreenTag(text: String, filled: Boolean = true, modifier: Modifier = Modifier) {
    val p = rootedPalette(RootedSurface.PAPER)
    Text(
        text = text.uppercase(),
        color = if (filled) p.onAccent else p.green,
        fontSize = 9.5.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Medium,
        modifier = modifier
            .background(if (filled) p.green else p.green.copy(alpha = 0.12f), CircleShape)
            .padding(horizontal = 11.dp, vertical = 6.dp),
    )
}

/**
 * An animated circular progress ring — iOS's ProgressRing, used behind the
 * celebration character and anywhere a completion fraction deserves a beat
 * of ceremony rather than a flat bar.
 */
@Composable
fun ProgressRing(progress: Double, modifier: Modifier = Modifier, lineWidth: Dp = 8.dp, tint: Color, track: Color) {
    val animated = remember { Animatable(0f) }
    LaunchedEffect(progress) {
        animated.animateTo(progress.toFloat().coerceIn(0f, 1f), animationSpec = spring(dampingRatio = 0.85f, stiffness = 60f))
    }
    androidx.compose.foundation.Canvas(modifier) {
        val strokePx = lineWidth.toPx()
        drawCircle(color = track, style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokePx))
        drawArc(
            color = tint, startAngle = -90f, sweepAngle = 360f * animated.value, useCenter = false,
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokePx, cap = androidx.compose.ui.graphics.StrokeCap.Round),
        )
    }
}

/** A number that counts up to its target — iOS's CountingNumber. */
@Composable
fun CountingNumber(value: Int, modifier: Modifier = Modifier, fontSize: TextUnit, color: Color, fontWeight: FontWeight = FontWeight.Light) {
    var displayed by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(value) {
        val start = displayed
        val startNanos = withFrameNanosNow()
        while (true) {
            val now = withFrameNanosNow()
            val t = ((now - startNanos) / 900_000_000f).coerceIn(0f, 1f)
            val eased = 1f - (1f - t) * (1f - t) // easeOut
            displayed = start + (value - start) * eased
            if (t >= 1f) break
        }
        displayed = value.toFloat()
    }
    Text(text = "${displayed.toInt()}", color = color, fontSize = fontSize, fontWeight = fontWeight, modifier = modifier)
}

private suspend fun withFrameNanosNow(): Long = androidx.compose.runtime.withFrameNanos { it }

/**
 * A staggered rise-and-fade entrance — iOS's `.risesIn(index)`. Wrap a block
 * of content that should animate in a beat after the one before it.
 */
@Composable
fun RisesIn(index: Int, delayStepMs: Long = 60L, content: @Composable (Modifier) -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(index * delayStepMs)
        shown = true
    }
    val alpha by animateFloatAsState(if (shown) 1f else 0f, animationSpec = tween(500), label = "risesInAlpha")
    val offsetY by animateFloatAsState(if (shown) 0f else 14f, animationSpec = tween(500), label = "risesInOffset")
    content(Modifier.alpha(alpha).offset(y = offsetY.dp))
}
