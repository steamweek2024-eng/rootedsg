package sg.rooted.android.ui.theme

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color

// ═══════════════════════════════════════════════════════════════════════════
// Design system — a direct port of Design/Theme.swift and Design/Themes.swift.
// Five colour identities, each with a dark and a light appearance; a "canvas"
// palette (the gradient/gestalt ground) and an "onPaper" palette (the white
// reading-surface sheets) tuned separately so both clear contrast on their
// own ground.
// ═══════════════════════════════════════════════════════════════════════════

data class RootedPalette(
    val text: Color,
    val secondary: Color,
    val green: Color,
    val warm: Color,
    val alert: Color,
    val rule: Color,
    val faintFill: Color,
    val onAccent: Color,
)

data class RootedAppearanceSet(
    val ground: Color,
    val groundDeep: Color,
    val paper: Color,
    val canvas: RootedPalette,
    val onPaper: RootedPalette,
    val sheetNeedsRule: Boolean,
)

enum class RootedThemeId { GLASSHOUSE, NIGHTSOIL, KOPI, MONSOON, CHALK }

data class RootedTheme(
    val id: RootedThemeId,
    val themeName: String,
    val blurb: String,
    val dark: RootedAppearanceSet,
    val light: RootedAppearanceSet,
    val swatch: List<Color>,
) {
    fun appearanceSet(dark: Boolean): RootedAppearanceSet = if (dark) this.dark else this.light
}

enum class RootedAppearanceMode(val label: String) { SYSTEM("System"), LIGHT("Light"), DARK("Dark") }

private fun rgb(r: Double, g: Double, b: Double, a: Double = 1.0) =
    Color(r.toFloat(), g.toFloat(), b.toFloat(), a.toFloat())

object RootedThemes {
    val glasshouse = RootedTheme(
        id = RootedThemeId.GLASSHOUSE, themeName = "Glasshouse",
        blurb = "Deep planthouse green, or warm bone paper.",
        dark = RootedAppearanceSet(
            ground = rgb(0.055, 0.180, 0.122), groundDeep = rgb(0.031, 0.106, 0.075), paper = rgb(0.973, 0.965, 0.945),
            canvas = RootedPalette(
                text = Color.White, secondary = Color.White.copy(alpha = 0.78f),
                green = rgb(0.639, 0.902, 0.545), warm = rgb(0.929, 0.616, 0.463), alert = rgb(0.965, 0.639, 0.576),
                rule = Color.White.copy(alpha = 0.20f), faintFill = Color.White.copy(alpha = 0.09f), onAccent = rgb(0.031, 0.106, 0.075)),
            onPaper = RootedPalette(
                text = rgb(0.071, 0.098, 0.082), secondary = rgb(0.071, 0.098, 0.082, 0.68),
                green = rgb(0.043, 0.353, 0.196), warm = rgb(0.596, 0.267, 0.129), alert = rgb(0.616, 0.157, 0.106),
                rule = rgb(0.071, 0.098, 0.082, 0.13), faintFill = rgb(0.071, 0.098, 0.082, 0.06), onAccent = rgb(0.973, 0.965, 0.945)),
            sheetNeedsRule = false,
        ),
        light = RootedAppearanceSet(
            ground = rgb(0.973, 0.965, 0.945), groundDeep = rgb(0.945, 0.933, 0.906), paper = Color.White,
            canvas = RootedPalette(
                text = rgb(0.071, 0.098, 0.082), secondary = rgb(0.071, 0.098, 0.082, 0.68),
                green = rgb(0.043, 0.353, 0.196), warm = rgb(0.596, 0.267, 0.129), alert = rgb(0.616, 0.157, 0.106),
                rule = rgb(0.071, 0.098, 0.082, 0.14), faintFill = rgb(0.071, 0.098, 0.082, 0.06), onAccent = Color.White),
            onPaper = RootedPalette(
                text = rgb(0.071, 0.098, 0.082), secondary = rgb(0.071, 0.098, 0.082, 0.68),
                green = rgb(0.043, 0.353, 0.196), warm = rgb(0.596, 0.267, 0.129), alert = rgb(0.616, 0.157, 0.106),
                rule = rgb(0.071, 0.098, 0.082, 0.12), faintFill = rgb(0.071, 0.098, 0.082, 0.05), onAccent = Color.White),
            sheetNeedsRule = true,
        ),
        swatch = listOf(rgb(0.055, 0.180, 0.122), rgb(0.639, 0.902, 0.545), rgb(0.929, 0.616, 0.463)),
    )

    val nightsoil = RootedTheme(
        id = RootedThemeId.NIGHTSOIL, themeName = "Nightsoil",
        blurb = "Almost black, or a crisp paper white, a sharp new-leaf green either way.",
        dark = RootedAppearanceSet(
            ground = rgb(0.071, 0.071, 0.067), groundDeep = rgb(0.043, 0.043, 0.039), paper = rgb(0.957, 0.953, 0.941),
            canvas = RootedPalette(
                text = Color.White, secondary = Color.White.copy(alpha = 0.78f),
                green = rgb(0.678, 0.914, 0.514), warm = rgb(0.910, 0.702, 0.435), alert = rgb(0.949, 0.616, 0.545),
                rule = Color.White.copy(alpha = 0.18f), faintFill = Color.White.copy(alpha = 0.08f), onAccent = rgb(0.043, 0.043, 0.039)),
            onPaper = RootedPalette(
                text = rgb(0.086, 0.086, 0.082), secondary = rgb(0.086, 0.086, 0.082, 0.68),
                green = rgb(0.196, 0.400, 0.106), warm = rgb(0.545, 0.365, 0.078), alert = rgb(0.639, 0.176, 0.118),
                rule = rgb(0.086, 0.086, 0.082, 0.13), faintFill = rgb(0.086, 0.086, 0.082, 0.06), onAccent = rgb(0.957, 0.953, 0.941)),
            sheetNeedsRule = false,
        ),
        light = RootedAppearanceSet(
            ground = rgb(0.957, 0.953, 0.941), groundDeep = rgb(0.929, 0.925, 0.910), paper = Color.White,
            canvas = RootedPalette(
                text = rgb(0.086, 0.086, 0.082), secondary = rgb(0.086, 0.086, 0.082, 0.68),
                green = rgb(0.196, 0.400, 0.106), warm = rgb(0.545, 0.365, 0.078), alert = rgb(0.639, 0.176, 0.118),
                rule = rgb(0.086, 0.086, 0.082, 0.14), faintFill = rgb(0.086, 0.086, 0.082, 0.06), onAccent = Color.White),
            onPaper = RootedPalette(
                text = rgb(0.086, 0.086, 0.082), secondary = rgb(0.086, 0.086, 0.082, 0.68),
                green = rgb(0.196, 0.400, 0.106), warm = rgb(0.545, 0.365, 0.078), alert = rgb(0.639, 0.176, 0.118),
                rule = rgb(0.086, 0.086, 0.082, 0.12), faintFill = rgb(0.086, 0.086, 0.082, 0.05), onAccent = Color.White),
            sheetNeedsRule = true,
        ),
        swatch = listOf(rgb(0.071, 0.071, 0.067), rgb(0.678, 0.914, 0.514), rgb(0.910, 0.702, 0.435)),
    )

    val kopi = RootedTheme(
        id = RootedThemeId.KOPI, themeName = "Kopi",
        blurb = "Roasted brown, or oat paper, after the kopitiam either way.",
        dark = RootedAppearanceSet(
            ground = rgb(0.153, 0.098, 0.067), groundDeep = rgb(0.106, 0.067, 0.047), paper = rgb(0.965, 0.941, 0.898),
            canvas = RootedPalette(
                text = Color.White, secondary = Color.White.copy(alpha = 0.78f),
                green = rgb(0.706, 0.878, 0.573), warm = rgb(0.945, 0.729, 0.502), alert = rgb(0.965, 0.647, 0.573),
                rule = Color.White.copy(alpha = 0.20f), faintFill = Color.White.copy(alpha = 0.09f), onAccent = rgb(0.106, 0.067, 0.047)),
            onPaper = RootedPalette(
                text = rgb(0.129, 0.094, 0.071), secondary = rgb(0.129, 0.094, 0.071, 0.68),
                green = rgb(0.176, 0.376, 0.180), warm = rgb(0.522, 0.318, 0.110), alert = rgb(0.612, 0.180, 0.114),
                rule = rgb(0.129, 0.094, 0.071, 0.14), faintFill = rgb(0.129, 0.094, 0.071, 0.06), onAccent = rgb(0.965, 0.941, 0.898)),
            sheetNeedsRule = false,
        ),
        light = RootedAppearanceSet(
            ground = rgb(0.965, 0.941, 0.898), groundDeep = rgb(0.937, 0.906, 0.851), paper = Color.White,
            canvas = RootedPalette(
                text = rgb(0.129, 0.094, 0.071), secondary = rgb(0.129, 0.094, 0.071, 0.68),
                green = rgb(0.176, 0.376, 0.180), warm = rgb(0.522, 0.318, 0.110), alert = rgb(0.612, 0.180, 0.114),
                rule = rgb(0.129, 0.094, 0.071, 0.15), faintFill = rgb(0.129, 0.094, 0.071, 0.06), onAccent = Color.White),
            onPaper = RootedPalette(
                text = rgb(0.129, 0.094, 0.071), secondary = rgb(0.129, 0.094, 0.071, 0.68),
                green = rgb(0.176, 0.376, 0.180), warm = rgb(0.522, 0.318, 0.110), alert = rgb(0.612, 0.180, 0.114),
                rule = rgb(0.129, 0.094, 0.071, 0.12), faintFill = rgb(0.129, 0.094, 0.071, 0.05), onAccent = Color.White),
            sheetNeedsRule = true,
        ),
        swatch = listOf(rgb(0.153, 0.098, 0.067), rgb(0.706, 0.878, 0.573), rgb(0.945, 0.729, 0.502)),
    )

    val monsoon = RootedTheme(
        id = RootedThemeId.MONSOON, themeName = "Monsoon",
        blurb = "Storm teal, or rain-washed paper.",
        dark = RootedAppearanceSet(
            ground = rgb(0.043, 0.129, 0.157), groundDeep = rgb(0.024, 0.086, 0.106), paper = rgb(0.949, 0.965, 0.965),
            canvas = RootedPalette(
                text = Color.White, secondary = Color.White.copy(alpha = 0.78f),
                green = rgb(0.573, 0.902, 0.788), warm = rgb(0.937, 0.706, 0.494), alert = rgb(0.957, 0.639, 0.596),
                rule = Color.White.copy(alpha = 0.20f), faintFill = Color.White.copy(alpha = 0.09f), onAccent = rgb(0.024, 0.086, 0.106)),
            onPaper = RootedPalette(
                text = rgb(0.055, 0.086, 0.094), secondary = rgb(0.055, 0.086, 0.094, 0.68),
                green = rgb(0.043, 0.353, 0.318), warm = rgb(0.545, 0.310, 0.129), alert = rgb(0.612, 0.161, 0.129),
                rule = rgb(0.055, 0.086, 0.094, 0.13), faintFill = rgb(0.055, 0.086, 0.094, 0.06), onAccent = rgb(0.949, 0.965, 0.965)),
            sheetNeedsRule = false,
        ),
        light = RootedAppearanceSet(
            ground = rgb(0.949, 0.965, 0.965), groundDeep = rgb(0.921, 0.937, 0.937), paper = Color.White,
            canvas = RootedPalette(
                text = rgb(0.055, 0.086, 0.094), secondary = rgb(0.055, 0.086, 0.094, 0.68),
                green = rgb(0.043, 0.353, 0.318), warm = rgb(0.545, 0.310, 0.129), alert = rgb(0.612, 0.161, 0.129),
                rule = rgb(0.055, 0.086, 0.094, 0.14), faintFill = rgb(0.055, 0.086, 0.094, 0.06), onAccent = Color.White),
            onPaper = RootedPalette(
                text = rgb(0.055, 0.086, 0.094), secondary = rgb(0.055, 0.086, 0.094, 0.68),
                green = rgb(0.043, 0.353, 0.318), warm = rgb(0.545, 0.310, 0.129), alert = rgb(0.612, 0.161, 0.129),
                rule = rgb(0.055, 0.086, 0.094, 0.12), faintFill = rgb(0.055, 0.086, 0.094, 0.05), onAccent = Color.White),
            sheetNeedsRule = true,
        ),
        swatch = listOf(rgb(0.043, 0.129, 0.157), rgb(0.573, 0.902, 0.788), rgb(0.937, 0.706, 0.494)),
    )

    val chalk = RootedTheme(
        id = RootedThemeId.CHALK, themeName = "Chalk",
        blurb = "A light room by default, ink on chalk, or ink on charcoal in the dark.",
        dark = nightsoil.dark,
        light = RootedAppearanceSet(
            ground = rgb(0.933, 0.929, 0.914), groundDeep = rgb(0.898, 0.894, 0.878), paper = Color.White,
            canvas = RootedPalette(
                text = rgb(0.098, 0.106, 0.098), secondary = rgb(0.098, 0.106, 0.098, 0.66),
                green = rgb(0.086, 0.361, 0.196), warm = rgb(0.545, 0.290, 0.118), alert = rgb(0.612, 0.153, 0.106),
                rule = rgb(0.098, 0.106, 0.098, 0.16), faintFill = rgb(0.098, 0.106, 0.098, 0.07), onAccent = Color.White),
            onPaper = RootedPalette(
                text = rgb(0.098, 0.106, 0.098), secondary = rgb(0.098, 0.106, 0.098, 0.66),
                green = rgb(0.086, 0.361, 0.196), warm = rgb(0.545, 0.290, 0.118), alert = rgb(0.612, 0.153, 0.106),
                rule = rgb(0.098, 0.106, 0.098, 0.13), faintFill = rgb(0.098, 0.106, 0.098, 0.05), onAccent = Color.White),
            sheetNeedsRule = true,
        ),
        swatch = listOf(rgb(0.933, 0.929, 0.914), rgb(0.086, 0.361, 0.196), rgb(0.545, 0.290, 0.118)),
    )

    val all = listOf(glasshouse, nightsoil, kopi, monsoon, chalk)

    fun byId(id: RootedThemeId): RootedTheme = all.first { it.id == id }
}

enum class RootedSurface { CANVAS, PAPER }

object RootedMetrics {
    val cardRadius = 26
    val smallRadius = 18
    val heroRadius = 32
    val chipRadius = 12
    val thumbRadius = 14
    val pagePadding = 20
    val buttonRadius = 100
}

/** The current appearance set, provided by RootedThemeProvider — every themed colour reads from here. */
val LocalRootedAppearance = compositionLocalOf { RootedThemes.glasshouse.light }
