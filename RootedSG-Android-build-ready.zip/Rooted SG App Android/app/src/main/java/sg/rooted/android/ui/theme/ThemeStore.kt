package sg.rooted.android.ui.theme

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import sg.rooted.android.data.PreferencesStore

/**
 * Holds the chosen theme and appearance, persisted via DataStore — the
 * Android counterpart to ThemeStore.swift. Backed by Compose's own
 * `mutableStateOf` so any composable reading `.theme`/`.appearanceMode`
 * recomposes automatically on change, same as the `@Observable` original.
 */
class ThemeStore(private val prefs: PreferencesStore, private val scope: CoroutineScope) {
    var themeId by mutableStateOf(RootedThemeId.GLASSHOUSE)
        private set
    // Defaults to LIGHT, not SYSTEM — matches iOS, which forces a light appearance
    // regardless of the device's dark-mode setting (Info.plist's UIUserInterfaceStyle).
    // A user can still switch to Dark or System explicitly in the Theme picker.
    var appearanceMode by mutableStateOf(RootedAppearanceMode.LIGHT)
        private set

    /** Set from the system's dark-theme setting by the app root. */
    var systemPrefersDark by mutableStateOf(true)

    val theme: RootedTheme get() = RootedThemes.byId(themeId)

    val effectiveIsDark: Boolean
        get() = when (appearanceMode) {
            RootedAppearanceMode.SYSTEM -> systemPrefersDark
            RootedAppearanceMode.LIGHT -> false
            RootedAppearanceMode.DARK -> true
        }

    val currentAppearance: RootedAppearanceSet get() = theme.appearanceSet(dark = effectiveIsDark)

    init {
        scope.launch {
            prefs.themeId.collect { stored ->
                stored?.let { raw -> runCatching { RootedThemeId.valueOf(raw) }.getOrNull()?.let { themeId = it } }
            }
        }
        scope.launch {
            prefs.appearanceMode.collect { stored ->
                stored?.let { raw -> runCatching { RootedAppearanceMode.valueOf(raw) }.getOrNull()?.let { appearanceMode = it } }
            }
        }
    }

    fun select(new: RootedThemeId) {
        themeId = new
        scope.launch { prefs.setThemeId(new.name) }
    }

    fun setAppearance(mode: RootedAppearanceMode) {
        appearanceMode = mode
        scope.launch { prefs.setAppearanceMode(mode.name) }
    }
}
