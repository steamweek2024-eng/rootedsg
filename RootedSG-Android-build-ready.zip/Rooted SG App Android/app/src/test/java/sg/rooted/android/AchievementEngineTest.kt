package sg.rooted.android

import org.junit.Assert.assertTrue
import org.junit.Test
import sg.rooted.android.engine.AchievementEngine
import sg.rooted.android.model.*

class AchievementEngineTest {
    @Test
    fun achievementsComeFromPersistedCareBehaviour() {
        val user = UserProfile(name = "Maya", school = "", xp = 2600)
        val plants = (1..5).map { i ->
            Plant(
                ownerId = user.id, name = "Plant $i", species = "Monstera", speciesEmoji = "🌿",
                registeredDate = 0L, healthScore = 94, careStreak = if (i == 1) 8 else 2,
                hadRecoveryEvent = i == 1,
            )
        }
        val rescue = Quest(
            ownerId = user.id, type = QuestType.RECOVERY, title = "Rescue", detail = "",
            target = 1, progress = 1, rewardXP = 250, status = QuestStatus.COMPLETED,
        )
        val sessions = (1..25).map { i ->
            DiagnosisSession(
                ownerId = user.id, plantId = plants.first().id, status = DiagnosisStatus.COMPLETE,
                likelyCause = if (i <= 10) "Overwatering" else "Light stress",
                userChoice = if (i <= 10) "Overwatering" else "Light stress",
                diagnosisXP = 150,
            )
        }

        val badges = AchievementEngine.evaluate(user, plants, listOf(rescue), sessions).associateBy { it.id }
        assertTrue(badges.getValue("first_rescue").unlocked)
        assertTrue(badges.getValue("water_whisperer").unlocked)
        assertTrue(badges.getValue("plant_detective").unlocked)
        assertTrue(badges.getValue("green_thumb").unlocked)
        assertTrue(badges.getValue("comeback_king").unlocked)
        assertTrue(badges.getValue("streak_keeper").unlocked)
    }
}
