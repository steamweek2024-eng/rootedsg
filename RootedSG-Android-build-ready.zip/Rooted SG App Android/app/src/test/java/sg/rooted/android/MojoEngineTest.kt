package sg.rooted.android

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import sg.rooted.android.engine.MojoEngine
import sg.rooted.android.engine.MojoEvent
import sg.rooted.android.engine.MojoMood
import sg.rooted.android.model.HealthStatus
import sg.rooted.android.model.Plant
import sg.rooted.android.model.Quest
import sg.rooted.android.model.QuestStatus
import sg.rooted.android.model.QuestType
import sg.rooted.android.model.UserProfile
import java.util.concurrent.TimeUnit

class MojoEngineTest {

    private val now = System.currentTimeMillis()

    private fun plant(
        name: String = "P",
        health: HealthStatus = HealthStatus.HEALTHY,
        streak: Int = 0,
        lastCheckIn: Long? = now,
        milestones: String = "",
    ) = Plant(
        ownerId = "u", name = name, species = "Basil", speciesEmoji = "🌿",
        registeredDate = now - TimeUnit.DAYS.toMillis(20),
        health = health, careStreak = streak, lastCheckInDate = lastCheckIn,
        awardedMilestoneDaysRaw = milestones,
    )

    private fun user(xp: Int = 0) = UserProfile(name = "Grower", school = "", xp = xp)

    @Test
    fun gardenScore_allHealthy_isOne() {
        val score = MojoEngine.gardenScore(listOf(plant(), plant(), plant()))
        assertEquals(1.0, score, 0.0001)
    }

    @Test
    fun gardenScore_noPlants_isNeutral() {
        assertEquals(0.6, MojoEngine.gardenScore(emptyList()), 0.0001)
    }

    @Test
    fun gardenScore_ignoresDeceased() {
        val score = MojoEngine.gardenScore(
            listOf(plant(health = HealthStatus.HEALTHY), plant(health = HealthStatus.DECEASED)),
        )
        assertEquals(1.0, score, 0.0001)
    }

    @Test
    fun gardenScore_strugglingDragsItDown() {
        val healthy = MojoEngine.gardenScore(listOf(plant(health = HealthStatus.HEALTHY)))
        val mixed = MojoEngine.gardenScore(
            listOf(plant(health = HealthStatus.HEALTHY), plant(health = HealthStatus.STRUGGLING)),
        )
        assertTrue(mixed < healthy)
    }

    @Test
    fun vitals_healthierGarden_raisesHealth() {
        val quests = emptyList<Quest>()
        val weak = MojoEngine.vitals(listOf(plant(health = HealthStatus.STRUGGLING)), quests, user(), 0)
        val strong = MojoEngine.vitals(listOf(plant(health = HealthStatus.HEALTHY)), quests, user(), 0)
        assertTrue(strong.health > weak.health)
    }

    @Test
    fun vitals_momentumAndBadgesRaiseHealth() {
        val plants = listOf(plant(health = HealthStatus.HEALTHY, streak = 9, milestones = "7,30,90"))
        val quests = List(6) {
            Quest(ownerId = "u", type = QuestType.CARE, title = "q$it", detail = "", target = 1, rewardXP = 10,
                status = QuestStatus.COMPLETED)
        }
        val base = MojoEngine.vitals(listOf(plant(health = HealthStatus.HEALTHY)), emptyList(), user(xp = 0), 0)
        val boosted = MojoEngine.vitals(plants, quests, user(xp = 500), xpThisWeek = 120)
        assertTrue(boosted.health > base.health)
        assertTrue(boosted.mood == MojoMood.THRIVING || boosted.mood == MojoMood.HAPPY)
    }

    @Test
    fun mood_thresholds() {
        assertEquals(MojoMood.THRIVING, MojoEngine.mood(90))
        assertEquals(MojoMood.HAPPY, MojoEngine.mood(70))
        assertEquals(MojoMood.OKAY, MojoEngine.mood(55))
        assertEquals(MojoMood.WORRIED, MojoEngine.mood(40))
        assertEquals(MojoMood.SAD, MojoEngine.mood(10))
    }

    @Test
    fun nudge_isSilent_whenGardenHealthyAndNothingDue() {
        val plants = listOf(plant(health = HealthStatus.HEALTHY, lastCheckIn = now))
        val vitals = MojoEngine.vitals(plants, emptyList(), user(xp = 300), xpThisWeek = 60)
        assertNull(MojoEngine.nudge(vitals, plants, daysSinceOpen = 0))
    }

    @Test
    fun nudge_speaksUp_whenAPlantIsOverdue() {
        val overdue = plant(health = HealthStatus.HEALTHY, lastCheckIn = now - TimeUnit.DAYS.toMillis(12))
        val vitals = MojoEngine.vitals(listOf(overdue), emptyList(), user(), 0)
        val line = MojoEngine.nudge(vitals, listOf(overdue), daysSinceOpen = 1, petName = "Mojo")
        assertNotNull(line)
        assertTrue(line!!.contains("Mojo"))
    }

    @Test
    fun nudge_missesYou_afterDaysAway() {
        val plants = listOf(plant(health = HealthStatus.HEALTHY, lastCheckIn = now))
        val vitals = MojoEngine.vitals(plants, emptyList(), user(xp = 300), xpThisWeek = 60)
        val line = MojoEngine.nudge(vitals, plants, daysSinceOpen = 5, petName = "Mojo")
        assertNotNull(line)
        assertTrue(line!!.contains("misses you"))
    }

    @Test
    fun reaction_verifiedCheckIn_jumpsAndNamesTheDays() {
        val (anim, text) = MojoEngine.reaction(MojoEvent.CheckInVerified("Bob", 1))!!
        assertEquals(sg.rooted.android.engine.MojoAnim.JUMPING, anim)
        assertTrue(text.contains("Bob"))
        assertTrue(text.contains("1 day"))
    }

    @Test
    fun reaction_struggling_isTheSadSprite() {
        val (anim, _) = MojoEngine.reaction(MojoEvent.PlantStruggling("Mochi"))!!
        assertEquals(sg.rooted.android.engine.MojoAnim.FAILED, anim)
    }

    @Test
    fun dailyTip_isStableForADay_butRotatesAcrossDays() {
        val plants = listOf(
            plant(name = "Bob", health = HealthStatus.HEALTHY, lastCheckIn = now),
            plant(name = "Old", health = HealthStatus.HEALTHY, lastCheckIn = now - TimeUnit.DAYS.toMillis(11)),
        )
        val vitals = MojoEngine.vitals(plants, emptyList(), user(xp = 200), xpThisWeek = 40)
        val a1 = MojoEngine.dailyTip(plants, emptyList(), vitals, "Mojo", daySeed = 5)
        val a2 = MojoEngine.dailyTip(plants, emptyList(), vitals, "Mojo", daySeed = 5)
        assertEquals(a1, a2)
        // With an overdue plant present there is more than one candidate line.
        assertTrue(a1.isNotBlank())
    }

    @Test
    fun dailyTip_allClear_encourages() {
        val plants = listOf(plant(health = HealthStatus.HEALTHY, streak = 2, lastCheckIn = now))
        val vitals = MojoEngine.vitals(plants, emptyList(), user(xp = 500), xpThisWeek = 100)
        val tip = MojoEngine.dailyTip(plants, emptyList(), vitals, "Mojo", daySeed = 0)
        assertTrue(tip.isNotBlank())
    }
}
