package sg.rooted.android

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import sg.rooted.android.model.QuestCodec
import sg.rooted.android.model.QuestObjective

class QuestCodecTest {
    @Test
    fun objectivesRoundTripWithoutLosingCompletion() {
        val original = listOf(
            QuestObjective(title = "Let soil dry", icon = "💧", isComplete = true, completedDate = 123L),
            QuestObjective(title = "Move to indirect light", icon = "☀️"),
        )
        val decoded = QuestCodec.decode(QuestCodec.encode(original))
        assertEquals(2, decoded.size)
        assertTrue(decoded.first().isComplete)
        assertEquals("Move to indirect light", decoded.last().title)
    }
}
