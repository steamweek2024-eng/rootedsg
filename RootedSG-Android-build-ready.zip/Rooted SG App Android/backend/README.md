# ROOTED SG backend

A deployable REST backend matching the Android client's `RootedApi` contract.

## What it provides

- Google ID-token verification and ROOTED session tokens
- authenticated listing/request writes and server-authoritative stock claims
- authenticated one-to-one conversation/message routes
- `/v1/plant-analysis` with a provider adapter and a cautious non-AI fallback
- `/v1/sg/conditions` proxy/cache for data.gov.sg with an optional server-only API key
- `/health` readiness/configuration endpoint

The Android garden, check-ins, quests, XP, achievements, local diagnosis and public data.gov.sg weather continue to work without this server. Account sync, real cross-device exchange/chat and provider-backed cloud analysis use it when configured.

## Local setup

1. Install Node.js 20+.
2. Copy `.env.example` to your secret/environment manager and provide the values through the process environment. This server intentionally does not load `.env` files itself.
3. Run `npm install`.
4. Run `npm run dev` (or `npm start`).
5. Android emulator: set `ROOTED_BACKEND_URL_DEBUG=http://10.0.2.2:8787` in `local.properties`.
6. Physical device: use your development machine's LAN address, or a deployed HTTPS URL.

## Google Sign-In

Create Android + Web OAuth clients in Google Cloud Console. The **Web** client ID is the audience used by both sides:

- Android `local.properties`: `GOOGLE_WEB_CLIENT_ID=...apps.googleusercontent.com`
- backend environment: `GOOGLE_CLIENT_ID=...apps.googleusercontent.com`

The backend verifies the ID token and derives the ROOTED account ID itself. Never trust a sender/owner ID supplied by the phone.

## Production deployment

Use HTTPS. Put this service behind your normal managed load balancer/API gateway, add platform rate limiting/logging, and move the JSON datastore to Postgres before running more than one backend instance. The included JSON store is deliberately simple so local development works with no database setup; it is not a horizontally scalable production database.

Keep `DATA_GOV_API_KEY`, `AI_PROVIDER_KEY`, Google secrets and signing material **off the Android client**. data.gov.sg public feeds can be called keyless by the app for normal use; a production API key belongs on this backend/proxy.

## AI provider contract

If `AI_PROVIDER_URL` is blank, `/v1/plant-analysis` returns a conservative fallback and explicitly avoids pretending it saw a specific symptom. To enable cloud vision, point `AI_PROVIDER_URL` at your provider adapter. ROOTED sends:

```json
{
  "task": "doctor",
  "image_base64": "...",
  "mime_type": "image/jpeg",
  "plant_species": "Monstera",
  "client_user_id": "...",
  "safety_note": "Return observations as likely/possible, not certainty. Do not invent visible evidence."
}
```

Return either `{ "analysis": { ... } }` or the analysis object itself. Doctor analysis must contain `headline`, `severity`, `causes[]` (`possible_cause`, `why_plausible`), `next_action`, and `observe_next`; species and biodiversity shapes match `ApiModels.kt`.
