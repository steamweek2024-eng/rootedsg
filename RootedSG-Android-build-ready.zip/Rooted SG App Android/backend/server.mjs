import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { OAuth2Client } from 'google-auth-library';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 8787);
const HOST = process.env.HOST || '0.0.0.0';
const GOOGLE_CLIENT_ID = (process.env.GOOGLE_CLIENT_ID || '').trim();
const DATA_GOV_API_KEY = (process.env.DATA_GOV_API_KEY || '').trim();
const AI_PROVIDER_URL = (process.env.AI_PROVIDER_URL || '').trim();
const AI_PROVIDER_KEY = (process.env.AI_PROVIDER_KEY || '').trim();
const DATA_FILE = path.resolve(__dirname, process.env.DATA_FILE || './data/rooted-db.json');
const BODY_LIMIT = 14 * 1024 * 1024;
const oauth = GOOGLE_CLIENT_ID ? new OAuth2Client(GOOGLE_CLIENT_ID) : null;

const emptyDb = () => ({ users: {}, sessions: {}, listings: {}, requests: {}, conversations: {}, messages: {} });
let db = loadDb();

function loadDb() {
  try {
    const parsed = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    return { ...emptyDb(), ...parsed };
  } catch {
    return emptyDb();
  }
}

function persist() {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  const tmp = `${DATA_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, DATA_FILE);
}

function nowIso() { return new Date().toISOString(); }
function id(prefix) { return `${prefix}_${crypto.randomUUID()}`; }
function token() { return crypto.randomBytes(32).toString('base64url'); }
function cleanText(value, max = 2000) { return String(value ?? '').trim().slice(0, max); }
function cleanInt(value, min = 0, max = Number.MAX_SAFE_INTEGER) {
  const n = Number.parseInt(value, 10);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : min;
}

function send(res, status, body) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
    'content-length': Buffer.byteLength(payload),
  });
  res.end(payload);
}

function error(res, status, message) { send(res, status, { error: message }); }

async function readJson(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > BODY_LIMIT) throw Object.assign(new Error('Request body too large.'), { status: 413 });
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); }
  catch { throw Object.assign(new Error('Invalid JSON body.'), { status: 400 }); }
}

function bearer(req) {
  const value = String(req.headers.authorization || '');
  return value.startsWith('Bearer ') ? value.slice(7).trim() : '';
}

function authenticatedUser(req) {
  const sessionToken = bearer(req);
  if (!sessionToken) return null;
  const session = db.sessions[sessionToken];
  if (!session || session.expires_at < Date.now()) {
    if (session) { delete db.sessions[sessionToken]; persist(); }
    return null;
  }
  return db.users[session.user_id] || null;
}

function requireUser(req, res) {
  const user = authenticatedUser(req);
  if (!user) error(res, 401, 'Sign in to continue.');
  return user;
}

function publicListing(x) {
  return {
    id: x.id, owner_id: x.owner_id, owner_name: x.owner_name, owner_avatar: x.owner_avatar,
    owner_plant_days: x.owner_plant_days, produce: x.produce, headline: x.headline, detail: x.detail,
    terms: x.terms, price_sgd_cents: x.price_sgd_cents, capacity_households: x.capacity_households,
    claimed_count: x.claimed_count, stock_total: x.stock_total, stock_remaining: x.stock_remaining,
    quantity_label: x.quantity_label, is_seed_listing: x.is_seed_listing, neighbourhood: x.neighbourhood,
    status: x.status, created_at: x.created_at,
  };
}

function publicRequest(x) {
  return {
    id: x.id, requester_id: x.requester_id, requester_name: x.requester_name,
    requester_avatar: x.requester_avatar, produce: x.produce, note: x.note,
    neighbourhood: x.neighbourhood, status: x.status, created_at: x.created_at,
  };
}

const rateBuckets = new Map();
function rateLimit(key, max, windowMs) {
  const now = Date.now();
  const current = rateBuckets.get(key);
  if (!current || current.reset <= now) {
    rateBuckets.set(key, { count: 1, reset: now + windowMs });
    return true;
  }
  if (current.count >= max) return false;
  current.count += 1;
  return true;
}

async function googleSignIn(body, res) {
  if (!oauth || !GOOGLE_CLIENT_ID) return error(res, 503, 'Google Sign-In is not configured on this server.');
  const idToken = cleanText(body.id_token, 10000);
  if (!idToken) return error(res, 400, 'Missing id_token.');
  try {
    const ticket = await oauth.verifyIdToken({ idToken, audience: GOOGLE_CLIENT_ID });
    const p = ticket.getPayload();
    if (!p?.sub || !p.email) return error(res, 401, 'Google identity token is missing required claims.');
    const user = {
      id: `google_${p.sub}`,
      email: cleanText(p.email, 320),
      name: cleanText(p.name || p.email.split('@')[0], 120),
      picture: cleanText(p.picture || '', 1000),
      updated_at: nowIso(),
    };
    db.users[user.id] = user;
    const sessionToken = token();
    db.sessions[sessionToken] = { user_id: user.id, created_at: Date.now(), expires_at: Date.now() + 30 * 24 * 60 * 60 * 1000 };
    persist();
    return send(res, 200, { ...user, session_token: sessionToken });
  } catch {
    return error(res, 401, 'Google Sign-In token could not be verified.');
  }
}

function isParticipant(conversation, userId) {
  return conversation && (conversation.grower_id === userId || conversation.taker_id === userId);
}

function safeFallbackAnalysis(task, species) {
  if (task === 'species') {
    return {
      candidates: [{ name: species || 'Unknown plant', scientific_name: '', confidence: 0.2, rationale: 'Cloud vision is not configured; confirm the species manually.' }],
      manual_confirmation_required: true,
    };
  }
  if (task === 'biodiversity') {
    return { candidates: [], manual_confirmation_required: true };
  }
  return {
    headline: 'Use the visible clues before changing care',
    severity: 'uncertain',
    causes: [
      { possible_cause: 'Watering or drainage stress', why_plausible: 'This is a common cause of visible decline, but the server has no configured vision provider to confirm it.' },
      { possible_cause: 'Light or environmental stress', why_plausible: 'Changes in light, heat and humidity can look similar in a single photo.' },
    ],
    next_action: 'Check the soil moisture and drainage first. Avoid adding water, fertiliser or pesticide solely from this fallback result.',
    observe_next: 'Recheck with a clear photo of representative leaves, soil/pot and new growth.',
  };
}

async function analysePlant(body, req, res) {
  const ip = String(req.socket.remoteAddress || 'unknown');
  if (!rateLimit(`ai:${ip}`, 20, 10 * 60 * 1000)) return error(res, 429, 'Too many analysis requests. Try again later.');
  const task = ['species', 'doctor', 'biodiversity'].includes(body.task) ? body.task : null;
  if (!task) return error(res, 400, 'Unsupported analysis task.');
  const imageBase64 = cleanText(body.image_base64, 13 * 1024 * 1024);
  if (!imageBase64) return error(res, 400, 'Missing image_base64.');

  if (!AI_PROVIDER_URL) {
    return send(res, 200, { analysis: safeFallbackAnalysis(task, cleanText(body.plant_species, 160)), source: 'safe-fallback' });
  }

  try {
    const headers = { 'content-type': 'application/json', accept: 'application/json' };
    if (AI_PROVIDER_KEY) headers.authorization = `Bearer ${AI_PROVIDER_KEY}`;
    const providerResponse = await fetch(AI_PROVIDER_URL, {
      method: 'POST', headers,
      body: JSON.stringify({
        task,
        image_base64: imageBase64,
        mime_type: cleanText(body.mime_type || 'image/jpeg', 80),
        plant_species: cleanText(body.plant_species, 160) || null,
        client_user_id: cleanText(body.client_user_id, 200) || null,
        safety_note: 'Return observations as likely/possible, not certainty. Do not invent visible evidence.',
      }),
      signal: AbortSignal.timeout(30000),
    });
    if (!providerResponse.ok) throw new Error(`AI provider HTTP ${providerResponse.status}`);
    const parsed = await providerResponse.json();
    const analysis = parsed.analysis ?? parsed;
    if (!analysis || typeof analysis !== 'object') throw new Error('AI provider returned malformed JSON');
    return send(res, 200, { analysis, source: 'provider' });
  } catch (e) {
    console.error('[AI provider]', e?.message || e);
    return send(res, 200, { analysis: safeFallbackAnalysis(task, cleanText(body.plant_species, 160)), source: 'safe-fallback' });
  }
}

const dataGovCache = new Map();
async function dataGovConditions(url, req, res) {
  const ip = String(req.socket.remoteAddress || 'unknown');
  if (!rateLimit(`sg:${ip}`, 60, 60 * 1000)) return error(res, 429, 'Too many conditions requests.');
  const cacheKey = 'all';
  const cached = dataGovCache.get(cacheKey);
  if (cached && Date.now() - cached.at < 5 * 60 * 1000) return send(res, 200, cached.value);
  const paths = ['rainfall', 'air-temperature', 'relative-humidity', 'wind-speed', 'uv', 'two-hr-forecast', 'twenty-four-hr-forecast', 'four-day-outlook'];
  const headers = { accept: 'application/json' };
  if (DATA_GOV_API_KEY) headers['x-api-key'] = DATA_GOV_API_KEY;
  const entries = await Promise.all(paths.map(async name => {
    try {
      const r = await fetch(`https://api-open.data.gov.sg/v2/real-time/api/${name}`, { headers, signal: AbortSignal.timeout(10000) });
      return [name, r.ok ? await r.json() : { error: `HTTP ${r.status}` }];
    } catch (e) { return [name, { error: e?.message || 'unavailable' }]; }
  }));
  const value = { fetched_at: nowIso(), neighbourhood: cleanText(url.searchParams.get('neighbourhood'), 120) || null, feeds: Object.fromEntries(entries) };
  dataGovCache.set(cacheKey, { at: Date.now(), value });
  return send(res, 200, value);
}

async function route(req, res) {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const method = req.method || 'GET';
  const pathName = url.pathname;

  if (method === 'GET' && pathName === '/health') {
    return send(res, 200, { ok: true, service: 'rooted-sg', version: '1.1.0', time: nowIso(), ai_provider: Boolean(AI_PROVIDER_URL), google_auth: Boolean(GOOGLE_CLIENT_ID), data_gov_key: Boolean(DATA_GOV_API_KEY) });
  }
  if (method === 'GET' && pathName === '/v1/sg/conditions') return dataGovConditions(url, req, res);

  const body = ['POST', 'PUT', 'PATCH'].includes(method) ? await readJson(req) : {};
  if (method === 'POST' && pathName === '/v1/auth/google') return googleSignIn(body, res);
  if (method === 'POST' && pathName === '/v1/plant-analysis') return analysePlant(body, req, res);

  if (method === 'GET' && pathName === '/v1/listings') {
    const neighbourhood = cleanText(url.searchParams.get('neighbourhood'), 120).toLowerCase();
    const listings = Object.values(db.listings)
      .filter(x => !neighbourhood || x.neighbourhood.toLowerCase() === neighbourhood)
      .sort((a, b) => b.created_at.localeCompare(a.created_at)).map(publicListing);
    return send(res, 200, { listings });
  }

  let m = pathName.match(/^\/v1\/listings\/([^/]+)$/);
  if (m && method === 'PUT') {
    const user = requireUser(req, res); if (!user) return;
    const listingId = decodeURIComponent(m[1]).slice(0, 200);
    const old = db.listings[listingId];
    if (old && old.owner_id !== user.id) return error(res, 403, 'You do not own this listing.');
    const stockTotal = cleanInt(body.stock_total, 0, 100000);
    const capacity = cleanInt(body.capacity_households, 1, 1000);
    const listing = {
      id: listingId, owner_id: user.id, owner_name: cleanText(body.owner_name || user.name, 120), owner_avatar: cleanText(body.owner_avatar, 32),
      owner_plant_days: cleanInt(body.owner_plant_days, 0, 10000000), produce: cleanText(body.produce, 80), headline: cleanText(body.headline, 180),
      detail: cleanText(body.detail, 3000), terms: cleanText(body.terms, 80), price_sgd_cents: cleanInt(body.price_sgd_cents, 0, 10000000),
      capacity_households: capacity, claimed_count: old?.claimed_count || 0, stock_total: stockTotal,
      stock_remaining: old ? Math.min(stockTotal || old.stock_remaining, old.stock_remaining) : stockTotal,
      quantity_label: cleanText(body.quantity_label, 120), is_seed_listing: Boolean(body.is_seed_listing), neighbourhood: cleanText(body.neighbourhood, 120),
      status: cleanText(body.status || 'OPEN', 40).toUpperCase(), created_at: old?.created_at || nowIso(), updated_at: nowIso(),
    };
    db.listings[listingId] = listing; persist(); return send(res, 200, publicListing(listing));
  }

  m = pathName.match(/^\/v1\/listings\/([^/]+)\/claim$/);
  if (m && method === 'POST') {
    const user = requireUser(req, res); if (!user) return;
    const listing = db.listings[decodeURIComponent(m[1])];
    if (!listing) return error(res, 404, 'Listing not found.');
    if (listing.owner_id === user.id) return error(res, 409, 'You cannot claim your own listing.');
    const units = cleanInt(body.units, 1, 1000);
    const fullByHouseholds = listing.claimed_count >= listing.capacity_households;
    const fullByStock = listing.stock_total > 0 && listing.stock_remaining < units;
    if (listing.status !== 'OPEN' || fullByHouseholds || fullByStock) return error(res, 409, 'That listing is full or no longer available.');
    listing.claimed_count += 1;
    if (listing.stock_total > 0) listing.stock_remaining = Math.max(0, listing.stock_remaining - units);
    if (listing.claimed_count >= listing.capacity_households || (listing.stock_total > 0 && listing.stock_remaining <= 0)) listing.status = 'FULL';
    listing.updated_at = nowIso(); persist(); return send(res, 200, publicListing(listing));
  }

  if (method === 'GET' && pathName === '/v1/requests') {
    const neighbourhood = cleanText(url.searchParams.get('neighbourhood'), 120).toLowerCase();
    const requests = Object.values(db.requests).filter(x => !neighbourhood || x.neighbourhood.toLowerCase() === neighbourhood)
      .sort((a, b) => b.created_at.localeCompare(a.created_at)).map(publicRequest);
    return send(res, 200, { requests });
  }

  m = pathName.match(/^\/v1\/requests\/([^/]+)$/);
  if (m && method === 'PUT') {
    const user = requireUser(req, res); if (!user) return;
    const requestId = decodeURIComponent(m[1]).slice(0, 200);
    const old = db.requests[requestId];
    if (old && old.requester_id !== user.id) return error(res, 403, 'You do not own this request.');
    const item = {
      id: requestId, requester_id: user.id, requester_name: cleanText(body.requester_name || user.name, 120), requester_avatar: cleanText(body.requester_avatar, 32),
      produce: cleanText(body.produce, 80), note: cleanText(body.note, 2000), neighbourhood: cleanText(body.neighbourhood, 120),
      status: cleanText(body.status || 'OPEN', 40).toUpperCase(), created_at: old?.created_at || nowIso(), updated_at: nowIso(),
    };
    db.requests[requestId] = item; persist(); return send(res, 200, publicRequest(item));
  }

  if (method === 'POST' && pathName === '/v1/conversations') {
    const user = requireUser(req, res); if (!user) return;
    const listing = db.listings[cleanText(body.listing_id, 200)];
    if (!listing) return error(res, 404, 'Listing not found.');
    if (listing.owner_id === user.id) return error(res, 409, 'A grower cannot start a taker conversation with their own listing.');
    const existing = Object.values(db.conversations).find(c => c.listing_id === listing.id && c.grower_id === listing.owner_id && c.taker_id === user.id);
    if (existing) return send(res, 200, { id: existing.id });
    const conversation = {
      id: id('conv'), listing_id: listing.id, listing_headline: listing.headline,
      grower_id: listing.owner_id, grower_name: listing.owner_name, taker_id: user.id, taker_name: user.name, created_at: nowIso(),
    };
    db.conversations[conversation.id] = conversation; persist(); return send(res, 200, { id: conversation.id });
  }

  m = pathName.match(/^\/v1\/conversations\/([^/]+)\/messages$/);
  if (m && method === 'GET') {
    const user = requireUser(req, res); if (!user) return;
    const conversation = db.conversations[decodeURIComponent(m[1])];
    if (!isParticipant(conversation, user.id)) return error(res, conversation ? 403 : 404, conversation ? 'You are not part of this conversation.' : 'Conversation not found.');
    const since = Date.parse(url.searchParams.get('since') || '') || 0;
    const messages = Object.values(db.messages).filter(x => x.conversation_id === conversation.id && Date.parse(x.created_at) > since)
      .sort((a, b) => a.created_at.localeCompare(b.created_at))
      .map(x => ({ id: x.id, sender_id: x.sender_id, sender_name: x.sender_name, text: x.text, created_at: x.created_at }));
    return send(res, 200, { messages });
  }

  if (m && method === 'POST') {
    const user = requireUser(req, res); if (!user) return;
    const conversation = db.conversations[decodeURIComponent(m[1])];
    if (!isParticipant(conversation, user.id)) return error(res, conversation ? 403 : 404, conversation ? 'You are not part of this conversation.' : 'Conversation not found.');
    const text = cleanText(body.text, 3000);
    if (!text) return error(res, 400, 'Message cannot be empty.');
    const message = { id: id('msg'), conversation_id: conversation.id, sender_id: user.id, sender_name: user.name, text, created_at: nowIso() };
    db.messages[message.id] = message; persist();
    return send(res, 200, { id: message.id, sender_id: message.sender_id, sender_name: message.sender_name, text: message.text, created_at: message.created_at });
  }

  return error(res, 404, 'Not found.');
}

const server = http.createServer(async (req, res) => {
  try {
    await route(req, res);
  } catch (e) {
    console.error(e);
    error(res, e?.status || 500, e?.status ? e.message : 'Server error.');
  }
});

server.listen(PORT, HOST, () => {
  console.log(`ROOTED backend listening on http://${HOST}:${PORT}`);
  console.log(`Google auth: ${GOOGLE_CLIENT_ID ? 'configured' : 'not configured'} · AI provider: ${AI_PROVIDER_URL ? 'configured' : 'safe fallback'} · data.gov key: ${DATA_GOV_API_KEY ? 'server-side' : 'public/keyless'}`);
});
